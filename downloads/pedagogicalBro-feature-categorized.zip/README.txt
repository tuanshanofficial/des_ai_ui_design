# Feature course files grouped by function

Source: HYBleek/pedagogicalBro, feature branch, commit 5fbfdc3ea1e68b2e88f4d501129fa802c945623f.
All GitHub source file bytes are unchanged. Original paths are preserved beneath each English category to avoid filename collisions.

TeachingLogic: conceptual LLM prompts and policy (des_rag_policy_v3.py), project application prompts plus HTTP/login/storage orchestration (tutor_web.py), judgment and response formatting.
UIDesign: current course HTML, JavaScript, CSS, lesson data and upload template.
LearningRecords: learning summaries and diagnostic logs. Login, SQLite and full progress logic remain inside tutor_web.py.
CourseManagement: materials, question banks and uploads.
ModelProviders: API transports and provider configuration.
ContextProcessing: context budgets and shared request processing.
SharedPipeline: shared policy and session code.
TextbookRetrieval: optional textbook retrieval code; textbook corpora and model weights are not included.
Setup: dependencies, launchers and configuration template.
Tools: repository import and maintenance scripts.

This is a categorized source bundle, NOT a directly runnable relocated application. Python imports and resource paths are unchanged. To run the selected course application, first restore the original layout in a NEW directory:

    python restore_layout.py /path/to/new/course-demo

The destination must be absent or empty. Then from that directory:

    python -m pip install -r AI_TA_PYTHON_CODE/webui/requirements-course.txt
    python -m AI_TA_PYTHON_CODE.pedagogical_ai.tutor_web --env-file .env

Configure your real provider credentials locally using .env.example as a guide. No credentials are included. Do not use placeholder credentials to claim working AI behavior.
Original instructor PDFs and Word banks are not in GitHub and are not included; import them separately for original slides and assigned questions. Runtime SQLite records are generated locally. This bundle omits evaluation experiments, tests, historical UIs and textbook data. Optional textbook retrieval requires the omitted corpora, model weights and full dependencies. Online AI behavior has not been validated in this cloud environment.

restore_layout.py, MANIFEST.json and this README are packaging helpers, not GitHub source changes. GitHub has not been modified.
