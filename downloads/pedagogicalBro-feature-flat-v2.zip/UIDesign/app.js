'use strict';
const STORE = 'des-live-course-v1';
const INSTRUCTOR_PENDING = 'des-instructor-pending-v1';
const app = document.getElementById('app');
const titles = ['', 'Introduction to Simulation', 'Simulation Examples', 'General Principles and Simulation Software', 'Statistical Models', 'Random Number Generation', 'Random Variate Generation'];
let lessons = [], course = null, materials = null, busy = false, error = '', pendingReply = null;
let activeAction=null;
const slideCache = new Map(), slideRequests = new Map();
let local;
try { local = JSON.parse(localStorage.getItem(STORE) || '{}'); } catch { local = {}; }
if (!local || typeof local !== 'object' || Array.isArray(local)) local = {};
let instructorKey = '', instructorRequest = null, instructorRetryId = null;
try { const marker=JSON.parse(sessionStorage.getItem(INSTRUCTOR_PENDING)||'null');if(marker?.id)instructorRequest={id:marker.id,path:marker.path||'/api/instructor/questions',lookupOnly:true}; } catch { /* No pending instructor submission. */ }
let instructorDraft = {lecture:'1',lo:'',prompt:'',optionA:'',optionB:'',optionC:'',optionD:'',correct_option:'',answer:'',rubric:'',context:''};
let instructorNotice = '';
let instructorRecording = null;
let usernameDraft = '', historyEvents = [], instructorUpload = null;
let conversationOwner = null;
const lectureConversations = new Map();
if (local.request && !local.request.data) {
  try { const [path,data] = JSON.parse(local.request.fingerprint); Object.assign(local.request,{path,data}); } catch { delete local.request; }
}
if (local.request && (!/^\/api\/(concept|complete_concept|intro|answer)$/.test(local.request.path) || !local.request.data || !local.request.id)) delete local.request;
let view = 'home', index = 0, lecture = 1, cursor = 0;
if(!local.drafts||typeof local.drafts!=='object'||Array.isArray(local.drafts))local.drafts={};
if(!local.choices||typeof local.choices!=='object'||Array.isArray(local.choices))local.choices={};
const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const format = t => esc(t).replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
function save() {
  if(view==='learn'&&lessons[index]?.lecture===lecture) {
    if(!local.lastConcepts||typeof local.lastConcepts!=='object'||Array.isArray(local.lastConcepts))local.lastConcepts={};
    local.lastConcepts[lecture]=index;
  }
  try { localStorage.setItem(STORE, JSON.stringify(local)); } catch { /* Current session remains usable. */ }
}
function pendingRequest() { return instructorRequest || local.request || null; }
function clearRequest(request) {
  if (instructorRequest?.id === request.id) { instructorRequest = null;instructorRetryId=null;try {sessionStorage.removeItem(INSTRUCTOR_PENDING);}catch{} }
  if (local.request?.id === request.id) delete local.request;
  save();
}
function completeAction(request, result, {preserveDraft=false}={}) {
  const data=request.data;
  if(request.path==='/api/concept') invalidateLectureConversation(lessons[data.lesson_index]?.lecture);
  if(request.path==='/api/answer') invalidateLectureConversation(Number(data.lecture));
  if(request.path==='/api/complete_concept') {
    lecture=lessons[data.lesson_index].lecture;
    index=data.lesson_index;
    if(index===lessons.map(x=>x.lecture).lastIndexOf(lecture)) view=lectureProgress(lecture)?.application_required===false?'progress':'intro';
    else { index++; view='learn'; }
  } else if(request.path==='/api/intro') {
    lecture=data.lecture;view='quiz';
    const qs=currentQuestions(),next=qs.findIndex(q=>!resolved(q));cursor=next<0?qs.length-1:next;
  } else if(request.path==='/api/concept') {
    index=data.lesson_index;lecture=lessons[index].lecture;view='learn';
    const key=`chat:${index}`;
    if(!preserveDraft&&data.message!=='/reset'&&(local.drafts[key]||'').trim()===data.message) local.drafts[key]='';
  } else if(request.path==='/api/answer') {
    lecture=data.lecture;view='quiz';
    const qs=currentQuestions(),at=qs.findIndex(q=>q.id===data.question_id);
    if(at>=0)cursor=at;
    const key=`${data.lecture}:${data.question_id}`;
    if(!preserveDraft&&data.kind!=='selection'&&(local.drafts[key]||'').trim()===data.answer)local.drafts[key]='';
  } else if(request.path==='/api/instructor/questions') {
    view='instructor';
    instructorNotice=`Question ${result.question_id} was added to the question bank.`;
    instructorDraft={lecture:String(data.lecture),lo:String(data.lo),prompt:'',optionA:'',optionB:'',optionC:'',optionD:'',correct_option:'',answer:'',rubric:'',context:''};
  } else if(request.path==='/api/instructor/import') {
    view='instructor';instructorNotice=instructorResultNotice(result);instructorUpload=null;
  }
}
function responseMessage(result, fallback='The response could not be completed. Please try again.') {
  return typeof result?.error==='string'?result.error:result?.error?.message||fallback;
}
function updateSession(result) {
  if(result?.session){course=result.session;if(course.materials)materials=course.materials;}
}
function restoreFailedDraft(request) {
  const data=request.data;
  if(request.path==='/api/concept') {
    const key=`chat:${data.lesson_index}`;
    if(data.message!=='/reset'&&!local.drafts[key])local.drafts[key]=data.message;
    if(lessons[data.lesson_index]){index=data.lesson_index;lecture=lessons[index].lecture;view='learn';}
  } else if(request.path==='/api/answer') {
    const key=`${data.lecture}:${data.question_id}`;
    if(data.kind==='selection'){if(!local.choices[key])local.choices[key]=data.answer;}
    else if(!local.drafts[key])local.drafts[key]=data.answer;
    lecture=data.lecture;view='quiz';
    const at=currentQuestions().findIndex(q=>q.id===data.question_id);if(at>=0)cursor=at;
  } else if(request.path==='/api/complete_concept'&&lessons[data.lesson_index]) {
    index=data.lesson_index;lecture=lessons[index].lecture;view='learn';
  } else if(request.path==='/api/intro') {lecture=data.lecture;view='intro';}
}
function currentStudentRequest(request) {return local.request?.id===request.id;}
function trackActionRequest(request) {if(activeAction&&!activeAction.requestId)activeAction.requestId=request.id;}
function ownsAction(action) {
  const pending=pendingRequest();
  return activeAction===action&&(!action.requestId||!pending||pending.id===action.requestId);
}
function releaseUncommittedRequest(request,result) {
  if(!currentStudentRequest(request))return;
  updateSession(result);restoreFailedDraft(request);clearRequest(request);
}
function confirmedEditableFailure(result,request) {
  return result?.committed===false&&result.editable===true&&(!result.request_id||result.request_id===request.id);
}
async function requestJson(path,options={},timeoutMs=45000,allowMissing=false) {
  const controller=typeof AbortController==='function'?new AbortController():null;
  let timer;
  const timeout=new Promise((_,reject)=>{
    timer=setTimeout(()=>{
      reject(new Error(options.method==='POST'&&pendingRequest()
        ?'The tutor is taking longer than expected. Your draft is saved. Use Recover previous action to check the result before sending again.'
        :'The connection is taking longer than expected. Please try checking again.'));
      controller?.abort();
    },timeoutMs);
  });
  try {
    return await Promise.race([(async()=>{
      const response=await fetch(path,{...options,...(controller?{signal:controller.signal}:{})});
      // Older course servers may return an HTML 404 for the lookup route.
      const result=allowMissing&&[404,405].includes(response.status)?{}:await response.json();
      return {response,result};
    })(),timeout]);
  } finally {clearTimeout(timer);}
}
async function api(path, data) {
  const headers={'Content-Type':'application/json'};
  if(local.token)headers.Authorization=`Bearer ${local.token}`;
  const mutation=Boolean(data)&&path!=='/api/session',instructor=/^\/api\/instructor\/(questions|import)$/.test(path);
  let request=null,body=data;
  if(data) {
    const fingerprint=JSON.stringify([path,data]),pending=pendingRequest();
    if(pending&&(!mutation||pending.fingerprint!==fingerprint))throw new Error('Recover the previous action before submitting something new.');
    if(instructor) {
      if(!instructorKey.trim())throw new Error('Enter the instructor access code shown by the local server.');
      headers['X-Instructor-Key']=instructorKey;
    }
    if(mutation) {
      request=pending||{path,data,fingerprint,id:instructor&&instructorRetryId?instructorRetryId:crypto.randomUUID()};
      if(instructor) { instructorRequest=request;try {sessionStorage.setItem(INSTRUCTOR_PENDING,JSON.stringify({id:request.id,...(request.path==='/api/instructor/import'?{path:request.path}:{})}));}catch{} } else local.request=request;
      body={...request.data,request_id:request.id};trackActionRequest(request);save();
    }
  }
  const {response,result}=await requestJson(path,{method:data?'POST':'GET',headers,...(data?{body:JSON.stringify(body)}:{})});
  if(request&&!instructor&&!currentStudentRequest(request))return {ignored:true};
  if(request&&!instructor&&response.status===202)throw new Error('The previous response is still being processed. Check again in a moment.');
  if(!response.ok) {
    if(request&&!instructor&&response.status===409) {
      // The same ID may already describe a different committed answer. Read it
      // before accepting another submission; retain this unassessed draft.
      request.conflict=true;save();
      return recoverStudentRequest(request);
    }
    if(request&&!instructor&&confirmedEditableFailure(result,request)) {
      // The server has permanently retired this failed ID. A later Send starts
      // a new attempt; recovery must never rerun its model operation.
      releaseUncommittedRequest(request,result);
    } else if(request&&response.status>=400&&response.status<500) {
      if(instructor)instructorRequest={id:request.id,path:request.path,lookupOnly:true};
      else clearRequest(request);
    }
    throw new Error(responseMessage(result));
  }
  updateSession(result);
  if(request) {completeAction(request,result,{preserveDraft:request.conflict===true});clearRequest(request);}
  return result;
}
async function recoverStudentRequest(request) {
  if(!currentStudentRequest(request))return {ignored:true};
  trackActionRequest(request);
  const headers={};if(local.token)headers.Authorization=`Bearer ${local.token}`;
  const {response,result}=await requestJson(`/api/requests/${encodeURIComponent(request.id)}`,{headers},15000,true);
  if(!currentStudentRequest(request))return {ignored:true};
  if(response.status===404||response.status===405) {
    // Even on an older server, absence of a lookup route is not evidence that
    // the original teaching request was never accepted. Never replay it here.
    throw new Error('This server cannot check the saved result yet. Reconnect to the updated course server and recover it before submitting another answer.');
  }
  if(!currentStudentRequest(request))return {ignored:true};
  if(response.status===202||result.status==='pending')throw new Error(result.message||'The previous response is still being processed. Check again in a moment.');
  if(!response.ok)throw new Error(responseMessage(result,'The previous response could not be confirmed. Please try recovery again.'));
  if(result.status==='committed'&&result.committed===true&&result.data?.session) {
    updateSession(result.data);completeAction(request,result.data,{preserveDraft:request.conflict===true});clearRequest(request);
    if(request.conflict)error='An earlier reply was already saved. Your unsent changes remain in the draft.';
    return result.data;
  }
  if(result.status==='failed'&&confirmedEditableFailure(result,request)) {
    releaseUncommittedRequest(request,result);
    throw new Error(responseMessage(result,'The previous response did not finish. Your answer is saved; you can edit it or send it again.'));
  }
  if(result.status==='not_found'&&result.request_retired===true&&confirmedEditableFailure(result,request)) {
    // The server atomically retired the absent ID, so a delayed original POST
    // cannot arrive later and assess this answer after editing is enabled.
    releaseUncommittedRequest(request,result);
    error='Your answer is saved. You can edit it or send it again.';return result;
  }
  // A bare not_found does not exclude a delayed POST. Keep the original ID
  // blocked until a compatible server can confirm or retire it.
  throw new Error('The previous response could not be confirmed. Recover it again before submitting another answer.');
}
async function recoverPreviousAction() {
  if(busy)return;
  const request=pendingRequest();if(!request)return;
  await perform(async()=>{
    if(request.lookupOnly) {
      if(!instructorKey.trim())throw new Error('Enter the instructor access code to check your previous submission.');
      const {response,result}=await requestJson(`/api/instructor/requests/${encodeURIComponent(request.id)}`,{headers:{'X-Instructor-Key':instructorKey}},15000,true);
      if(response.status===202||result.status==='pending')throw new Error(result.message||'The previous submission is still processing. Check again in a moment.');
      if(response.status===404) {instructorRetryId=request.id;instructorRequest=null;instructorNotice=request.path==='/api/instructor/import'?'The previous upload has no saved receipt. Choose the same Word file to retry.':'The previous question has no saved receipt. Enter the same question to retry it safely.';view='instructor';return;}
      if(!response.ok)throw new Error(result.error||'Could not confirm the previous submission.');
      clearRequest(request);instructorNotice=instructorResultNotice(result);view='instructor';
    } else await recoverStudentRequest(request);
  });
}
function recoveryNotice() {
  if(!pendingRequest())return '';
  return `<section class="warning recoveryNotice" role="status"><div><strong>${busy?'Your response is still being prepared.':'The previous action needs confirmation.'}</strong><p>${instructorRequest?'Confirm your previous question submission before adding another question.':busy?'Your draft is saved on this page. Wait for the reply; if it takes too long, check its saved result before sending again.':'Check whether your previous answer was saved. This will not submit or assess it again.'}</p>${instructorRequest?`<label class="instructorField"><span>Instructor access code</span><input data-recover aria-label="Instructor access code" type="password" autocomplete="off" value="${esc(instructorKey)}" oninput="instructorKey=this.value"></label>`:''}</div><button class="btn compact" data-recover ${busy?'disabled':''} onclick="recoverPreviousAction()">${busy?'Working…':'Recover previous action'}</button></section>`;
}
async function perform(work) {
  if(busy)return;
  const action={requestId:null,slow:false};activeAction=action;
  busy=true;error='';render();scrollChat();
  const slowTimer=setTimeout(()=>{
    if(ownsAction(action)&&busy){action.slow=true;render();scrollChat();}
  },12000);
  try {await work();}
  catch(e) {if(ownsAction(action))error=e.message||'Connection failed. Your draft is saved; retry when ready.';}
  finally {
    clearTimeout(slowTimer);
    // A delayed response from an earlier request must not finish a newer turn.
    if(ownsAction(action)) {
      const replyInput=pendingReply?.type==='concept'?'chatInput':pendingReply?.type==='project'?'projectReply':null;
      activeAction=null;busy=false;pendingReply=null;save();render();scrollChat();
      if(replyInput&&!pendingRequest()){const input=document.getElementById(replyInput);if(input&&!input.disabled)input.focus({preventScroll:true});}
    }
  }
}
function scrollChat() {
  requestAnimationFrame(()=>{
    const box=document.getElementById('chatMessages');
    if(!box)return;
    const welcomeOnly=box.querySelector('.conceptWelcome')&&!box.querySelector('.lectureConversation .bubble');
    box.scrollTop=welcomeOnly?0:box.scrollHeight;
  });
}
function pendingBubbles(type,key) {
  if(!busy||pendingReply?.type!==type||pendingReply.key!==key) return '';
  return `<div class="bubble student">${format(pendingReply.text)}</div><div class="bubble typing" aria-hidden="true"><span>.</span><span>.</span><span>.</span></div><p class="processingNote" role="status">${activeAction?.slow?'Still preparing your next step. Your message is saved on this page.':pendingReply.followUp?'Preparing an explanation of this question…':'Reviewing your response and preparing the next step…'}</p>`;
}
function scopeLectureConversations() {
  if(conversationOwner!==local.token) {
    lectureConversations.clear();
    conversationOwner=local.token;
  }
}
function lectureConversation(lectureNumber) {
  scopeLectureConversations();
  if(!lectureConversations.has(lectureNumber)) {
    lectureConversations.set(lectureNumber,{turns:null,status:'new'});
  }
  return lectureConversations.get(lectureNumber);
}
function invalidateLectureConversation(lectureNumber) {
  if(!lectureNumber)return;
  const {turns}=lectureConversation(lectureNumber);
  lectureConversations.set(lectureNumber,{turns,status:'new'});
}
function conversationContent(lectureNumber, fallback) {
  const {turns,status}=lectureConversation(lectureNumber);
  const messages=turns===null?fallback.map(messageBubble).join(''):turns.map((turn,i)=>{
    const prior=turns[i-1];
    const changedContext=!prior||prior.route!==turn.route||prior.lesson_index!==turn.lesson_index||prior.question_id!==turn.question_id;
    const topic=turn.route==='concept'?lessons[turn.lesson_index]?.title:turn.question_prompt;
    const label=changedContext?`<p class="conversationContext">${turn.route==='concept'?'Concept':'Application'}${topic?' · '+esc(topic):''}</p>`:'';
    const orderNote=turn.order_unknown&&!prior?.order_unknown?'<p class="small muted">The exact order of these older messages is unavailable.</p>':'';
    const student=turn.student_text&&turn.mode!=='reset'?messageBubble({role:'user',content:turn.student_text}):'';
    const tutor=turn.tutor_text?messageBubble({role:'assistant',content:turn.tutor_text}):'';
    return label+orderNote+student+tutor;
  }).join('');
  const notice=status==='error'
    ?'<p class="small muted">The lecture conversation could not be loaded. <button type="button" class="textButton" onclick="retryLectureConversation()">Retry</button></p>'
    :turns===null&&local.token?'<p class="small muted" role="status">Loading lecture conversation…</p>':'';
  return notice+messages;
}
function lectureConversationMarkup(lectureNumber, fallback) {
  return `<div id="lectureConversation" class="lectureConversation" aria-label="Lecture ${lectureNumber} conversation">${conversationContent(lectureNumber,fallback)}</div>`;
}
function updateLectureConversationPanel(lectureNumber) {
  if(lecture!==lectureNumber||!['learn','quiz'].includes(view))return;
  const panel=document.getElementById('lectureConversation');
  if(!panel)return;
  const box=document.getElementById('chatMessages');
  const atLatest=box&&box.scrollHeight-box.scrollTop-box.clientHeight<40;
  const q=view==='quiz'?currentQuestions()[cursor]:null;
  const fallback=view==='learn'?course.chats[String(index)]||[]:q?course.results[questionKey(q)]?.dialogue||[]:[];
  panel.innerHTML=conversationContent(lectureNumber,fallback);
  if(atLatest)scrollChat();
}
async function loadLectureConversation(lectureNumber) {
  const token=local.token,state=lectureConversation(lectureNumber);
  if(!token||state.status!=='new')return;
  state.status='loading';
  try {
    const {response,result}=await requestJson('/api/session/conversation?lecture='+lectureNumber,
      {headers:{Authorization:`Bearer ${token}`}},15000);
    if(!response.ok||result.lecture!==lectureNumber||!Array.isArray(result.turns))throw new Error('Invalid conversation response.');
    state.turns=result.turns;
    state.status='loaded';
  } catch {
    state.status='error';
  }
  if(local.token===token&&lectureConversation(lectureNumber)===state)updateLectureConversationPanel(lectureNumber);
}
function retryLectureConversation() {
  if(busy||pendingRequest())return;
  invalidateLectureConversation(lecture);
  updateLectureConversationPanel(lecture);
  loadLectureConversation(lecture);
}
function lectureProgress(n) {return course?.progress.find(p=>p.lecture===Number(n));}
function canStudy(n) {return Boolean(course)&&(course.accessible_lectures?course.accessible_lectures.includes(Number(n)):n<=course.unlocked);}
function lectureNumbers() {return [...new Set(lessons.map(x=>x.lecture))].sort((a,b)=>a-b);}
function applicationReady(n) { return Boolean(lectureProgress(n)?.application_ready)&&course?.materials?.question_banks?.available!==false; }
function firstUnfinished(n) { return lessons.findIndex((x,i)=>x.lecture===n&&!course.completed_concepts.includes(i)); }
async function completeConcept() {
  if(busy||pendingRequest()||local.applicationReview?.lecture===lecture)return;
  await perform(async()=> { await api('/api/complete_concept',{lesson_index:index}); });
}
let drawerReturnFocus=null;
function toggleSidebar(open) {
  open=Boolean(open);
  const drawer=document.getElementById('lessonDrawer'),tab=document.getElementById('drawerTab');
  const wasOpen=document.body.classList.contains('drawerOpen');
  if(open&&!wasOpen)drawerReturnFocus=document.activeElement;
  const containedFocus=drawer.contains(document.activeElement);
  document.body.classList.toggle('drawerOpen',open);
  drawer.inert=!open;drawer.setAttribute('aria-hidden',String(!open));
  tab.setAttribute('aria-expanded',String(open));
  if(open&&!wasOpen&&document.activeElement===tab)drawer.querySelector('button:not(:disabled)')?.focus();
  if(!open&&containedFocus)(drawerReturnFocus?.isConnected?drawerReturnFocus:tab).focus();
}
document.addEventListener('keydown', e => {
  if(e.key === 'Escape') toggleSidebar(false);
  if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.target.matches('#chatInput,#projectReply')) {
    e.preventDefault();e.target.form.requestSubmit();
  }
});
function showHome() { if(busy) return; view = 'home'; error = ''; toggleSidebar(false); render(); }
function showSlides() {
  if(busy)return;
  view='slides';error='';toggleSidebar(false);render();
}
function openInstructor() {
  if(busy)return;
  view='instructor';error='';toggleSidebar(false);render();
}
async function showProgress() {
  if(busy)return;
  view='progress';error='';toggleSidebar(false);
  if(local.token)await perform(async()=>{await api('/api/session');});
  else render();
}
function resumeLecture(n) {
  if(busy||!canStudy(n))return;
  const unfinished=firstUnfinished(n);
  if(unfinished>=0)go(unfinished);else if(lectureProgress(n)?.application_required===false)go(lessons.findIndex(x=>x.lecture===n));else openQuiz(n);
}
function renderProgress() {
  if(!course)return `<section class="workspace"><div class="pageHeading"><div><h1>Course Progress</h1><p>Sign in to restore your learning progress.</p></div></div>${loginMarkup()}</section>`;
  const totals=course.progress.reduce((a,p)=>({concepts:a.concepts+p.concepts_completed,conceptTotal:a.conceptTotal+p.concepts_total,questions:a.questions+p.resolved,questionTotal:a.questionTotal+p.total,correct:a.correct+p.correct}),{concepts:0,conceptTotal:0,questions:0,questionTotal:0,correct:0});
  const stats=[['Concepts completed',`${totals.concepts} / ${totals.conceptTotal}`],['Application completed',`${totals.questions} / ${totals.questionTotal}`],['Correct answers',String(totals.correct)],['Completed with support',String(totals.questions-totals.correct)]];
  return `<section class="workspace"><div class="pageHeading"><div><h1>Course Progress</h1><p>${course.username?'Saved for '+esc(course.username)+'. ':''}Continue your learning from any sign-in.</p><p class="small muted">Correct answers and completion with support are recorded separately.</p></div><div class="progressHeadingActions"><button class="btn ghost" onclick="showHistory()">Conversation history</button><button class="btn ghost" onclick="downloadLearningRecord()">Download learning record</button><button class="btn" ${busy?'disabled':''} onclick="continueLearning()">Continue learning</button></div></div><div class="panel progressOverview">${stats.map(([label,value])=>`<div class="statCard"><span>${label}</span><strong>${value}</strong></div>`).join('')}</div><section class="panel lectureList"><h2>Your lectures</h2>${course.progress.map(p=>{
    const conceptOnly=p.application_required===false,finished=conceptOnly?p.concepts_total>0&&p.concepts_completed===p.concepts_total:p.total>0&&p.resolved===p.total;
    const status=p.locked?'Locked':finished?'Completed':conceptOnly?'Concept learning':p.bank_available===false||p.total===0?'Awaiting instructor question bank':p.application_ready?'Application ready':'In progress';
    return `<article class="lectureProgress"><div class="lectureIdentity"><span class="eyebrow">Lecture ${p.lecture}</span><h3>${esc(titles[p.lecture]||'Course concepts')}</h3><span class="tag ${p.locked?'locked':finished?'complete':'inProgress'}">${status}</span></div><div class="lectureMetrics"><div class="metricRow"><span>Concepts</span><div class="progress" role="progressbar" aria-label="Lecture ${p.lecture} concepts" aria-valuenow="${p.concepts_completed}" aria-valuemin="0" aria-valuemax="${p.concepts_total}"><div style="width:${p.concepts_completed/(p.concepts_total||1)*100}%"></div></div><span>${p.concepts_completed} / ${p.concepts_total}</span></div>${conceptOnly?'<p class="small muted">Read the original lecture and discuss its concepts with the teaching assistant.</p>':`<div class="metricRow"><span>Application</span><div class="progress" role="progressbar" aria-label="Lecture ${p.lecture} application" aria-valuenow="${p.resolved}" aria-valuemin="0" aria-valuemax="${p.total}"><div style="width:${p.resolved/(p.total||1)*100}%"></div></div><span>${p.resolved} / ${p.total}</span></div><p class="small muted">${p.locked?`Complete Lecture ${p.lecture-1} application to unlock`:p.application_ready?`${p.correct} correct · ${p.resolved-p.correct} completed with support`:'Finish the concepts to unlock application'}</p>`}</div><div class="progressActions">${p.locked?'<button class="btn ghost" disabled>Locked</button>':`<button class="btn ${p.application_ready?'ghost':''}" ${busy?'disabled':''} onclick="resumeLecture(${p.lecture})">${finished?'Review concepts':'Continue concepts'}</button>${conceptOnly?'':`<button class="btn ghost" ${busy||!p.application_ready?'disabled':''} onclick="openQuiz(${p.lecture})">${finished?'Review application':p.application_ready?'Open application':'Application locked'}</button>`}`}</div></article>`;
  }).join('')}</section><p class="small muted savedNote">Your progress and conversations are saved automatically.</p></section>`;
}

function objectiveLimit(lecture) {return materials?.question_banks?.lectures?.find(item=>item.lecture===Number(lecture))?.objectives||{1:7,2:7,3:9}[lecture];}
function updateInstructorField(key,value) { instructorDraft[key]=value; }
async function addInstructorQuestion() {
  if(busy||pendingRequest())return;
  const options=['A','B','C','D'].map(key=>instructorDraft['option'+key].trim());
  const payload={lecture:Number(instructorDraft.lecture),lo:Number(instructorDraft.lo),prompt:instructorDraft.prompt.trim(),options:options.some(Boolean)?options.map((value,i)=>`${'ABCD'[i]}. ${value}`):[],correct_option:options.some(Boolean)?instructorDraft.correct_option:null,answer:instructorDraft.answer.trim(),rubric:instructorDraft.rubric.trim(),context:instructorDraft.context.trim()};
  if(!payload.prompt||!payload.answer||!payload.rubric||!Number.isInteger(payload.lo)||payload.lo<1||payload.lo>objectiveLimit(payload.lecture)) {error='Enter the learning objective, question, reference answer, and grading criteria.';render();return;}
  if(payload.options.length&&(options.some(value=>!value)||!payload.correct_option)){error='For a multiple-choice question, provide all four options and choose the correct option.';render();return;}
  instructorNotice='';
  await perform(async()=>{await api('/api/instructor/questions',payload);});
}
function instructorResultNotice(result) {
  return Number.isInteger(result.imported_count)?`${result.already_imported?'This file was already imported.':'Imported '+result.imported_count+' questions.'} ${result.filename||''}`:`Question ${result.question_id} was added to the question bank.`;
}
async function selectBankFile(input) {
  if(busy||pendingRequest())return;
  const file=input.files?.[0];instructorUpload=null;instructorNotice='';error='';
  if(!file){render();return;}
  if(!file.name.toLowerCase().endsWith('.docx')){error='Choose a Word .docx file using the downloadable template.';render();return;}
  if(file.size>5*1024*1024){error='Choose a Word file smaller than 5 MB.';render();return;}
  await perform(async()=>{
    const content=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error('The Word file could not be read. Choose it again.'));reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(file);});
    instructorUpload={filename:file.name,content_base64:content,preview:null};
  });
}
async function previewBankUpload() {
  if(busy||pendingRequest()||!instructorUpload)return;
  if(!instructorKey.trim()){error='Enter the instructor access code before previewing the Word file.';render();return;}
  await perform(async()=>{
    const {response,result}=await requestJson('/api/instructor/import-preview',{method:'POST',headers:{'Content-Type':'application/json','X-Instructor-Key':instructorKey},body:JSON.stringify({filename:instructorUpload.filename,content_base64:instructorUpload.content_base64})});if(!response.ok){instructorUpload.preview=null;throw new Error(responseMessage(result,'The Word file could not be validated.'));}
    instructorUpload.preview=result;
  });
}
async function confirmBankUpload() {
  if(busy||pendingRequest()||!instructorUpload?.preview)return;
  instructorNotice='';
  await perform(async()=>{await api('/api/instructor/import',{filename:instructorUpload.filename,content_base64:instructorUpload.content_base64,sha256:instructorUpload.preview.sha256});});
}
function instructorAccessHeaders() {
  const key=instructorKey.trim();
  if(!key)throw new Error('Enter the instructor access code shown by the local server.');
  return {'X-Instructor-Key':key};
}
function updateInstructorKey(value) {
  if(instructorKey===value)return;
  instructorKey=value;
  instructorRecording=null;
  const settings=document.getElementById('recordingSettings');
  if(settings)settings.innerHTML=recordingSettingsContent();
}
async function changeInstructorRecording(enabled) {
  if(busy||pendingRequest())return;
  await perform(async()=>{
    const headers=instructorAccessHeaders();
    const saving=typeof enabled==='boolean';
    if(saving)headers['Content-Type']='application/json';
    const {response,result}=await requestJson('/api/instructor/recording',
      {headers,...(saving?{method:'POST',body:JSON.stringify({enabled})}:{})},15000);
    if(!response.ok)throw new Error(responseMessage(result,'The recording setting could not be loaded.'));
    if(typeof result.enabled!=='boolean')throw new Error('The server did not return a recording setting.');
    instructorRecording=result.enabled;
  });
}
async function downloadInstructorConversations() {
  if(busy||pendingRequest())return;
  await perform(async()=>{
    const {response,result}=await requestJson('/api/instructor/records',{headers:instructorAccessHeaders()},15000);
    if(!response.ok)throw new Error(responseMessage(result,'The recorded conversations could not be downloaded.'));
    downloadRecord(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}),'sysc4005-recorded-conversations.json');
  });
}
function recordingSettingsContent() {
  const state=instructorRecording===null?'Enter the instructor access code to check the current setting.':
    instructorRecording?'Recording is on. New conversations are added to the teacher archive.':
    'Recording is off. Students can still restore their own conversations.';
  const settingAction=instructorRecording===null?'Check recording setting':instructorRecording?'Turn recording off':'Turn recording on';
  const actionValue=instructorRecording===null?'':String(!instructorRecording);
  return `<h2>Conversation recording</h2><p role="status">${state}</p><div class="recordingActions"><button class="btn ghost compact" ${busy?'disabled':''} onclick="changeInstructorRecording(${actionValue})">${settingAction}</button><button class="btn ghost compact" ${busy?'disabled':''} onclick="downloadInstructorConversations()">Download recorded conversations</button></div>`;
}
function renderInstructor() {
  const preview=instructorUpload?.preview;
  return `<section class="workspace instructorArea"><div class="pageHeading"><div><h1>Instructor question bank</h1><p>Upload a Word question bank using the fixed course template.</p></div><a class="btn ghost" href="/api/instructor/template" download="SYSC4005-question-bank-template.docx">Download Word template</a></div><section class="panel workspacePanel instructorPanel"><div class="questionForm"><div class="packageBody"><h2>Upload and check your Word file</h2><p>Use one Field / Value table per question. Include Lecture, Objective, Prompt, Answer and Rubric. For multiple-choice questions, complete all four options and the correct option.</p><p class="small muted">Replace every template placeholder and set Ready to import to Yes. Supported project banks: Lecture 1–3. Your file is checked in full before any questions are added.</p><label class="instructorField"><span>Instructor access code</span><input type="password" aria-label="Instructor access code" autocomplete="off" value="${esc(instructorKey)}" oninput="updateInstructorKey(this.value)" ${busy?'disabled':''}><small>The local server shows this code. It stays only while this page is open.</small></label><label class="instructorField"><span>Word question bank (.docx)</span><span class="fileControl"><span class="btn ghost fileButton">Choose Word file</span><input id="bankFile" class="fileInput" type="file" aria-label="Word question bank (.docx)" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onchange="selectBankFile(this)" ${busy?'disabled':''}><span class="fileSelection">${instructorUpload?'Selected: '+esc(instructorUpload.filename):'No Word file selected'}</span></span></label>${preview?`<section class="uploadPreview"><h2>Ready for review</h2><div class="uploadSummary"><strong>${preview.question_count} questions</strong><span>${Object.entries(preview.counts).filter(([,n])=>n).map(([n,count])=>'Lecture '+n+': '+count).join(' · ')}</span></div>${preview.already_imported?'<p>This exact file is already in the bank. Confirming it will keep the existing questions.</p>':''}${preview.questions.map((q,i)=>`<details><summary>${i+1}. Lecture ${q.lecture} · Objective ${q.lo} · ${esc(q.prompt)}</summary>${q.context?`<p>${esc(q.context)}</p>`:''}${renderTables(q.table)}${q.options.length?`<ul>${q.options.map(o=>'<li>'+esc(o)+'</li>').join('')}</ul><p><strong>Correct option:</strong> ${esc(q.correctOption)}</p>`:''}<p><strong>Reference answer:</strong> ${esc(q.answer)}</p><p><strong>Grading criteria:</strong> ${esc(q.rubric)}</p></details>`).join('')}</section>`:''}</div><div class="packageActions"><button class="btn ${preview?'ghost':''}" onclick="previewBankUpload()" ${busy||!instructorUpload?'disabled':''}>Validate & preview</button><button class="btn" onclick="confirmBankUpload()" ${busy||!preview?'disabled':''}>Confirm import</button></div><p class="packageNotice" role="status">${esc(instructorNotice)}</p></div></section><aside class="instructorSidebar"><section class="panel packageOverview"><h2>Question selection</h2><p>Each new student selects one question from each learning-objective pool.</p><p>Confirmed uploads are saved on this computer. Existing students keep their assigned questions and progress.</p><p class="small muted">Reference answers and grading criteria stay private to this portal.</p></section><section class="panel packageOverview" id="recordingSettings">${recordingSettingsContent()}</section></aside></section>`;
}

function go(i) {
  if(busy||!course||!lessons.length)return;
  i = Math.max(0, Math.min(lessons.length - 1, i));
  if(!canStudy(lessons[i].lecture)) return;
  if(local.applicationReview?.lecture!==lessons[i].lecture)delete local.applicationReview;
  index = i; lecture = lessons[i].lecture; view = 'learn'; error = ''; save(); toggleSidebar(false); render();
  scrollChat();
}
function openIntroduction(n) {
  if(busy||!canStudy(n))return;
  if(!applicationReady(n)){error='Finish all concepts in this lecture before starting application.';render();return;}
  delete local.applicationReview;
  lecture=n;view='intro';error='';save();render();
}
function currentQuestions() { return course?.questions[String(lecture)] || []; }
function questionKey(q) { return `${q.lecture}:${q.id}`; }
function resolved(q) { return ['correct','explained'].includes(course.results[questionKey(q)]?.status); }
function quizPosition(questions, questionId) {
  const active=questions.findIndex(q=>!resolved(q));
  const preferred=questions.findIndex(q=>q.id===questionId);
  if(preferred>=0&&(active<0||preferred<=active))return preferred;
  return active<0?questions.length-1:active;
}
function openQuiz(n, questionId) {
  if(busy || !course) return;
  if(!applicationReady(n)){openIntroduction(n);return;}
  if(!course.introduced.includes(n)) { openIntroduction(n); return; }
  const position=quizPosition(course.questions[String(n)]||[],questionId);
  if(position<0)return;
  delete local.applicationReview;
  lecture=n;cursor=position;view='quiz';error='';save();toggleSidebar(false);render();scrollChat();
}
function reviewConcepts() {
  if(busy||pendingRequest()||view!=='quiz')return;
  const question=currentQuestions()[cursor];
  const savedReview=course.resume?.return_to?.lecture===lecture?course.resume.lesson_index:undefined;
  const lastViewed=[local.lastConcepts?.[lecture],local.lastView?local.index:undefined,savedReview]
    .find(i=>Number.isInteger(i)&&lessons[i]?.lecture===lecture);
  const target=lastViewed??lessons.findIndex(lesson=>lesson.lecture===lecture);
  if(!question||target<0)return;
  local.applicationReview={view:'quiz',lecture,question_id:question.id};
  go(target);
}
function returnToApplication() {
  if(busy||pendingRequest()||!local.applicationReview)return;
  const {lecture,question_id}=local.applicationReview;
  openQuiz(lecture,question_id);
}
async function beginApplication() {
  await perform(async()=> { await api('/api/intro', {lecture}); });
}
async function startNew() {
  if(busy) return;
  if(course?.username){error='Your progress is saved under your username. Continue learning, or sign out to use another username.';render();return;}
  if(pendingRequest()){error='Recover the previous action before starting a new session.';render();return;}
  if(local.token && !confirm('Start a new session with newly selected questions? Your current session will no longer be resumed on this browser.')) return;
  await perform(async()=> {
    const result=await api('/api/session', {}); local={token:result.token,drafts:{},choices:{}};
    index=0; lecture=1; cursor=0; view='learn'; save();
  }, 'Starting your course session…');
}
function rememberProfile() {
  if(!course?.username)return;
  try {localStorage.setItem('des-profile:'+course.username.normalize('NFKC').toLowerCase(),JSON.stringify(local));} catch {}
}
function learningPosition() {
  if(!course||!lessons.length)return null;
  const saved=course.resume||{};
  for(const position of [local.applicationReview,saved.return_to,saved]) {
    if(!position||!canStudy(position.lecture))continue;
    if(position.view==='learn'&&lessons[position.lesson_index]?.lecture===position.lecture)return position;
    if(['intro','quiz'].includes(position.view)&&applicationReady(position.lecture))return position;
    if(position.view==='progress')return position;
  }
  const hasLearningRecord=saved.view||course.completed_concepts.length||course.introduced.length||
    Object.keys(course.results).length||Object.values(course.chats).some(chat=>chat.length);
  if(!hasLearningRecord)return null;
  const next=lessons.findIndex((lesson,i)=>canStudy(lesson.lecture)&&!course.completed_concepts.includes(i));
  const lessonIndex=Math.max(0,next);
  return {view:'learn',lecture:lessons[lessonIndex].lecture,lesson_index:lessonIndex};
}
function learningPositionLabel(position) {
  if(position.view==='quiz') {
    const question=quizPosition(course.questions[String(position.lecture)]||[],position.question_id);
    return `Lecture ${position.lecture} · Application${question>=0?' question '+(question+1):''}`;
  }
  if(position.view==='intro')return `Lecture ${position.lecture} · Project introduction`;
  if(position.view==='progress')return 'Course Progress';
  return `Lecture ${position.lecture} · ${lessons[position.lesson_index].title}`;
}
async function loginLearner() {
  if(busy||pendingRequest())return;
  const username=usernameDraft.trim();if(!username){error='Enter your username.';render();return;}
  await perform(async()=>{
    rememberProfile();
    const headers={'Content-Type':'application/json'};if(local.token)headers.Authorization=`Bearer ${local.token}`;
    const {response,result}=await requestJson('/api/login',{method:'POST',headers,body:JSON.stringify({username})});if(!response.ok)throw new Error(responseMessage(result,'Sign in could not be completed. Please try again.'));
    let saved={};try {saved=JSON.parse(localStorage.getItem('des-profile:'+result.username.normalize('NFKC').toLowerCase())||'{}');}catch{}
    const same=local.token===result.token;
    local=same?local:saved.token===result.token?saved:{drafts:{},choices:{}};
    local.token=result.token;local.username=result.username;course=result.session;materials=course.materials||materials;
    usernameDraft='';index=0;lecture=1;cursor=0;view='home';
    toggleSidebar(false);save();rememberProfile();
  });
}
function signOut() {
  if(busy)return;
  if(pendingRequest()){error='Recover the previous action before signing out.';render();return;}
  rememberProfile();local={drafts:{},choices:{}};course=null;index=0;lecture=1;cursor=0;view='home';
  historyEvents=[];error='';save();render();
}
async function showHistory() {
  if(busy||!local.token)return;
  await perform(async()=>{
    const {response,result}=await requestJson('/api/session/export',{headers:{Authorization:`Bearer ${local.token}`}},15000);if(!response.ok)throw new Error(responseMessage(result,'The conversation history could not be loaded.'));
    historyEvents=result.interactions||[];view='history';toggleSidebar(false);
  });
}
function renderHistory() {
  const turns=historyEvents.filter(e=>e.student_text||e.tutor_text);
  return `<section class="workspace historyWorkspace"><div class="pageHeading"><div><h1>Conversation history</h1><p>${course?.username?'Saved for '+esc(course.username)+'. ':''}All saved discussions and project answers, including earlier discussions you reset.</p></div><div class="progressHeadingActions"><button class="btn ghost" onclick="downloadLearningRecord()">Download learning record</button><button class="btn" onclick="showHistory()" ${busy?'disabled':''}>Refresh history</button></div></div><div class="historyList">${turns.length?turns.map(e=>`<article class="panel historyTurn"><div class="historyMeta">${esc(e.created_at)} · ${e.lecture?'Lecture '+e.lecture:'Concept '+(Number(e.lesson_index)+1)}${e.question_id?' · '+esc(e.question_id):''}</div>${e.question?.prompt?`<h2>${esc(e.question.prompt)}</h2>`:''}<div class="bubble student">${format(e.student_text)}</div><div class="bubble assistant"><div class="messageAuthor">AI Teaching Assistant</div>${format(e.tutor_text)}</div></article>`).join(''):'<section class="panel workspacePanel"><p>No saved conversations yet. Your messages will appear here after a completed response.</p></section>'}</div></section>`;
}
function loginMarkup() {
  return `<section class="loginPanel"><h2>${local.token?'Save this progress under a username':'Sign in to your course'}</h2><p class="small muted">Use the same username next time to restore your progress and conversation history. A new username starts your own course.</p><form class="usernameForm" onsubmit="event.preventDefault();loginLearner()"><label><span>Username</span><input id="usernameInput" name="username" autocomplete="username" maxlength="64" required value="${esc(usernameDraft)}" oninput="usernameDraft=this.value" placeholder="Your username" ${busy?'disabled':''}></label><button class="btn" ${busy?'disabled':''}>Sign in</button></form></section>`;
}
async function continueLearning() {
  if(busy||pendingRequest()||!local.token)return;
  if(!course){await perform(async()=>{await api('/api/session');});if(!course)return;}
  const position=learningPosition();
  if(position?.view==='quiz'){openQuiz(position.lecture,position.question_id);return;}
  if(position?.view==='intro'){openIntroduction(position.lecture);return;}
  if(position?.view==='progress'){await showProgress();return;}
  go(position?.lesson_index??lessons.findIndex(lesson=>lesson.lecture===1));
}
function drawSidebar() {
  document.getElementById('lessonDrawer').innerHTML=`<div class="drawerHead"><b>Course lectures</b><button aria-label="Close navigation" onclick="toggleSidebar(false)">×</button></div><div class="drawerScroll">${lectureNumbers().map(n=>`<div class="drawerGroup">Lecture ${n}${canStudy(n)?'':' · Locked'}</div>${lessons.map((x,i)=>x.lecture===n?`<button class="drawerLesson ${view==='learn'&&i===index?'active':''}" ${busy||pendingRequest()||!canStudy(n)?'disabled':''} onclick="go(${i})">${course?.completed_concepts.includes(i)?'✓ ':''}${esc(x.title)}</button>`:'').join('')}${lectureProgress(n)?.application_required===false?'':`<button class="drawerLesson" ${busy||pendingRequest()||!applicationReady(n)?'disabled':''} onclick="openQuiz(${n});toggleSidebar(false)">${applicationReady(n)?'Apply to Project →':'Finish concepts to unlock application'}</button>`}`).join('')}</div><div class="drawerFoot">Your completed concepts and conversations are saved automatically. Previous concepts remain available.</div>`;
}
function renderHome() {
  const position=learningPosition();
  const resume=position?`Resume: ${learningPositionLabel(position)}`:local.token?'Start with the first concept in Lecture 1.':'Sign in with your username to begin.';
  return `<div class="homeLanding"><section class="homeWelcome"><div class="eyebrow">LEARN · REASON · APPLY</div><h1><span>SYSC4005 · Learn to model systems.</span> Build confidence through practice.</h1><p>Understand discrete-event simulation with guided explanations and AI support, then apply your knowledge to a progressively developed project.</p>${course?.username?`<p class="homeStatus">Signed in as <strong>${esc(course.username)}</strong>. Your progress is saved.</p>`:''}<div class="homeActions"><button class="btn" onclick="continueLearning()" ${busy||!local.token?'disabled':''}>${position?'Continue from Last Time':'Start Learning'}</button><button class="btn ghost" onclick="showSlides()" ${busy?'disabled':''}>View Lecture Slides</button>${local.token?`<button class="btn ghost" onclick="showHistory()" ${busy?'disabled':''}>Conversation history</button>`:''}</div>${course?.username?'':loginMarkup()}<div class="homeStatus">${esc(resume)}</div></section><section class="panel aboutCourse"><h2>How learning works</h2><div class="journeyLine"><div class="journeyStep"><span class="journeySymbol" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4c4-2 6-1 9 1 3-2 5-3 9-1v15c-4-2-6-1-9 1-3-2-5-3-9-1z"/><path d="M12 5v15"/></svg></span><div><b>Learn concepts</b><small>Course materials and AI guidance</small></div></div><span class="journeyArrow">→</span><div class="journeyStep"><span class="journeySymbol" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="4" width="14" height="17" rx="2"/><rect x="9" y="2" width="6" height="4" rx="1"/><path d="M9 10h6M9 14h6M9 18h4"/></svg></span><div><b>Understand the project</b><small>Project goals and requirements</small></div></div><span class="journeyArrow">→</span><div class="journeyStep"><span class="journeySymbol" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><path d="M6.5 10v7.5H14"/></svg></span><div><b>Apply your knowledge</b><small>Guided project development</small></div></div></div><details class="homeAboutDetails"><summary>About this course</summary><p>Learn through course concepts and examples, and apply your understanding to build, verify and analyze a simulation model. Continue in sequence from your last learning activity.</p></details></section></div>`;
}
function selectedSlidePages(range) {
  if(Array.isArray(range))return new Set(range.map(Number));
  const pages=new Set();
  for(const part of String(range||'').split(',')) {
    const match=part.trim().match(/^(\d+)(?:\s*[–-]\s*(\d+))?$/);if(!match)continue;
    const first=Number(match[1]),last=Number(match[2]||match[1]);
    for(let page=first;page<=last&&page<=1000;page++)pages.add(page);
  }
  return pages;
}
function originalSlidesMarkup(data, lessonIndex) {
  const pages=data.pages||[];
  const url=value=>String(value||'').startsWith('/materials/')?esc(value):'';
  const pdf=data.source?.pdf_url||pages.find(page=>page.source_pdf||page.pdf_url)?.source_pdf||pages.find(page=>page.pdf_url)?.pdf_url?.split('#')[0];
  const text=pages.map(page=>`Slide ${page.page}${page.title?' · '+page.title:''}\n${page.text||''}`).join('\n\n');
  return `<p class="small muted">${esc(data.source?.filename||'Original course slides')} · Complete lecture · ${pages.length} slides${pdf?` · <a href="${url(pdf)}" target="_blank" rel="noopener">Open original PDF</a>`:''}</p><div class="lectureDeck" aria-label="Complete Lecture ${data.lecture} slides">${pages.map(page=>`<figure class="slidePage"><figcaption>Slide ${page.page}${page.title?' · '+esc(page.title):''}</figcaption>${page.image_url?`<img loading="lazy" src="${url(page.image_url)}" alt="Original Lecture ${data.lecture} slide ${page.page}">`:''}</figure>`).join('')||'<p>The lecture slides are not available yet.</p>'}</div>${text?`<details class="slideTranscript"><summary>Lecture text</summary><pre>${esc(text)}</pre></details>`:''}`;
}

function lectureSlidesMarkup(n, lessonIndex=null) {
  const cached=slideCache.get(n);
  return `<details class="lectureSlides" ontoggle="loadLectureSlides(this,${n},${lessonIndex===null?'null':lessonIndex})"><summary>${lessonIndex===null?'Lecture '+n+' original slides':'Original lecture slides'}</summary><div class="slidesContent">${cached?originalSlidesMarkup(cached,lessonIndex):'<p class="small muted">Open to load the original course slides.</p>'}</div></details>`;
}
async function loadLectureSlides(details,n,lessonIndex) {
  if(!details.open||slideCache.has(n))return;
  const content=details.querySelector('.slidesContent');content.textContent='Loading original slides…';
  try {
    if(!slideRequests.has(n))slideRequests.set(n,(async()=>{const {response,result:data}=await requestJson('/api/slides?lecture='+n,{},15000);if(!response.ok)throw new Error(data.error||'The original slides are unavailable.');slideCache.set(n,data);return data;})());
    const data=await slideRequests.get(n);
    if(details.isConnected)content.innerHTML=originalSlidesMarkup(data,lessonIndex);
  } catch(e) {if(details.isConnected)content.innerHTML=`<p>${esc(e.message)}</p><button class="btn ghost compact" onclick="loadLectureSlides(this.closest('details.lectureSlides'),${n},${lessonIndex===null?'null':lessonIndex})">Retry loading slides</button>`;}
  finally {slideRequests.delete(n);}
}
function slideLibraryMarkup() {
  const catalog=[...(materials?.slides?.lectures||[]),...(materials?.slides?.additional||[])];
  const lectures=[...new Set(catalog.filter(item=>item.available!==false).map(item=>Number(item.lecture)).filter(Number.isInteger))];
  return lectures.length?`<section class="panel courseSlidesLibrary"><h2>Original course slides</h2><p class="small muted">Read the supplied lecture PDFs, including the later course lectures.</p>${lectures.map(n=>lectureSlidesMarkup(n)).join('')}</section>`:'';
}
function renderSlides() {
  const library=slideLibraryMarkup();
  return `<section class="workspace slidesWorkspace"><div class="pageHeading"><div><h1>Lecture Slides</h1><p>Browse the original course lecture decks.</p></div></div>${library||'<p class="panel workspacePanel">Lecture slides are currently unavailable.</p>'}</section>`;
}
async function downloadLearningRecord() {
  if(!local.token)return;
  try {
    const response=await fetch('/api/session/export',{headers:{Authorization:`Bearer ${local.token}`}});
    if(!response.ok)throw new Error('The learning record could not be downloaded. Please try again.');
    downloadRecord(await response.blob(),'sysc4005-learning-record.json');
  } catch(e) {error=e.message;render();}
}
function downloadRecord(blob,filename) {
  const url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;
  link.download=filename;
  link.click();
  setTimeout(()=>URL.revokeObjectURL(url),0);
}
function lessonDetailMarkup(detail) {
  return detail.replace(/(<h3>[^<]*<\/h3>)(\s*(?:<p>[\s\S]*?<\/p>\s*)?<table\b[\s\S]*?<\/table>)/g,
    '<section class="workedExample">$1$2</section>');
}
function conceptWelcome(lesson) {
  const topic=lesson.title.replace(/\?$/, '').toLowerCase();
  const prompts=lesson.title==='Events and system state'?[
    'Can you give another example of an event and an activity?',
    'How would the system state change if two customers arrive at the same time?',
    'What state variables should we track in a bank model?'
  ]:[
    `Can you explain ${topic} with another example?`,
    `What is the key idea I should understand about ${topic}?`,
    `Can you guide me through a similar problem about ${topic}?`
  ];
  return `<div class="conceptWelcome"><div class="bubble assistant welcomeBubble"><p>Need help understanding ${esc(topic)}?</p><p>Ask a question or request another example. I can explain the concept, work through a similar problem, or clarify any part of this page.</p></div><div class="suggestedQuestions"><h3>Try asking...</h3>${prompts.map(prompt=>`<button class="suggestion" data-prompt="${esc(prompt)}" onclick="askSuggestion(this.dataset.prompt)"><span class="suggestionIcon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.8-2.5 2-2.5 4"/><circle cx="12" cy="16.5" r=".9" fill="currentColor" stroke="none"/></svg></span><span>${esc(prompt)}</span><span aria-hidden="true">&#8250;</span></button>`).join('')}</div></div>`;
}
function askSuggestion(prompt) {
  if(busy||pendingRequest())return;
  saveDraft(`chat:${index}`,prompt);
  sendChat();
}
function renderLearn() {
  const x=lessons[index],same=lessons.map((v,i)=>v.lecture===x.lecture?i:null).filter(i=>i!==null),at=same.indexOf(index),last=at===same.length-1;
  const chat=course.chats[String(index)]||[],draft=local.drafts[`chat:${index}`]||'';
  const earlierDone=same.filter(i=>i<index).every(i=>course.completed_concepts.includes(i));
  return `<header class="courseContext"><div><span class="lectureLabel">Lecture ${x.lecture} &middot; ${esc(titles[x.lecture])}</span><h1>${esc(x.title)}</h1></div><div class="contextControls"><span>Concept ${at+1} of ${same.length}</span><button class="iconButton" aria-label="Previous concept" ${busy||at===0?'disabled':''} onclick="go(${index-1})">‹</button><button class="iconButton" aria-label="Next concept" ${busy||last?'disabled':''} onclick="go(${index+1})">›</button></div></header><div class="cols lessonWorkspace"><article class="panel course"><div class="lessonDocument"><div class="readingContent"><p class="lead">${esc(x.body)}</p><div class="lessonDetail">${lessonDetailMarkup(x.detail)}</div><div class="section takeaway"><h3>Key idea</h3><p>${esc(x.idea)}</p></div>${lectureSlidesMarkup(x.lecture,index)}</div><div class="nav lessonFooter">${at>0?`<button class="btn ghost" ${busy?'disabled':''} onclick="go(${index-1})">← Previous concept</button>`:''}${local.applicationReview?.lecture===lecture?`<button class="btn" ${busy?'disabled':''} onclick="returnToApplication()">Back to Application →</button>`:`<button class="btn" ${busy||!earlierDone?'disabled':''} onclick="completeConcept()">${last?(lectureProgress(lecture)?.application_required===false?'Complete lecture':'Mark complete & apply to project'):'Mark complete & continue'} →</button>`}</div>${!earlierDone?`<p class="small muted">Complete the earlier concepts first. <button class="textButton" onclick="go(${firstUnfinished(lecture)})">Return to unfinished concept</button></p>`:''}</div></article><aside class="panel chat"><div class="chatHeading"><h2>AI Teaching Assistant</h2><p class="muted small">Lecture ${x.lecture} &middot; ${esc(x.title)}</p></div><div class="chatMessages" id="chatMessages" aria-live="polite">${lectureConversationMarkup(x.lecture,chat)}${!chat.length&&!busy?conceptWelcome(x):''}${pendingBubbles('concept',String(index))}</div><form class="chatFoot" onsubmit="event.preventDefault();sendChat()"><textarea id="chatInput" rows="1" aria-label="Type your question or response" placeholder="Type your question or response…" ${busy?'disabled':''} oninput="saveDraft('chat:${index}',this.value)">${esc(draft)}</textarea><button class="btn" ${busy?'disabled':''}>Send</button></form><p class="chatKeyboardHelp">Press Enter to send, Shift + Enter for a new line.</p><button class="textButton resetDiscussion" ${busy||!chat.length?'disabled':''} onclick="resetChat()">Reset this discussion</button></aside></div>`;
}
function renderIntro() {
  const notes={1:'Define the airport problem, its boundaries, model classification, components, and performance objectives. No implementation or probability distributions are required yet.',2:'Apply random-number mapping, simple queueing traces, simulation tables, performance measures, and financial calculations. Use only the supplied values and the Lecture 2 methods.',3:'Apply event notices, conditional delays, system snapshots, the future event list, event traces, and simulation program organization.'};
  const p=course.progress[lecture-1];
  return `<section class="introPage"><header class="courseContext"><div><span class="lectureLabel">Lecture ${lecture} · Project application</span><h1>Put Lecture ${lecture} into practice</h1></div></header><div class="introLayout"><article class="panel introBriefing"><div class="introReading"><p class="lead">${esc(notes[lecture])}</p><h2>Your airport project</h2><p>At Smiths Falls / Montague Airport, passengers complete check-in and security before boarding. Commuter passengers may wait for a later departure; provincial passengers have scheduled reservations.</p><div class="section"><div class="label">FIXED RESOURCE BOUNDARY</div><p>There are six check-in counters: one provincial business-class counter and five shared coach counters in the baseline. Study how the existing resources are organized; adding counters is not the task.</p></div></div></article><aside class="panel introInstructions"><h2>How this works</h2><p>You will answer ${p.total} questions: one randomly selected from each learning-objective pool. These selections stay fixed for your session. The tutor presents one assigned question at a time and provides feedback on your answer.</p><p>After four unsuccessful attempts, the fifth triggers a guided explanation. Completion with support is recorded separately from an independently correct answer. Complete every assigned question to unlock the next lecture.</p></aside></div><div class="panel introActions"><button class="btn ghost" ${busy?'disabled':''} onclick="go(${lessons.map(x=>x.lecture).lastIndexOf(lecture)})">← Back to concepts</button><button class="btn" ${busy?'disabled':''} onclick="beginApplication()">${course.introduced.includes(lecture)?'Return to assigned questions':'Start assigned questions'} →</button></div></section>`;
}
function renderTables(tables) {
  return (tables||[]).map((rows,n)=>`<div class="gridtable" tabindex="0" role="region" aria-label="Supplied question table ${n+1}"><table><thead><tr>${(rows[0]||[]).map(v=>`<th scope="col">${esc(v)}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(row=>`<tr>${row.map(v=>`<td class="${/\(\d+\)\s*_+/.test(v)?'numberedBlank':''}">${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`).join('');
}
function focusProjectReply() {
  if(busy||pendingRequest())return;
  const input=document.getElementById('projectReply');
  if(input&&!input.disabled){input.focus({preventScroll:true});input.scrollIntoView?.({block:'nearest',behavior:'smooth'});}
}
function returnToAssignedAnswer() {
  if(busy||pendingRequest())return;
  const q=currentQuestions()[cursor];
  if(!q)return;
  viewAssignedQuestion();
  if(q.options.length) {
    const question=document.getElementById('assignedQuestion');
    const input=question?.querySelector('input[type="radio"]:checked:not(:disabled)')||question?.querySelector('input[type="radio"]:not(:disabled)');
    input?.focus({preventScroll:true});
  } else focusProjectReply();
}
function nextStepMarkup(question,result,done) {
  if(!done&&!result.dialogue?.length)return '';
  const kind=done?'continue':'revise_answer';
  const supplied=result.next_action;
  const message=supplied?.kind===kind&&typeof supplied.message==='string'?supplied.message:
    done?'This question is complete. You can ask a follow-up here, or continue when you are ready.':
    question.options.length?'The assigned question is not complete yet. Review it, choose an option again, then submit your choice.':
    'The assigned question is not complete yet. Return to its requirements and submit your complete answer below.';
  return `<section class="nextStep" data-next-action="${kind}" role="status"><div class="nextStepCopy"><strong>${done?'You can keep discussing this question':'Your next step: revise the assigned answer'}</strong><p>${esc(message)}</p></div><button type="button" class="btn ghost compact" ${busy?'disabled':''} onclick="${done?'focusProjectReply()':'returnToAssignedAnswer()'}">${done?'Ask a follow-up':question.options.length?'Review question & choose again':'Write my complete answer'}</button></section>`;
}
function renderQuiz() {
  const qs=currentQuestions(),q=qs[cursor];
  if(!q)return '<article class="panel intro">Finish the lecture concepts to unlock application.</article>';
  const key=questionKey(q),r=course.results[key]||{attempts:0,dialogue:[]},done=resolved(q),final=cursor===qs.length-1;
  const choice=local.choices[key]||'',draft=local.drafts[key]||'';
  const active=qs.findIndex(item=>!resolved(item));
  const hasNumberedBlanks=q.table.some(table=>table.some(row=>row.some(cell=>/\(\d+\)\s*_+/.test(cell))));
  const status=done?(r.status==='correct'?'Correct':'Completed with support'):`In progress · ${r.attempts} unsuccessful ${r.attempts===1?'attempt':'attempts'}`;
  const composerHelp=done?'Your result is saved. Ask for an explanation here, or move to the next question.':
    r.guiding_question?'You can answer the assigned question, reply to the guiding question, or ask for help.':
    hasNumberedBlanks?'Answer the numbered blanks, show your working, or ask for help.':'You can submit an answer, explain your reasoning, or ask for help.';
  return `<section class="applicationPage"><header class="courseContext"><div><span class="lectureLabel">Lecture ${lecture} · Project application</span><h1>Apply to your airport project</h1></div><div class="contextControls"><button class="btn ghost compact" ${busy?'disabled':''} onclick="reviewConcepts()">Review Concepts</button><span>Question ${cursor+1} of ${qs.length}</span><details class="questionHistory"><summary>Question history <span aria-hidden="true">⌄</span></summary><div class="historyMenu">${qs.map((item,i)=>`<button ${busy||(active>=0&&i>active)?'disabled':''} ${i===cursor?'aria-current="step"':''} onclick="openQuestion(${i})">Question ${i+1} · LO ${item.lo}<span>${resolved(item)?course.results[questionKey(item)].status==='correct'?'Correct':'Completed with support':i===active?'Current':'Not started'}</span></button>`).join('')}</div></details></div></header><section class="panel applicationConversation"><div class="chatMessages" id="chatMessages" aria-live="polite"><article class="bubble assistant assignedQuestion" id="assignedQuestion" tabindex="-1"><div class="messageAuthor">AI Teaching Assistant</div><div class="question">${esc(q.prompt)}</div>${q.context?`<p class="suppliedContext">${esc(q.context)}</p>`:''}${renderTables(q.table)}${q.options.length?`<fieldset class="options"><legend class="srOnly">Select an answer</legend>${q.options.map(o=>`<label class="option"><input type="radio" name="answer" value="${esc(o[0])}" ${choice===o[0]?'checked':''} ${busy||done?'disabled':''} onchange="chooseOption('${key}',this.value)"><span>${esc(o)}</span></label>`).join('')}</fieldset><button id="submitChoice" class="btn compact" ${busy||done||!choice?'disabled':''} onclick="submitChoice()">Submit choice</button>`:hasNumberedBlanks?'<p class="small muted">Reply in the chat using the numbered blanks: (1) …, (2) …, (3) …</p>':'<p class="small muted">Write your answer in the chat below.</p>'}</article>${lectureConversationMarkup(lecture,r.dialogue)}${pendingBubbles('project',key)}</div><div class="applicationBottom"><div class="chatUtilities"><button class="btn ghost compact" onclick="viewAssignedQuestion()">View assigned question</button><span class="questionStatus ${done?'resolved':''}" role="status">${status}</span></div>${nextStepMarkup(q,r,done)}<form class="chatFoot" onsubmit="event.preventDefault();submitAnswer()"><textarea id="projectReply" rows="2" aria-label="${done?'Ask a follow-up about this question':'Type your question or response'}" placeholder="${done?'Ask a follow-up about this question…':'Type your question or response…'}" ${busy?'disabled':''} oninput="saveDraft('${key}',this.value)">${esc(draft)}</textarea><button class="btn" ${busy?'disabled':''}>${done?'Ask follow-up':'Send'}</button></form><p class="composerHelp">${composerHelp}</p><div class="applicationNavigation"><span class="small muted">${done?'You can continue when you are ready.':'Complete this question to continue'}</span>${final?`<button class="btn ${done?'':'ghost'}" ${busy||!done?'disabled':''} onclick="finishLecture()">${lecture===3?'View course progress':'Continue to Lecture '+(lecture+1)} →</button>`:`<button class="btn ${done?'':'ghost'}" ${busy||!done?'disabled':''} onclick="navigateQuiz(1)">Next question →</button>`}</div></div></section></section>`;
}
function chooseOption(key,value) {
  const q=currentQuestions()[cursor];
  if(busy||pendingRequest()||!q||questionKey(q)!==key||resolved(q)||!q.options.some(option=>option[0]===value))return;
  local.choices[key]=value;
  save();
  const button=document.getElementById('submitChoice');
  if(button)button.disabled=false;
}
async function submitChoice() {
  if(busy||pendingRequest())return;
  const q=currentQuestions()[cursor];
  if(!q||resolved(q))return;
  const key=questionKey(q),answer=local.choices[key],option=q.options.find(o=>o[0]===answer);
  if(!option)return;
  pendingReply={type:'project',key,text:option};
  await perform(async()=>{await api('/api/answer',{lecture,question_id:q.id,answer,kind:'selection'});});
}
function saveDraft(key,value) { local.drafts[key]=value; save(); }
function conceptRequest(message) {
  const review=local.applicationReview;
  return {lesson_index:index,message,...(review?.lecture===lecture?{review_question_id:review.question_id}:{})};
}
async function sendChat() {
  const key=`chat:${index}`,message=(local.drafts[key]||'').trim();if(!message||busy||pendingRequest())return;
  pendingReply={type:'concept',key:String(index),text:message};
  await perform(async()=>{await api('/api/concept',conceptRequest(message));});
}
async function resetChat() {
  if(busy||pendingRequest())return;
  await perform(async()=>{await api('/api/concept',conceptRequest('/reset'));},'Resetting this concept discussion…');
}
async function submitAnswer() {
  if(busy||pendingRequest())return;
  const q=currentQuestions()[cursor];
  if(!q)return;
  const key=questionKey(q),answer=(local.drafts[key]||'').trim();
  if(!answer){error='Type your question or response first.';render();return;}
  const followUp=resolved(q);
  pendingReply={type:'project',key,text:answer,followUp};
  await perform(async()=>{await api('/api/answer',{lecture,question_id:q.id,answer,kind:followUp?'follow_up':'message'});});
}
function navigateQuiz(direction) {
  if(busy)return;
  const qs=currentQuestions();
  if(direction>0&&!resolved(qs[cursor]))return;
  openQuestion(Math.max(0,Math.min(qs.length-1,cursor+direction)));
}
function finishLecture() { const p=lectureProgress(lecture);if(busy||!p?.total||p.resolved!==p.total)return;if(lecture===3)showProgress();else go(lessons.findIndex(x=>x.lecture===lecture+1)); }
let lastRenderedConcept=null;
function render() {
  scopeLectureConversations();
  document.body.dataset.view=view;
  const changedConcept=view==='learn'&&lastRenderedConcept!==index;
  const reader=!changedConcept&&view==='learn'?app.querySelector('.readingContent'):null;
  const readingScroll=reader?.scrollTop||0;
  const expandedSections=reader?[...reader.querySelectorAll('details[open]')].map(details=>details.querySelector('summary')?.textContent):[];
  lastRenderedConcept=view==='learn'?index:null;
  document.body.classList.toggle('hideLessons',['home','slides','progress','instructor','history'].includes(view));
  document.body.classList.toggle('learningView',view==='learn'||view==='quiz');
  document.body.classList.toggle('projectView',view==='quiz');
  document.getElementById('headerSwitcher').innerHTML='';
  const account=document.getElementById('accountBar');if(account)account.innerHTML=course?.username?`<span title="${esc(course.username)}">${esc(course.username)}</span><button onclick="signOut()" ${busy?'disabled':''}>Sign out</button>`:'';
  document.querySelectorAll('.topActions>[data-view]').forEach(button=>{
    const active=button.dataset.view===view;button.classList.toggle('active',active);
    if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');
    button.disabled=busy;
  });
  app.innerHTML=recoveryNotice()+(error?`<div class="warning" role="alert">${esc(error)}</div>`:'')+(view==='learn'?renderLearn():view==='intro'?renderIntro():view==='quiz'?renderQuiz():view==='progress'?renderProgress():view==='instructor'?renderInstructor():view==='history'?renderHistory():view==='slides'?renderSlides():renderHome());
  if(reader) {
    const nextReader=app.querySelector('.readingContent');
    nextReader?.querySelectorAll('details').forEach(details=>{if(expandedSections.includes(details.querySelector('summary')?.textContent))details.open=true;});
    if(nextReader)nextReader.scrollTop=readingScroll;
  }
  drawSidebar();
  const drawer=document.getElementById('lessonDrawer'),open=document.body.classList.contains('drawerOpen');
  drawer.inert=!open;drawer.setAttribute('aria-hidden',String(!open));
  if(pendingRequest())app.querySelectorAll('button:not([data-recover]),input:not([data-recover]),textarea,select').forEach(control=>control.disabled=true);
  save();
  updateLayoutMetrics();
  if(view==='learn'||view==='quiz')loadLectureConversation(lecture);
  if(changedConcept)window.scrollTo({top:0,left:0,behavior:'instant'});
}
function updateLayoutMetrics() {
  document.documentElement.style.setProperty('--header-height',`${document.querySelector('.top').getBoundingClientRect().height}px`);
  document.documentElement.style.setProperty('--context-height',`${document.querySelector('.courseContext')?.getBoundingClientRect().height||0}px`);
}
window.addEventListener('resize',()=>requestAnimationFrame(updateLayoutMetrics));
function messageBubble(message) {
  return `<div class="bubble ${message.role==='user'?'student':'assistant'}" aria-label="${message.role==='user'?'Student':'Teaching assistant'}">${message.role==='user'?'':'<div class="messageAuthor">AI Teaching Assistant</div>'}${format(message.content)}</div>`;
}

function viewAssignedQuestion() {
  const box=document.getElementById('chatMessages'),question=document.getElementById('assignedQuestion');
  if(!box||!question)return;
  box.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  question.focus({preventScroll:true});
}

function openQuestion(position) {
  if(busy||!Number.isInteger(position))return;
  const qs=currentQuestions(),active=qs.findIndex(q=>!resolved(q));
  if(position<0||position>=qs.length||(active>=0&&position>active))return;
  cursor=position;error='';render();
}

(async()=> {
  try {
    const {response,result:lessonData}=await requestJson('/lessons.json',{},15000);if(!response.ok)throw new Error('Course materials could not be loaded.');lessons=lessonData;
    try {const {response,result}=await requestJson('/api/materials',{},15000);if(response.ok)materials=result;} catch { /* The lessons remain readable while materials reconnect. */ }
    if(local.token)await api('/api/session');
  } catch(e) {error=e.message||'Start the Python server and open http://127.0.0.1:8000.';}
  render();
})();
