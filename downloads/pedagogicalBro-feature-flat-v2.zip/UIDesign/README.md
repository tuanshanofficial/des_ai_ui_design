# Live DES course UI

## Reference-based desktop layout (2026-10-29)

Replaced competing desktop overrides with one responsive layout system. Course
pages use the navy reference header, full-width workspaces, proportional type,
and page-specific grids: paired lesson/tutor panels with pinned controls,
two-column project introduction with a shared action bar, three lecture progress
cards below the totals, and instructor package editing beside summary cards.
Home follows the separate white reference: simple header, welcome/resume actions,
a divider, and three outlined-icon learning steps. Existing welcome wording and
navigation are retained; the original course description is available under
About this course. Course content, state, APIs, question selection and pedagogical
logic are unchanged.

Verified in hidden Chrome at 1157 x 830, 1366 x 768, 1600 x 900, 1660 x 960,
1920 x 1080 and 3802 x 1893, plus mobile overflow checks. Reviewed captured Home,
lesson, project introduction, progress and instructor screenshots against the
references. Browser checks cover independent scrolling, anchored actions and
composer, navigation/progression, session persistence, question tables and failure
recovery with a controlled test model. These are UI checks, not live-model
pedagogical evaluation. All 145 repository tests pass.

Screenshots are local ignored artifacts in `.tutor_data/`, including
`unified_home_1157x830.png`, `natural_events_1660x960.png`, and
`unified_{intro,progress,instructor}_1660x960.png`.


## Latest supplied references

The learning page now puts the concept title in its page header, with lecture
context above it, and removes the duplicate title from the reading card. Tutor
context names the current concept. Its aligned panels, SVG icons, fixed lesson
footer and fixed chat composer remain intact. Project briefing panels align
above a bottom action bar with Back on the left and Start/Return on the right.

Home now follows the supplied simple top-to-bottom structure: original welcome
copy and session controls, a divider, and the three horizontal learning steps.
The former tall side-by-side home tiles are removed. Navy course branding,
original wording and the instructor navigation remain. Typography and table
padding were tightened to follow the supplied compact reading hierarchy.

Browser screenshots and checks passed across 1366x768, 1600x900, 1920x1080,
2560x1440 and 3802x1893, including short/long concepts, briefing, progress,
instructor, application MCQs and tables. Screenshots were reviewed. All 145
repository tests passed. Pedagogical logic and backend files were not modified.


## Page-specific compositions

Home now presents the original welcome text beside the three-step learning path
within one coherent frame, followed by a compact About strip. The project
introduction has a briefing column, instructions column and grouped bottom
navigation. Progress groups its heading beside saved totals, with three lecture
cards and accessible review actions. Instructor uses a form column and a
separate package/course summary sidebar. Application uses a coherent reading
and conversation width aligned with its fixed composer. Existing concept-panel
alignment, internal scrolling and pinned controls are preserved.

The latest browser run covers every view, including the previously missed
introduction, at five desktop resolutions from 1366x768 to 3802x1893. Actual
screenshots were reviewed. Checks include distinct column bounds, page extent,
no horizontal overflow, saved progress, instructor file/review controls, and
Back/Start briefing navigation to the original fixed assignments. All 145
repository tests passed. Original course text, assignments, history and tutor
logic are preserved; only noneducational grouping headings/wrappers were added.
Screenshots: .tutor_data/unified_home_*, unified_intro_*, unified_progress_*,
unified_instructor_* and unified_application_*.


## Viewport-filling page structure

Every desktop route now owns the available viewport beneath the header. Home
uses the remaining height for its two content sections; progress keeps its
summary visible while the lecture list scrolls; instructor uses a scrolling
package body with visible action buttons and a compact Current course row.
Project and concept views retain their fixed controls and internal scrolling.
Browser checks explicitly verified page and workspace bottom bounds, no outer
page scrolling, no horizontal overflow, and visible instructor/project controls
at five resolutions from 1366x768 through 3802x1893. All 145 repository tests pass.
The implementation adds only presentation wrappers / a view data attribute;
course content, persistence, grading and pedagogical logic remain unchanged.


## Consistent styling across all course views

The homepage, Course Progress, Instructor Portal, project introduction and
project application now share the concept page's responsive reading/control
scale, navy header, panel spacing and readable table styling. Original homepage
wording, saved progress, assignment/assessment behavior and instructor preview
limitations are preserved.

Project application uses a viewport-height flex layout with only its question
and conversation thread scrolling. The reply composer, question shortcut and
Next/Continue controls remain anchored. MCQs and supplied tables remain in the
same conversation. The SVG robot avatar is shared with concept chat.

Browser checks and screenshots cover home, progress, instructor, application
MCQs and table questions at 1366x768, 1600x900, 1920x1080, 2560x1440 and
3802x1893. Checks verify no horizontal page overflow, anchored project controls,
working progress rows, preserved preview controls, and earlier learning flows.
Screenshots are saved as `.tutor_data/unified_*`. All 145 repository tests pass.
These are frontend checks with a controlled model, not new live-model grading.


## Fixed lesson controls and centered question markers

The lessonDocument is now a full-height flex column: only readingContent scrolls,
while Previous / Mark complete remain outside that scroll area at the bottom.
Suggested-question markers now use an inline SVG instead of a question-mark
font glyph, eliminating inherited baseline offsets. Browser checks confirm
unchanged footer position during scrolling and centered SVG bounds from
1366x768 through 3802x1893. No tutor logic or educational content changed.


## Latest alignment correction

Both learning panels now share the remaining viewport height. The lesson card
scrolls internally, with navigation directly after its educational content;
the tutor conversation scrolls separately with its composer anchored below.
The former font-glyph avatar has been replaced with a self-contained SVG robot.
Browser checks verify matching top/bottom edges, reachable navigation, and SVG
avatar rendering across 1366x768 through 3802x1893. This supersedes the previous
natural-height/sticky-tutor descriptions. Educational content and logic remain
unchanged.

## Current learning layout: natural document and sticky tutor

The learning workspace remains full-width with 32px margins and a 60/40 grid.
The Concept Materials card is content-sized: a shared `.lessonDocument` aligns
headings, paragraphs, examples, Key Idea and navigation on one reading grid.
The reader no longer has a viewport height or its own vertical scrollbar.
Navigation follows the final section with a 24px gap, divider and full buttons.
Long lessons use ordinary page scrolling; shorter lessons end sooner.

The tutor independently uses `position: sticky`, with a viewport-sized card,
internal conversation scrolling and an anchored composer. The learning header
stays visible. Neither card is stretched to match the other's height. Switching
concepts starts at the top of the new document without changing saved state.

Browser verification covered short (Entities, attributes, and activities), long
(Why study simulation?), table (Building a simulation table), and active-chat
pages at 1366x768, 1600x900 and 1920x1080. Top and footer screenshots were captured;
review verified natural heights, coherent content widths, sticky chat/input,
fully accessible navigation and no horizontal overflow. The measured footer
gap was 24px at each size. Course text was compared with the source HTML.
Results: `.tutor_data/natural_layout_checks.json`; screenshots:
`.tutor_data/natural_*`. UI calls used a controlled model. All 145 repository
tests pass, and the production tutor hash still matches the 17-scenario report.

Earlier equal-height / fixed-reader descriptions below record prior iterations
and are superseded by this layout.


From the AI directory, double-click `start_tutor.cmd` or run:

```powershell
& C:\Users\wzzhx\anaconda3\python.exe -B tutor_web.py
```

Open **http://127.0.0.1:8000**. Keep the terminal running. Stop it with Ctrl+C.
Use `--port 8001` if port 8000 is occupied. Opening `index.html` directly is no
longer sufficient: the Python backend owns tutoring, assessment and progress.

Use the existing Python environment with `openai`, `python-dotenv`,
`sentence-transformers`, `faiss-cpu`, `numpy`, and `rank-bm25`. The backend uses
the existing `.env` entries `CARLETON_RCS_URL`, `CARLETON_RCS_API_KEY`, and
`CARLETON_MODEL`. No credentials are sent to the browser. The first concept
request loads the existing dense+BM25 retriever; later requests reuse it.

## Learning flow

1. Lecture 1 concepts, with live student-led TA discussion on each page.
2. Lecture 1 project introduction and seven assigned questions.
3. Lecture 2 concepts, introduction and seven assigned questions.
4. Lecture 3 concepts, introduction and nine assigned questions.

The original landing-page content is retained, with a full-width responsive
layout. Typography, spacing and controls scale with desktop and mobile screens.
Concept and project workspaces use the available viewport, with an animated
`...` inside the chat during generation.
Both use “Type your question or response…”; Enter sends and Shift+Enter adds a
line break. MCQs retain option selection and also accept typed replies to the
TA's guiding questions or a correct explanation in words.

Students mark each concept complete in order using **Mark complete & continue**.
Every concept in a lecture must be marked complete before application unlocks;
the backend enforces this even for direct requests. This records the learner's
completion action, not an AI-verified mastery judgment. Older sessions retain
their selected questions/answers but need to record concept completion before
reopening application, since the earlier UI did not track that action.

**Course Progress** opens a dedicated dashboard using saved server data: concept
and application counts, correct answers, completion with support, lecture locks,
and links to resume or review work. Visiting it does not replace the student's
last learning location. It also handles browsers without a saved session.

**Instructor Portal** restores the project-specification and bulk-question-bank
package interface. File selection/review previews filenames locally. Login,
uploading, validation and publishing are not implemented, and the Publish button
is disabled. The preview does not expose instructor answer keys to the browser.

The server draws one random variant per learning-objective pool and shuffles
the selected questions within each lecture. Selection is fixed for that session.
The complete banks contain 24, 22 and 27 items, read from
`../Document/Project/Lecture_1.docx`, `Lecture_2.docx`, and `Lecture_3.docx`
relative to the AI directory. Tables and shared pool assumptions, including
financial input values, are preserved. Instructor answers and rubrics remain
server-side; they are not embedded in HTML or public question responses.

The TA presents the assigned prompt; it does not invent extra project quizzes.
Multiple-choice option submissions use the stored key. A separate fresh model request
assesses short answers against the selected rubric, accepting equivalent valid
reasoning. Typed MCQ followups also use that assessor, with the actual preceding
guiding dialogue. A correct guiding step does not itself imply full-task mastery
or consume an unsuccessful attempt; genuine clarification requests likewise do
not count as failed answers. Insufficient written replies receive the production policy's separate,
evidence-validated prerequisite-gap decision. A selected MC option alone is not
evidence of a separate prerequisite gap. Generated support undergoes internal
review before being displayed. Four unsuccessful attempts receive support; the
fifth shows the instructor explanation. Genuine prerequisite-help requests do
not consume an attempt.

**Progression assumption:** every assigned question must be resolved before the
next lecture unlocks. Resolution can be an independently correct answer or
completion with the five-attempt explanation. These are labeled and counted
separately; completion with support never counts as demonstrated mastery. This
default follows the existing five-attempt policy and is shown in the UI.

Earlier concepts and completed answers remain accessible. Drafts and a session
token are retained in this browser; assignments, attempts, replies and progress
are retained in `.tutor_data/sessions.sqlite3`. Refreshing or restarting the
server does not reroll questions. Starting a new session intentionally draws a
new set. Concept discussions are isolated by page and student session; resetting
a discussion does not reset assignments. This is a local, single-machine app,
without instructor login, student account authentication or upload management.

## Implementation and validation

- `tutor_web.py`: local HTTP server, persistent sessions, project assessment,
  and adapter to unchanged `des_rag_policy_v3.py` for concept chat.
- `course_bank.py`: instructor DOCX extraction and explicit public-field filter.
- `index.html`, `lessons.json`, `app.js`, `live-layout.css`: original course
  material, live UI and viewport/chat layout.
- `test_tutor_web.py`: bank integrity, one-per-pool selection, persistence,
  lecture gating, counter threshold, help requests, idempotent retry, failed-turn
  isolation, session isolation and HTTP asset boundaries.

Requests commit only after a complete response. Upstream/review failures retain
the draft and leave the attempt/progress unchanged. Retrying a request whose
response was lost does not count the same submission twice. Model calls are
serialized in this local prototype; the UI shows typing dots inside the active conversation.

Run checks from the AI directory:

```powershell
python -B -m pytest -q -p no:cacheprovider
```

The earlier 17-scenario tutor report applies to the unchanged production tutor.
It does not establish that this new web/project adapter or every lecture item
has passed that live evaluation. Controlled-model browser checks and actual
API connectivity smoke checks are separate from pedagogical compliance grading.


## Approved interface layout

The navy header stays prominent across Home, Course Progress, Instructor Portal,
concept lessons and project application. The desktop workspace fills the available width with 32-pixel outer margins.
Text retains readable line lengths and consistent type sizes; smaller screens stack the panels and controls.
The original homepage wording and three-step course journey are preserved.

Concept pages pair the reading panel with a separate TA discussion. Application
uses one conversation: the assigned question, supplied tables, MCQ options,
student replies and TA guidance appear in that thread. Written replies remain
available for MCQs. Tables retain their numbered blanks; students answer in chat.
View assigned question scrolls back to the original task. Question history opens
completed questions or the current question, without permitting future skips.

Course Progress uses saved totals and three compact lecture rows. Instructor
Portal remains a clearly marked local package preview; publishing is disabled.

The latest reference uses compact navigation, a roughly 61/39 reading/chat
split, a divider below the lesson title, shaded worked examples with tables,
and an icon-led key-idea callout. Concept completion controls stay visible
while the reading content scrolls. Empty concept chats show a welcome and three
suggested questions; clicking one sends it through the normal tutor endpoint.
The composer displays the Enter / Shift+Enter keyboard guidance.

The desktop learning page uses a viewport-height flex column. Its header and
lecture row keep their natural heights; the shared 60/40 panel grid fills the
remaining space without a maximum width or height. Reading and conversation
children scroll independently with min-height: 0. The lesson footer and composer
remain outside those scrolling children. The first concept omits Previous.

## Desktop reading refinement

Presentation changes are scoped to `.lessonWorkspace`: lesson paragraphs are
17px with 1.7 line height and an 80ch reading measure, headings are 29px/20px,
tables are 15px with padded cells and content-based widths, key ideas are 16px,
and chat messages are 16px. The full-viewport 60/40 grid and anchored footer /
composer remain unchanged. Concept suggestions no longer mention the airport
project. No course content, backend logic, homepage, portal or application-page
styling was changed in this refinement.

Browser checks covered 1366x768, 1600x900 and 1920x1080 using:
- Short: Entities, attributes, and activities.
- Long: Why study simulation?
- Additional tables: Single-server simulation; Building a simulation table.

At each size the checks verify aligned cards, viewport bounds, readable type,
no horizontal overflow, visible navigation/input, unchanged lesson text, and
scrolling when content exceeds the reading area. Twelve actual screenshots were
captured; short and long pages were visually reviewed across all three sizes.
Checks use a controlled model for UI requests, not live pedagogical grading.
All 145 repository tests passed. Screenshots and measured browser results are in
`.tutor_data/refined_*` and `.tutor_data/desktop_refinement_checks.json`.
Shorter viewports still require scrolling for some examples and suggested
questions; those remain accessible within the panels, without outer scrolling.

## Large-screen scale correction

The concept page now scales its reading text, headings, tables, chat text,
controls and avatars together. Body text is 20px at 1600px wide and rises to
30px on the 3802px-wide display shown in the user screenshot. The coherent
reading grid expands to 110ch instead of the former narrow 86ch cap. Natural
lesson height, document scrolling, the sticky tutor and 60/40 columns remain.
These changes are scoped to learning pages; no course content or backend code
was changed. Browser checks and screenshots cover 1366x768, 1600x900, 1920x1080,
2560x1440 and 3802x1893, including Events and system state. All layout checks
passed, with no horizontal overflow and accessible navigation and chat input.
