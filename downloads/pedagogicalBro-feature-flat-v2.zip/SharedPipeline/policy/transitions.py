"""Pure, deterministic transitions for the README's teaching policy.

Model calls and question generation belong to the caller. A transition returns a
new immutable state, so callers can commit it only after generation succeeds.
"""

from dataclasses import dataclass, replace
from enum import Enum


class Phase(str, Enum):
    NEW = "new"
    APPROACH = "approach"
    GUIDING = "guiding"
    APPLICATION = "application"
    COMPLETED = "completed"


class Intake(str, Enum):
    BASIC = "basic"
    SCENARIO = "basic_scenario"
    CLARIFICATION = "clarification"
    GUIDANCE = "assessment_guidance"
    DIRECT = "direct_solution"


class Understanding(str, Enum):
    SUFFICIENT = "sufficient"
    NOT_SUFFICIENT = "not_sufficient"
    # Accepted for stored records and older integrations; live diagnosis is binary.
    PARTIAL = "partial"
    INSUFFICIENT = "insufficient"
    UNKNOWN = "unknown"


class Review(str, Enum):
    INCORRECT = "incorrect"
    OUT_OF_SCOPE = "out_of_scope"
    AMBIGUOUS = "too_ambiguous"
    APPROPRIATE = "appropriate"


class Action(str, Enum):
    EXPLAIN = "explain_and_assess"
    SCENARIO_INTRO = "scenario_intro"
    ASK_APPROACH = "ask_approach"
    REFUSE = "refuse_and_hint"
    INITIAL_HINT = "initial_hint"
    HINT = "give_hint"
    FOUNDATION = "foundational_support"
    APPLICATION = "ask_application"
    COMPLETE = "complete"
    PROJECT_COMPLETE = "project_complete"
    EXPLAIN_ANSWER = "full_explanation"
    EXPLAIN_AND_APPLY = "full_explanation_and_application"
    CLARIFY = "clarify"
    REGENERATE = "regenerate"
    REPAIR = "repair_incorrect"
    REPHRASE = "rephrase"
    KEEP = "keep_and_hint"


@dataclass(frozen=True)
class State:
    objective: str = ""
    phase: Phase = Phase.NEW
    failed_attempts: int = 0
    outcome: str = "in_progress"
    kind: str = "conceptual"

    def __post_init__(self) -> None:
        if not isinstance(self.phase, Phase):
            raise ValueError("State phase must be a Phase value.")
        if type(self.failed_attempts) is not int or self.failed_attempts < 0:
            raise ValueError("Failed attempts must be a nonnegative integer.")
        if self.kind not in ("conceptual", "project"):
            raise ValueError("State kind must be conceptual or project.")


@dataclass(frozen=True)
class Decision:
    state: State
    action: Action
    replace_question: bool = False


# The revised policy invokes a full explanation on the fifth failed answer.
MAX_FAILED_ATTEMPTS = 5
_ASSESSABLE_PHASES = (Phase.APPROACH, Phase.GUIDING, Phase.APPLICATION)
_PRACTICE_PHASES = (Phase.GUIDING, Phase.APPLICATION)


def start(
    objective: str,
    intake: Intake,
    diagnosis: Understanding | None = None,
    *,
    approach_provided: bool = False,
    prerequisite_missing: bool = False,
) -> Decision:
    """Begin a new objective using the intake route from the source policy.

    An initial clarification can supply evidence of understanding, but is not a
    failed answer to a tutor question. Missing evidence requests clarification.
    """
    if not isinstance(objective, str) or not objective.strip():
        raise ValueError("A nonempty learning objective is required.")
    if not isinstance(intake, Intake):
        raise ValueError("Intake must be an Intake value.")
    if diagnosis is not None and not isinstance(diagnosis, Understanding):
        raise ValueError("Diagnosis must be an Understanding value or None.")
    if type(approach_provided) is not bool:
        raise ValueError("approach_provided must be a boolean.")
    if type(prerequisite_missing) is not bool:
        raise ValueError("prerequisite_missing must be a boolean.")

    state = State(objective=objective.strip(), phase=Phase.GUIDING,
                  kind="project" if intake in (Intake.GUIDANCE, Intake.DIRECT) else "conceptual")
    if intake is Intake.BASIC:
        return Decision(state, Action.EXPLAIN, replace_question=True)
    if intake is Intake.SCENARIO:
        return Decision(replace(state, phase=Phase.APPLICATION), Action.SCENARIO_INTRO,
                        replace_question=True)
    if intake is Intake.GUIDANCE and not approach_provided:
        return Decision(replace(state, phase=Phase.APPROACH), Action.ASK_APPROACH)
    if intake is Intake.DIRECT:
        return Decision(replace(state, phase=Phase.APPROACH), Action.REFUSE)
    return assess(
        state,
        diagnosis or Understanding.UNKNOWN,
        count_attempt=False,
        prerequisite_missing=prerequisite_missing,
    )


def assess(
    state: State,
    diagnosis: Understanding,
    *,
    count_attempt: bool = True,
    prerequisite_missing: bool = False,
) -> Decision:
    """Choose support, application, or completion from validated evidence.

    Unsuccessful answers during adaptive support count toward the safeguard,
    including responses to a hint without a formal question. The caller excludes
    intake diagnosis and nonanswers. Initial approach elicitation never counts.
    Failures remain attached to the current objective/question across support modes.
    """
    if state.phase not in _ASSESSABLE_PHASES:
        raise ValueError(f"Cannot assess a session in phase '{state.phase.value}'.")
    if not isinstance(diagnosis, Understanding):
        raise ValueError("Diagnosis must be an Understanding value.")
    if type(count_attempt) is not bool:
        raise ValueError("count_attempt must be a boolean.")
    if type(prerequisite_missing) is not bool:
        raise ValueError("prerequisite_missing must be a boolean.")

    if diagnosis is Understanding.UNKNOWN:
        return Decision(state, Action.CLARIFY)

    if diagnosis is Understanding.SUFFICIENT:
        if state.phase is Phase.APPLICATION or state.kind == "project":
            return Decision(
                replace(state, phase=Phase.COMPLETED, outcome="demonstrated"),
                Action.PROJECT_COMPLETE if state.kind == "project" else Action.COMPLETE,
            )
        return Decision(
            replace(state, phase=Phase.APPLICATION, failed_attempts=0),
            Action.APPLICATION,
            replace_question=True,
        )

    failed_attempts = state.failed_attempts
    counted_failure = count_attempt and state.phase in _PRACTICE_PHASES
    if counted_failure:
        failed_attempts += 1
    if counted_failure and failed_attempts >= MAX_FAILED_ATTEMPTS:
        if state.phase is Phase.GUIDING and state.kind != "project":
            return Decision(
                replace(state, phase=Phase.APPLICATION, failed_attempts=0),
                Action.EXPLAIN_AND_APPLY,
                replace_question=True,
            )
        return Decision(
            replace(
                state,
                phase=Phase.COMPLETED,
                failed_attempts=failed_attempts,
                outcome="explained_not_verified",
            ),
            Action.EXPLAIN_ANSWER,
        )

    next_state = replace(
        state,
        phase=Phase.GUIDING if state.phase is Phase.APPROACH else state.phase,
        failed_attempts=failed_attempts,
    )
    action = Action.FOUNDATION if prerequisite_missing else Action.HINT
    return Decision(next_state, action)


def review(state: State, result: Review) -> Decision:
    """Review an active question or hint without changing teaching progress.

    Every review outcome returns the exact saved state, including the failure
    counter. The caller checks that a question or hint exists and preserves the
    diagnosed understanding and complete previous interaction history.
    """
    if state.phase not in _ASSESSABLE_PHASES:
        raise ValueError(f"Cannot review a question in phase '{state.phase.value}'.")
    if not isinstance(result, Review):
        raise ValueError("Review result must be a Review value.")
    if result is Review.INCORRECT:
        return Decision(state, Action.REPAIR, replace_question=state.phase in _PRACTICE_PHASES)
    if result is Review.OUT_OF_SCOPE:
        return Decision(
            state,
            Action.REGENERATE,
            replace_question=state.phase in _PRACTICE_PHASES,
        )
    if result is Review.AMBIGUOUS:
        return Decision(state, Action.REPHRASE)
    return Decision(state, Action.KEEP)
