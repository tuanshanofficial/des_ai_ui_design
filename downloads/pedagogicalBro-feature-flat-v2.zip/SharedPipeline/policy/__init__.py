"""Deterministic pedagogical state transitions."""
