# Supported AI TA pipeline

```text
student browser / CLI
  -> execution: TutorSession, transactional turn and retained student evidence
  -> processing: fixed instructor project context and complete-request budget
  -> retrieval: selected textbook corpora -> MiniLM query embedding / BM25
                -> global reciprocal rank fusion -> bounded cited sources
  -> providers: intake / reply classification -> diagnosis -> prerequisite check
  -> policy: Python chooses next teaching action
  -> providers: generation -> shape, question-mode and citation validation
  -> execution: commit state and expose the final reply

reference-answer workspace
  -> question + retrieved sources -> isolated answer generation
  -> candidate + separately stored reference -> reproducible NLP similarity
  -> export of answers, provenance, component scores and failures
```

## Boundaries

| Folder | Responsibilities |
| --- | --- |
| `execution` | CLI bootstrap and `TutorSession`; command routing, cumulative evidence, review, atomic turn commit. |
| `processing` | Project JSON validation, complete wire-input budgets, lossless repeated-context references, safe shared errors. |
| `policy` | Immutable learning state and deterministic transitions; beginner teaching contracts derived from the latest main prototype. |
| `providers` | Provider configuration and transport; strict JSON parsing and validated task contracts. No teaching state mutation. |
| `retrieval` | Read-only corpus/index loading, query embeddings, BM25, global ranking, parent deduplication, and source context. |
| `../webui` | Browser presentation, HTTP/SSE coordination and the instructor evaluation workspace. |

The root `pedagogical_tutor` package aliases these modules for existing imports.
No separate copy of the teaching implementation is maintained there. The original
`python -m pedagogical_tutor` and `des_rag_policy_v2.py` entry points remain supported.

## Teaching state and diagnosis

`State.kind` distinguishes conceptual learning from designated-project work.
`State.phase` is `new`, `approach`, `guiding`, `application`, or `completed`;
it is independent of the instructor-defined project stage. Basic scenario intake
starts application in the original scenario. Basic definition intake creates a
conceptual assessment. Clarification does not insert an unnecessary initial quiz.

Live understanding diagnosis requests `sufficient`, `not_sufficient`, or `unknown`.
`not_sufficient` always triggers a second model operation, `prerequisite_gap`.
The gap output is either `missing=false`, or `missing=true` with a distinct concept,
an exact student quote, and a reason it is a separate foundation. The quote must
occur in a current or retained student message; quoting the tutor is rejected.
Historical `partial` and `insufficient` records remain accepted by the compatibility
adapter, with their strictly validated legacy prerequisite flag.

Sufficient conceptual assessment/clarification moves to a new independent application
scenario. Sufficient application concludes. Sufficient project reasoning concludes
the current local project step. The same distinction applies after five failed
assessed replies: conceptual support explains and moves to application; application
and project support explain and conclude as `explained_not_verified`.

Students can use natural explicit review requests or `/review [reason]`.
`incorrect` takes priority over `out_of_scope`, then `too_ambiguous`; otherwise retain
the prompt and add a hint. Review preserves the exact state and all earlier evidence.
It neither diagnoses the student again nor consumes an attempt.

## Retrieval and embeddings

The supplied indexes use `sentence-transformers/all-MiniLM-L6-v2` (384 dimensions).
`HybridRetriever.from_textbooks(root, book_count=3, method="dual")` accepts the
repository root, `AI_TA_PYTHON_CODE`, or `textbook`. One embedder is shared across
all books. A combined index exists only in memory. Passage and parent identifiers
are namespaced by textbook before global dense and BM25 ranking, preventing ID
collisions and chapter mixing across books.

Both retrieval factories explicitly load SentenceTransformer on the CPU. Automatic
Apple MPS selection caused a native Metal command-buffer abort when MiniLM retrieval
and MPNet answer scoring ran concurrently. Torch and FAISS also bundle different
OpenMP runtimes on macOS. FAISS runs in a dedicated spawned process, while CPU
MiniLM and MPNet stay in the parent process. One worker owns all selected textbook
indexes and the combined index. Read/add/reconstruct/search operations and numerical
rankings remain FAISS operations; only paths and NumPy arrays cross the local pipe.
The worker is closed on parent exit; timeouts or worker exits become ordinary Python
errors instead of terminating the tutor. Application startup must remain inside an
`if __name__ == "__main__"` guard so spawning cannot rerun model setup in the child.

`dual` fuses the two rankings using reciprocal ranks. `semantic` makes no BM25
query. `bm25` makes no query-embedding or dense-search call, although startup still
loads and validates the supplied indexes and shared model. Only positive finite
BM25 hits count. Sources are deduplicated by parent, numbered globally, and bounded
to 18,000 characters including headers and labeled excerpt truncation.

All books are checked for record IDs, parent mapping, vector count, and dimension.
Present manifests (books 2 and 3) additionally verify embedding model, normalization,
passage order, and SHA-256 hashes. Book 1 lacks a manifest: structural checks cannot
prove its original model identity or vector ordering. Retrieval relevance and
multilingual quality are not calibrated by these structural checks.

The separate answer benchmark can wrap this loaded corpus with
`FocusedRetriever` in `retrieval/focused.py`. It reuses the CPU encoder and isolated
FAISS worker, combines 60 candidates per dense/sparse channel, removes fixed
question/function words from the sparse query, and ranks question-concept coverage,
phrases and nearby definition cues before reciprocal ranks. It returns at most
three passage windows, with at most one adjacent passage each, bounded to 5,400
characters including headers. It uses no references, question IDs, answer-score
model or learned thresholds. The frozen configuration is exported as
`FOCUSED_CONFIG` with its hash. The original retriever and teaching sessions retain
their existing behavior; the benchmark explicitly records `legacy` or `focused`.

## Context, validation, and limits

Each complete model request is budgeted before transmission, including instructions,
project JSON, student evidence, retrieval, output allowance, and safety reserve.
Repeated content can be packed losslessly. Student evidence is not dropped or
summarized to make it fit. Unknown diagnoses, model errors, invalid JSON, unsupported
citations, and over-budget input leave the turn uncommitted.

Sessions remain in memory. A server restart does not migrate previous learning
state. Current shape/state/citation checks and beginner contracts do not prove the
semantic correctness of generated feedback. The upstream model-based response audit
and automatic rewrite loop have not been copied into the active controller; its
presence in the reference prototype is not presented as an active guarantee.

Offline tests validate behavior with injected providers and retrieval components.
They do not establish live endpoint access or model-generated teaching quality.
