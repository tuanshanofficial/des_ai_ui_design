# Reconciled teaching and execution flow

This flow follows the supported implementation reconciled with main `e235a3e`.
It supersedes older diagrams when they disagree about project completion, binary
diagnosis, scenario intake or incorrect-premise review. Historical PDFs are preserved.

```mermaid
flowchart TD
    Input[Student question] --> Intake{Request type}
    Intake -->|Definition| Lesson[Short definition and example]
    Lesson --> Concept[Conceptual assessment]
    Intake -->|Independent scenario| Scenario[Preserve requested scenario and ask a focused task]
    Intake -->|Conceptual clarification| Diagnose
    Intake -->|Project guidance| Approach{Approach supplied?}
    Intake -->|Direct project solution| Refuse[Decline direct solution and give an initial hint]
    Refuse --> Ask[Ask for current approach]
    Approach -->|No| Ask
    Approach -->|Yes| Diagnose
    Ask --> Reply{Meaningful approach demonstrated?}
    Reply -->|No| Initial[Initial hint]
    Initial --> Ask
    Reply -->|Yes| Diagnose
    Concept --> Answer[Student response]
    Scenario --> Answer
    Answer --> Diagnose{Understanding sufficient?}
    Diagnose -->|Unknown| Clarify[Clarify and preserve progress]
    Clarify --> Answer
    Diagnose -->|Yes| Destination{Current task}
    Destination -->|Conceptual assessment or clarification| Application[New application scenario on the same concept]
    Application --> Answer
    Destination -->|Application or local project step| Done[Conclude this interaction]
    Diagnose -->|No, assessed reply| Failures{Five unsuccessful assessed replies?}
    Failures -->|Yes| Explain[Explain the current local answer without claiming mastery]
    Explain --> Destination
    Failures -->|No| Gap{Separate prerequisite missing?}
    Diagnose -->|No, intake diagnosis| Gap
    Gap -->|Supported by actual student quote| Foundation[Explain only that prerequisite]
    Gap -->|No distinct foundation gap| Hint[Targeted unsolved hint]
    Foundation --> Answer
    Hint --> Answer
```

Intake diagnosis, approach elicitation, clarification and review do not count as
failed answers. New questions reset their question-specific counter. Review always
returns to the same interaction with its counter, diagnosis and evidence preserved:

```mermaid
flowchart LR
    Request[Explicit review request] --> Review{Check prompt}
    Review -->|Incorrect premise first| Repair[Repair the premise]
    Review -->|Out of scope| Replace[Replace within scope]
    Review -->|Ambiguous| Rephrase[Clarify wording]
    Review -->|Appropriate| Keep[Retain and add an unsolved cue]
    Repair --> Return[Return to same learning state]
    Replace --> Return
    Rephrase --> Return
    Keep --> Return
```

```mermaid
flowchart LR
    Web[Browser or CLI] --> Execution[Execution and retained evidence]
    Execution --> Processing[Project context and complete-request budget]
    Processing --> Retrieval[Selected textbooks: MiniLM and BM25]
    Retrieval --> Classification[Validated model diagnosis and separate prerequisite check]
    Classification --> Policy[Python teaching transition]
    Policy --> Generation[Model generation]
    Generation --> Validation[Question, criteria, citations and response validation]
    Validation --> Commit[Commit the complete turn]
    Commit --> Web
```

Reference-answer experiments have their own path: question plus optional textbook
evidence → fresh answer → local comparison with a separately stored reference →
JSON/CSV with provenance and independent metrics. Reference answers never enter
the generation request. This scoring does not evaluate teaching logic.
