"""Command-line entry point for the textbook tutor."""

import argparse
import os
import sys
from pathlib import Path

from ..processing.context import ContextBudget, ContextLimitError
from ..providers.llm import ChatTutorModel, ModelError
from ..providers.config import PROVIDERS, load_provider_env, resolve_provider
from ..processing.project import ProjectContext, load_project_context
from ..retrieval.hybrid import HybridRetriever
from .session import HELP, TutorSession


def _context_budget(context_window_tokens):
    if type(context_window_tokens) is not int or context_window_tokens <= 5120:
        raise ValueError("--context-window-tokens / DES_CONTEXT_WINDOW_TOKENS must be an integer greater than 5120.")
    return ContextBudget(context_window_tokens=context_window_tokens)


def build_session(data_dir, model=None, api_url=None, project_context=None, *,
                  context_window_tokens=32768, provider="carleton", book_count=None,
                  retrieval_method="dual"):
    budget = _context_budget(context_window_tokens)
    if book_count is not None and (type(book_count) is not int or book_count not in (1, 2, 3)):
        raise ValueError("book_count must be 1, 2, or 3.")
    if retrieval_method not in ("dual", "bm25", "semantic"):
        raise ValueError("retrieval_method must be dual, bm25, or semantic.")
    config = resolve_provider(provider, model, api_url)
    if not isinstance(project_context, ProjectContext):
        project_context = load_project_context(project_context)
    try:
        from openai import OpenAI
    except ImportError:
        raise RuntimeError("Install the runtime dependencies with: pip install -r requirements.txt") from None
    if book_count is None:
        options = {} if retrieval_method == "dual" else {"method": retrieval_method}
        retriever = HybridRetriever.from_directory(Path(data_dir), **options)
    else:
        retriever = HybridRetriever.from_textbooks(Path(data_dir), book_count=book_count,
                                                   method=retrieval_method)
    client = OpenAI(base_url=config.api_url, api_key=config.api_key, timeout=90.0, max_retries=1)
    return TutorSession(ChatTutorModel(client, config.model, context_budget=budget,
                                      provider=config.provider), retriever,
                        project_context=project_context)


def run(session, *, verbose=False, read=input, write=print):
    write("Adaptive DES tutor ready.\n" + HELP)
    while True:
        try:
            message = read("\nStudent: ")
        except (EOFError, KeyboardInterrupt):
            write("\nBye.")
            return 0
        if message.strip().lower() in ("quit", "exit", "q"):
            write("Bye.")
            return 0
        try:
            result = session.respond(message)
        except ContextLimitError as exc:
            write(f"{exc} Your previous learning state is unchanged.")
            continue
        except (ModelError, ValueError, RuntimeError) as exc:
            # Do not expose provider messages, credentials, or submitted student text.
            write(f"Tutor turn failed ({type(exc).__name__}). Your previous learning state is unchanged; retry your message.")
            continue
        if verbose and result.action:
            write(f"Action: {result.action.value} | Phase: {result.state.phase.value} | Failed attempts: {result.state.failed_attempts}")
            for source in result.sources:
                write(f"[Source {source.number}] {source.chapter_title} | PDF pages {source.page_start}-{source.page_end}")
        write("\nTutor:\n" + result.text)


def main(argv=None):
    # Load an explicitly selected file before evaluating environment defaults.
    # --help remains available without dependencies or a readable env file.
    arguments = sys.argv[1:] if argv is None else list(argv)
    env_parser = argparse.ArgumentParser(add_help=False)
    env_parser.add_argument("--env-file", type=Path)
    if "--help" not in arguments and "-h" not in arguments:
        env_args, _ = env_parser.parse_known_args(arguments)
        try:
            load_provider_env(env_args.env_file)
        except (ValueError, RuntimeError) as exc:
            env_parser.error(str(exc))
    parser = argparse.ArgumentParser(description="Run the README pedagogical policy with textbook RAG.")
    parser.add_argument("--env-file", type=Path,
                        help="explicit local .env file; existing environment values take priority")
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--book-count", type=int, choices=(1, 2, 3), default=3,
                        help="number of supplied textbooks to retrieve from (default: 3)")
    parser.add_argument("--retrieval", choices=("dual", "bm25", "semantic"), default="dual",
                        help="textbook retrieval method (default: dual)")
    parser.add_argument("--provider", choices=PROVIDERS,
                        default=os.environ.get("DES_LLM_PROVIDER", "carleton"),
                        help="carleton: institutional chat API; openai: official Responses API")
    parser.add_argument("--model", default=None, help="override the selected provider's model")
    parser.add_argument("--api-url", default=None, help="override the selected provider's API base URL")
    parser.add_argument("--project-context", type=Path, default=os.environ.get("DES_PROJECT_CONTEXT") or None,
                        help="instructor JSON describing the assigned DES project and current project stage")
    parser.add_argument("--context-window-tokens", type=int,
                        default=os.environ.get("DES_CONTEXT_WINDOW_TOKENS", "32768"),
                        help="instructor-configured model context window; must exceed 5120 (default: 32768)")
    parser.add_argument("--verbose", action="store_true", help="Show policy decisions and retrieved sources.")
    args = parser.parse_args(arguments)
    try:
        _context_budget(args.context_window_tokens)
    except ValueError as exc:
        parser.error(str(exc))
    try:
        options = {"context_window_tokens": args.context_window_tokens,
                   "book_count": args.book_count, "retrieval_method": args.retrieval}
        if args.provider != "carleton":
            options["provider"] = args.provider
        session = build_session(args.data_dir, args.model, args.api_url, args.project_context, **options)
    except (ValueError, RuntimeError, ImportError, OSError) as exc:
        if isinstance(exc, ValueError) and ("CARLETON_RCS_API_KEY" in str(exc) or "OPENAI_API_KEY" in str(exc)):
            parser.exit(2, f"{exc}\n")
        if isinstance(exc, ValueError) and "project" in str(exc).lower():
            parser.exit(2, f"{exc}\n")
        parser.exit(2, f"Tutor initialization failed ({type(exc).__name__}). Check dependencies, data files, and model availability.\n")
    return run(session, verbose=args.verbose)
