"""Transactional orchestration of retrieval, model calls, and policy transitions."""

from dataclasses import dataclass, replace
import re

from ..providers.llm import ModelError, ReplyKind
from ..policy.transitions import Action, Decision, Intake, Phase, State, Understanding, assess, review, start
from ..processing.project import ProjectContext


HELP = (
    "Ask a DES question to begin. Commands:\n"
    "/review [reason] - review the current question or hint\n"
    "/new <question> - start a different learning objective\n"
    "/reset - clear this session\n"
    "/help - show commands\n"
    "quit - exit"
)


@dataclass(frozen=True)
class TurnResult:
    text: str
    state: State
    action: Action | None = None
    sources: tuple = ()
    assessment: object = None
    review: object = None


class TutorSession:
    """Commit a turn only after every dependency and response check succeeds.

    History is the complete record of the current objective. history_turns limits
    ordinary generation's recent-history field, not the complete current-question
    dialogue sent alongside it or the complete history used for review.
    """

    def __init__(self, model, retriever, history_turns=12, project_context=None):
        if type(history_turns) is not int or history_turns < 1:
            raise ValueError("history_turns must be a positive integer.")
        if project_context is not None and not isinstance(project_context, ProjectContext):
            raise ValueError("project_context must be a ProjectContext value or None.")
        self.model = model
        self.retriever = retriever
        self.history_turns = history_turns
        self.project_context = project_context
        self.reset()

    def _project_payload(self):
        """Give each model call a fresh copy of the teacher's fixed context."""
        return self.project_context.to_dict() if self.project_context is not None else None

    def reset(self):
        self.state = State()
        self.history = []
        self.question = None
        self.criteria = ()
        self.question_dialogue = []
        self.current_prompt = None
        self.last_assessment = None

    def respond(self, message):
        message = message.strip()
        if not message:
            return TurnResult("Please enter a question or answer.", self.state)
        command, _, argument = message.partition(" ")
        command = command.lower()
        if command == "/help":
            return TurnResult(HELP, self.state)
        if command == "/reset":
            self.reset()
            return TurnResult("Conversation and learning state cleared.", self.state)
        if command == "/new" and not argument.strip():
            return TurnResult("Use /new followed by your new question.", self.state)
        if command.startswith("/") and command not in ("/new", "/review"):
            return TurnResult("Unknown command. Use /help for available commands.", self.state)
        reviewing = command == "/review"
        review_reason = argument.strip() or "Review the current question and hint."
        if reviewing and (not self.current_prompt or self.state.phase == Phase.COMPLETED):
            return TurnResult("There is no active question or hint to review.", self.state)

        fresh = command == "/new" or self.state.phase in (Phase.NEW, Phase.COMPLETED)
        state = State() if fresh else self.state
        history = [] if fresh else [dict(m) for m in self.history]
        question = None if fresh else self.question
        criteria = () if fresh else self.criteria
        dialogue = [] if fresh else [dict(m) for m in self.question_dialogue]
        current_prompt = None if fresh else self.current_prompt
        last_assessment = None if fresh else self.last_assessment
        if command == "/new":
            message = argument.strip()

        # Keep assessment retrieval on the objective, rather than an incorrect answer.
        retrieval = self.retriever.retrieve(message if fresh else state.objective)
        assessment = review_result = None
        reply_kind = None
        if not fresh and not reviewing:
            reply_kind = self.model.classify_reply(
                objective=state.objective, question=question, history=history, message=message,
                project_context=self._project_payload(),
            )
            if reply_kind == ReplyKind.REVIEW:
                if not current_prompt:
                    return TurnResult("There is no active question or hint to review.", self.state)
                reviewing = True
                review_reason = message
        if reviewing:
            review_result = self.model.review(
                objective=state.objective, question=question, criteria=criteria,
                dialogue=dialogue, history=history, current_prompt=current_prompt,
                assessment=last_assessment, phase=state.phase,
                reason=review_reason,
                context=retrieval.context,
                project_context=self._project_payload(),
            )
            decision = review(state, review_result.result)
        elif fresh:
            intake = self.model.classify_intake(message, project_context=self._project_payload())
            approach_provided = False
            if intake == Intake.GUIDANCE:
                approach_provided = self.model.check_approach(
                    objective=message, history=[], message=message,
                    project_context=self._project_payload(),
                ).provided
            if intake == Intake.CLARIFICATION or approach_provided:
                assessment = self.model.assess(
                    objective=message, question=None, criteria=(), dialogue=[],
                    message=message, context=retrieval.context,
                    current_prompt=None, project_context=self._project_payload(),
                )
            decision = start(
                message, intake, assessment.understanding if assessment else None,
                approach_provided=approach_provided,
                prerequisite_missing=assessment.prerequisite_missing if assessment else False,
            )
        else:
            if reply_kind == ReplyKind.CLARIFICATION:
                decision = Decision(state, Action.CLARIFY)
            elif reply_kind == ReplyKind.DIRECT:
                # A request for an answer must not restart practice or erase failures.
                decision = Decision(state, Action.REFUSE)
            else:
                ready = state.phase != Phase.APPROACH or self.model.check_approach(
                    objective=state.objective, history=history, message=message,
                    project_context=self._project_payload(),
                ).demonstrated
                if not ready:
                    decision = Decision(state, Action.INITIAL_HINT)
                else:
                    assessment = self.model.assess(
                        objective=state.objective, question=question, criteria=criteria,
                        dialogue=dialogue, message=message, context=retrieval.context,
                        current_prompt=current_prompt, project_context=self._project_payload(),
                    )
                    decision = assess(
                        state, assessment.understanding, count_attempt=current_prompt is not None,
                        prerequisite_missing=assessment.prerequisite_missing,
                    )

        question_mode = self._question_mode(decision, question)
        generated = self.model.generate(
            action=decision.action, objective=decision.state.objective,
            phase=decision.state.phase, question=question, criteria=criteria,
            question_mode=question_mode, message=message, context=retrieval.context,
            current_prompt=current_prompt,
            history=history if reviewing else history[-2 * self.history_turns:],
            dialogue=dialogue,
            assessment=last_assessment if reviewing else assessment, review=review_result,
            project_context=self._project_payload(),
        )
        self._validate_reply(generated, question_mode, question, criteria, retrieval.sources)
        if reviewing and decision.action == Action.KEEP and not question:
            # Retaining a suitable hint is deterministic, including before a quiz exists.
            generated = replace(generated, response=f"{current_prompt}\n\n{generated.response}")

        evidence_kind = "review" if reviewing else (reply_kind.value if reply_kind else "intake")
        if assessment is not None:
            # Intake can already contain useful reasoning. Preserve it for the
            # same hint-only objective without counting it as a failed attempt.
            evidence_kind = ("unassessed" if assessment.understanding == Understanding.UNKNOWN
                             else "answer")
        user_entry = {
            "role": "user", "content": message, "kind": evidence_kind,
            "question": question, "criteria": criteria,
        }
        tutor_entry = {
            "role": "assistant", "content": generated.text,
            "question": generated.question, "criteria": generated.criteria,
        }
        history.extend([user_entry, tutor_entry])
        if reviewing:
            # A revised prompt keeps all evidence, with its original question/rubric.
            dialogue.extend([user_entry, tutor_entry])
        elif question_mode == "new":
            # Application questions must be answered independently of the old question.
            dialogue = [tutor_entry]
        elif decision.state.phase == Phase.COMPLETED:
            dialogue = []
        else:
            dialogue.extend([user_entry, tutor_entry])

        self.state = decision.state
        self.history = history
        self.question = generated.question
        self.criteria = generated.criteria
        self.question_dialogue = dialogue
        self.current_prompt = generated.text if self.state.phase != Phase.COMPLETED else None
        self.last_assessment = assessment if assessment is not None else last_assessment
        return TurnResult(generated.text, self.state, decision.action, retrieval.sources,
                          assessment, review_result)

    @staticmethod
    def _question_mode(decision, question):
        if decision.state.phase in (Phase.APPROACH, Phase.COMPLETED):
            return "none"
        if decision.action == Action.REPHRASE:
            return "rephrase" if question else "none"
        if decision.action in (Action.REGENERATE, Action.REPAIR) and not question:
            return "none"
        if decision.replace_question:
            return "new"
        if question:
            return "keep"
        return "none"

    @staticmethod
    def _validate_reply(reply, mode, question, criteria, sources):
        if not reply.response.strip():
            raise ModelError("The tutor returned an empty response.")
        if mode == "none":
            if reply.question is not None or reply.criteria:
                raise ModelError("The tutor introduced an assessment in the wrong phase.")
        elif not reply.question or not reply.criteria:
            raise ModelError("The tutor omitted the assessment question or its criteria.")
        elif mode == "keep" and (reply.question != question or reply.criteria != criteria):
            raise ModelError("The tutor changed the pending question or its criteria.")
        elif mode == "rephrase" and reply.criteria != criteria:
            raise ModelError("Rephrasing changed the assessment criteria.")
        available = {source.number for source in sources}
        cited = {int(n) for n in re.findall(r"\[Source (\d+)\]", reply.text)}
        if not cited.issubset(available):
            raise ModelError("The tutor cited a source that was not retrieved.")
