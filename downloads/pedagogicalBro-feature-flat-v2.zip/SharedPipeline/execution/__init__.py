"""Transactional tutoring sessions and command-line execution."""
