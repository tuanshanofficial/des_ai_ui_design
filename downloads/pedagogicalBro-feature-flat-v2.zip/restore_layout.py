from pathlib import Path
import sys, json, hashlib, os
base=Path(__file__).resolve().parent
if len(sys.argv)!=2:
    raise SystemExit('Usage: python restore_layout.py NEW_EMPTY_DIRECTORY')
dest=Path(sys.argv[1]).resolve()
if dest.exists() and (not dest.is_dir() or any(dest.iterdir())):
    raise SystemExit('Destination must be absent or empty; existing files will not be overwritten.')
manifest=json.loads((base/'MANIFEST.json').read_text())
# Verify every source file before writing anything.
for entry in manifest['files']:
    data=(base/entry['archive_path']).read_bytes()
    if hashlib.sha256(data).hexdigest()!=entry['sha256']:
        raise SystemExit('Checksum mismatch: '+entry['archive_path'])
dest.mkdir(parents=True,exist_ok=True)
links=[]
for entry in manifest['files']:
    data=(base/entry['archive_path']).read_bytes()
    target=dest/entry['original_path']; target.parent.mkdir(parents=True,exist_ok=True)
    if entry['mode']=='120000':
        links.append((target,data.decode()))
    else:
        target.write_bytes(data)
        if entry['mode']=='100755': target.chmod(0o755)
for target,link in links:
    try:
        target.symlink_to(link, target_is_directory=(target.parent/link).is_dir())
    except OSError:
        import shutil
        source=(target.parent/link).resolve()
        if source.is_dir(): shutil.copytree(source,target)
        else: shutil.copy2(source,target)
print('Original layout restored:',dest)
