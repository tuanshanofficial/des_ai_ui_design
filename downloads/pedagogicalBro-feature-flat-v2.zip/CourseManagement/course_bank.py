"""Read instructor DOCX banks without exposing marking material to students."""
from pathlib import Path
from copy import deepcopy
import re
from zipfile import ZipFile
from xml.etree import ElementTree as ET

PROJECT_DIR = Path(__file__).resolve().parent.parent / 'course_materials' / 'source'
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}


def node_text(node):
    """Preserve Word text, line breaks and tabs without rewriting source files."""
    parts = []
    for item in node.iter():
        if item.tag == '{' + NS['w'] + '}t':
            parts.append(item.text or '')
        elif item.tag == '{' + NS['w'] + '}tab':
            parts.append('\t')
        elif item.tag in ('{' + NS['w'] + '}br', '{' + NS['w'] + '}cr'):
            parts.append('\n')
    return ''.join(parts).strip()


def read_docx_blocks(filename):
    """Read paragraphs and tables in document order using only the standard library."""
    with ZipFile(filename) as archive:
        body = ET.fromstring(archive.read('word/document.xml')).find('w:body', NS)
    if body is None:
        raise ValueError(f'No document body in {Path(filename).name}')
    blocks = []
    for node in body:
        if node.tag.endswith('}tbl'):
            rows = []
            for row in node.findall('w:tr', NS):
                rows.append(['\n'.join(node_text(p) for p in cell.findall('w:p', NS))
                             for cell in row.findall('w:tc', NS)])
            blocks.append(dict(type='table', rows=rows))
        elif node.tag.endswith('}p'):
            text = node_text(node)
            if text:
                blocks.append(dict(type='paragraph', text=text))
    return blocks


def block_text(block):
    if block['type'] == 'table':
        return '\n'.join(' | '.join(row) for row in block['rows'])
    return block['text']


def validate_question(data):
    """Validate instructor input and return the private bank representation.

    Marking material is deliberately retained here. Only public_question() may
    be used when building a student response. The caller assigns any new ID.
    """
    if not isinstance(data, dict):
        raise ValueError('A question must be an object.')
    lecture, objective = data.get('lecture'), data.get('lo')
    if type(lecture) is not int or lecture not in (1, 2, 3):
        raise ValueError('Lecture must be 1, 2, or 3.')
    if type(objective) is not int or not 1 <= objective <= {1: 7, 2: 7, 3: 9}[lecture]:
        raise ValueError('Choose a learning objective from the selected lecture.')
    result = dict(id=data.get('id', ''), lecture=lecture, lo=objective)
    for field, limit in (('prompt', 10000), ('answer', 15000), ('rubric', 15000), ('context', 20000)):
        value = data.get(field, '' if field == 'context' else None)
        if not isinstance(value, str) or len(value) > limit or (field != 'context' and not value.strip()):
            raise ValueError(f'{field.capitalize()} must be text within {limit} characters'
                             + ('.' if field == 'context' else ' and must not be empty.'))
        result[field] = value.strip()
    options = data.get('options', [])
    if not isinstance(options, list) or len(options) not in (0, 4):
        raise ValueError('Use either a short answer or four options labeled A. through D..')
    if options and any(not isinstance(option, str) or len(option) > 3000
                       or not re.match(r'^' + letter + r'\.\s+\S', option)
                       for letter, option in zip('ABCD', options)):
        raise ValueError('Provide four nonempty options in A., B., C., D. order.')
    key = data.get('correct_option', data.get('correctOption'))
    if options and (not isinstance(key, str) or key not in ('A', 'B', 'C', 'D')):
        raise ValueError('A multiple-choice question needs a correct option from A through D.')
    if not options and key not in (None, ''):
        raise ValueError('A short-answer question does not have a correct option.')
    result.update(options=list(options), correctOption=key or None)
    tables = data.get('table', [])
    if not isinstance(tables, list) or len(tables) > 10:
        raise ValueError('Question tables must be a list of at most ten tables.')
    for table in tables:
        if not isinstance(table, list) or not table or len(table) > 200:
            raise ValueError('A question table needs between one and 200 rows.')
        for row in table:
            if not isinstance(row, list) or not row or len(row) > 30:
                raise ValueError('Each table row needs between one and 30 cells.')
            if any(not isinstance(cell, str) or len(cell) > 5000 for cell in row):
                raise ValueError('Table cells must be text within 5000 characters.')
    if sum(len(cell) for table in tables for row in table for cell in row) > 80000:
        raise ValueError('Question tables are too large.')
    result['table'] = deepcopy(tables)
    return result


def load_banks(directory=PROJECT_DIR):
    directory = Path(directory)
    missing = [f'Lecture_{n}.docx' for n in (1, 2, 3)
               if not (directory / f'Lecture_{n}.docx').is_file()]
    if missing:
        raise FileNotFoundError('Missing instructor question banks: ' + ', '.join(missing)
                                + '. Import the original course package with scripts/import_course_materials.py.')
    banks = {}
    for lecture in (1, 2, 3):
        body = read_docx_blocks(directory / f'Lecture_{lecture}.docx')
        questions, current, section = [], None, 'prompt'
        pool_context, in_pool = [], False
        for node in body:
            text = block_text(node)
            match = re.fullmatch(r'(Q(\d+)-[A-Z])(?:\s*\|.*)?', text)
            if match:
                current = dict(id=match[1], lecture=lecture, lo=int(match[2]),
                               context='\n'.join(pool_context), prompt=[], options=[], answer=[], rubric=[], table=[], correctOption=None)
                questions.append(current)
                section = 'prompt'
                continue
            # End the current question at the next LO/marking-summary heading.
            if re.match(r'^(?:LO\d|1\.\d|Marking|Coverage|Question selection|End of Lecture \d+ question bank)', text):
                current = None
                in_pool = bool(re.match(r'^LO\d', text))
                pool_context = []
            if current is None or not text:
                if (in_pool and text and not re.match(r'^(?:LO\d|Short answer|Multiple choice)', text)):
                    # Pool assumptions can contain indispensable supplied facts
                    # (e.g. airline fares). They are not answer keys.
                    value = re.sub(r'Draw ONE short-answer question from this pool\.', '', text).strip()
                    pool_context.append(value)
                continue
            if node['type'] == 'table':
                rows = node['rows']
                if section == 'prompt':
                    current['table'].append(rows)
                else:
                    current[section].append('\n'.join(' | '.join(row) for row in rows))
            elif re.match(r'^(?:REFERENCE ANSWERS?|Reference answers?)\b', text):
                section = 'answer'
                value = re.sub(r'^(?:REFERENCE ANSWERS?|Reference answers?)\s*:?[ \t]*', '', text)
                if value:
                    current['answer'].append(value)
            elif text.startswith('Assess:') or text == 'Grading criteria':
                section = 'rubric'
                if text.startswith('Assess:'):
                    current['rubric'].append(text.removeprefix('Assess:').strip())
            elif re.match(r'^(?:ANSWER\s+[A-D]\b|Correct answer:\s*[A-D]\b)', text):
                key = re.search(r'(?:ANSWER\s+|Correct answer:\s*)([A-D])\b', text)[1]
                current['correctOption'] = key
                current['answer'].append(key)
                explanation = re.sub(r'^(?:ANSWER\s+|Correct answer:\s*)[A-D]\s*[•:]?\s*', '', text)
                if explanation:
                    current['rubric'].append(explanation)
                section = 'rubric'
            elif section == 'prompt' and re.match(r'^[A-D]\.\s', text):
                current['options'].append(text)
            else:
                current[section].append(text)
        validated = []
        for q in questions:
            for field in ('prompt', 'answer', 'rubric'):
                q[field] = '\n'.join(q[field]).strip()
            if not q['prompt'] or not q['answer'] or (q['options'] and not q['correctOption']):
                raise ValueError(f'Incomplete instructor item: Lecture {lecture} {q["id"]}')
            if q['options'] and ({option[0] for option in q['options']} != set('ABCD')
                                 or q['correctOption'] not in 'ABCD'):
                raise ValueError(f'Invalid option key: Lecture {lecture} {q["id"]}')
            validated.append(validate_question(q))
        expected = {1: 24, 2: 22, 3: 27}[lecture]
        if len(questions) != expected or len({q['id'] for q in questions}) != expected:
            raise ValueError(f'Unexpected question bank size for Lecture {lecture}')
        if {q['lo'] for q in questions} != set(range(1, {1: 7, 2: 7, 3: 9}[lecture] + 1)):
            raise ValueError(f'Unexpected learning-objective pools for Lecture {lecture}')
        banks[lecture] = validated
    return banks


def public_question(q):
    return {key: q[key] for key in ('id', 'lecture', 'lo', 'context', 'prompt', 'options', 'table')}
