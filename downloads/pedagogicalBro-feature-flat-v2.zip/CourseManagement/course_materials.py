"""Read the imported instructor package; no PDF dependencies or model calls at runtime.

Only PDF slides and rendered slide images are public assets. Instructor question
banks, reference answers, marking criteria and the project DOCX stay server-side.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import quote


DEFAULT_ROOT = Path(__file__).resolve().parent.parent / 'course_materials'
LESSONS_PATH = Path(__file__).resolve().parent.parent / 'ui design' / 'lessons.json'


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def slide_numbers(expression, page_count):
    """Read one-based PDF page ranges such as '21–22, 25–27' exactly."""
    if not isinstance(expression, str) or not expression.strip():
        raise ValueError('A lesson needs an explicit slide-page range.')
    selected = set()
    for part in expression.split(','):
        match = re.fullmatch(r'\s*(\d+)\s*(?:[-\u2013\u2014]\s*(\d+)\s*)?', part)
        if not match:
            raise ValueError(f'Invalid slide-page range: {expression}')
        first, last = int(match[1]), int(match[2] or match[1])
        if not 1 <= first <= last <= page_count:
            raise ValueError(f'Slide-page range is outside the supplied PDF: {expression}')
        selected.update(range(first, last + 1))
    return sorted(selected)


def asset_url(relative_path):
    return '/materials/' + quote(str(relative_path), safe='/')


class CourseMaterials:
    def __init__(self, root=None):
        self.root = Path(root or DEFAULT_ROOT).resolve()
        self.manifest = {}
        self._pages = {}
        self._project = {}
        self._assets = {}
        self._missing = []
        manifest_path = self.root / 'manifest.json'
        if not manifest_path.is_file():
            self._missing.append('manifest.json')
            return
        self.manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        if self.manifest.get('schema_version') != 1:
            raise ValueError('Unsupported course-material manifest version.')
        for document in self.manifest.get('documents', []):
            source = self._path(document['path'])
            if not source.is_file() or file_sha256(source) != document['sha256']:
                self._missing.append(document['filename'])
                continue
            if document['kind'] == 'slides':
                lecture = int(document['lecture'])
                pages_path = self._path(document['pages_path'])
                if not pages_path.is_file():
                    self._missing.append(document['pages_path'])
                    continue
                pages = json.loads(pages_path.read_text(encoding='utf-8'))
                if len(pages) != document['page_count'] or [p['page'] for p in pages] != list(range(1, len(pages) + 1)):
                    raise ValueError(f'Incomplete slide extraction for lecture {lecture}.')
                rendered = []
                for page in pages:
                    image = self._path(page['image_path'])
                    if not image.is_file():
                        self._missing.append(page['image_path'])
                        continue
                    self._assets[page['image_path']] = image
                    pdf = asset_url(document['path'])
                    rendered.append(dict(page=page['page'], title=page['title'], text=page['text'],
                                         image_url=asset_url(page['image_path']),
                                         pdf_url=f'{pdf}#page={page["page"]}', source_pdf=pdf))
                if len(rendered) == len(pages):
                    self._pages[lecture] = rendered
                    self._assets[document['path']] = source
            elif document['kind'] == 'project':
                project_path = self._path(document['text_path'])
                if project_path.is_file():
                    self._project = json.loads(project_path.read_text(encoding='utf-8'))
                else:
                    self._missing.append(document['text_path'])

    def _path(self, relative):
        path = (self.root / relative).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError('A course-material path must stay within its package.')
        return path

    def public_asset(self, relative):
        """Return an exact allowlisted slide PDF/PNG, never an instructor DOCX."""
        return self._assets.get(relative)

    def status(self):
        documents = self.manifest.get('documents', [])
        banks, slides = [], []
        for document in documents:
            available = document['filename'] not in self._missing
            if document['kind'] == 'question_bank':
                banks.append(dict(lecture=document['lecture'], count=document['question_count'],
                                  objectives=document['objective_count'], sha256=document['sha256'],
                                  available=available, filename=document['filename']))
            elif document['kind'] == 'slides':
                lecture = int(document['lecture'])
                slides.append(dict(lecture=lecture, title=document['title'], page_count=document['page_count'],
                                   pdf_url=asset_url(document['path']), sha256=document['sha256'],
                                   available=lecture in self._pages, filename=document['filename']))
        banks.sort(key=lambda item: item['lecture'])
        slides.sort(key=lambda item: item['lecture'])
        project = next((doc for doc in documents if doc['kind'] == 'project'), {})
        bank_ready = len(banks) == 3 and all(item['available'] for item in banks)
        slide_ready = all(n in self._pages for n in (1, 2, 3))
        return dict(available=bool(self.manifest) and not self._missing and bank_ready and slide_ready and bool(self._project),
                    missing=list(self._missing),
                    question_banks=dict(available=bank_ready, lectures=banks,
                                        missing=[f'Lecture_{n}.docx' for n in (1, 2, 3)
                                                 if not any(b['lecture'] == n and b['available'] for b in banks)]),
                    slides=dict(available=slide_ready,
                                all=slides,
                                lectures=[s for s in slides if s['lecture'] <= 3],
                                additional=[s for s in slides if s['lecture'] > 3]),
                    project=dict(available=bool(self._project), title=project.get('title'),
                                 sha256=project.get('sha256'), filename=project.get('filename')))

    def slides(self, lecture):
        return deepcopy(self._pages.get(int(lecture), []))

    def lecture_numbers(self):
        """Return actual imported decks, including later lectures when supplied."""
        return tuple(sorted(self._pages))

    def slide_deck(self, lecture):
        """Describe one complete lecture PDF without selecting individual pages."""
        lecture = int(lecture)
        return next((deepcopy(deck) for deck in self.status()['slides']['all']
                     if deck['lecture'] == lecture and deck['available']), None)

    def _lesson(self, lecture, lesson):
        if isinstance(lesson, dict):
            selected = lesson
        else:
            lessons = json.loads(LESSONS_PATH.read_text(encoding='utf-8'))
            if type(lesson) is int:
                if not 0 <= lesson < len(lessons):
                    raise ValueError('Unknown lesson index.')
                selected = lessons[lesson]
            elif isinstance(lesson, str):
                selected = next((entry for entry in lessons
                                 if entry['lecture'] == lecture and entry['title'] == lesson), None)
                if selected is None:
                    raise ValueError('Unknown lesson title for this lecture.')
            else:
                raise ValueError('Lesson must be a lesson object, global index, or title.')
        if int(selected.get('lecture', lecture)) != lecture:
            raise ValueError('The selected lesson belongs to a different lecture.')
        return selected

    def context(self, lecture, lesson=None):
        """Give the tutor the actual supplied slide text with page provenance."""
        lecture = int(lecture)
        pages = self._pages.get(lecture, [])
        if not pages:
            return ''
        if lesson is not None:
            selected = self._lesson(lecture, lesson)
            numbers = slide_numbers(selected.get('slides'), len(pages))
            pages = [page for page in pages if page['page'] in numbers]
        document = next(doc for doc in self.manifest['documents']
                        if doc['kind'] == 'slides' and int(doc['lecture']) == lecture)
        heading = f'INSTRUCTOR LECTURE SLIDES: {document["title"]}\nSource PDF: {document["filename"]}'
        return heading + '\n\n' + '\n\n'.join(
            f'[Lecture {lecture}, slide {page["page"]}: {page["title"]}]\n{page["text"]}' for page in pages)

    def project_context(self):
        """Instructor project facts only; this never reads lecture answer keys."""
        return self._project.get('text', '')
