"""Validate complete Word question-bank uploads before any database writes.

The downloadable template is the contract. Each question is one two-column
``Field | Value`` Word table. Private references remain instructor-only input.
Parsing uses the standard library and never resolves package relationships.
"""
import base64
import binascii
import hashlib
from io import BytesIO
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile

from AI_TA_PYTHON_CODE.pedagogical_ai.course_bank import NS, node_text, validate_question


MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MAX_PACKAGE_BYTES = 20 * 1024 * 1024
MAX_XML_BYTES = 5 * 1024 * 1024
MAX_QUESTIONS = 100
FORMAT = 'sysc4005-question-bank-v1'
MARKER = 'SYSC4005 question bank v1'
TEMPLATE_PATH = Path(__file__).resolve().parent.parent / 'ui design' / 'assets' / 'question-bank-template.docx'
OBJECTIVE_LIMITS = {1: 7, 2: 7, 3: 9}

_WORD_DOCUMENT = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'
_FIELDS = {
    'lecture': 'lecture', 'objective': 'lo', 'learning objective': 'lo',
    'question type': 'type', 'ready to import': 'ready',
    'prompt': 'prompt', 'answer': 'answer', 'reference answer': 'answer',
    'rubric': 'rubric', 'marking criteria': 'rubric', 'context': 'context',
    'option a': 'A', 'option b': 'B', 'option c': 'C', 'option d': 'D',
    'correct option': 'correct_option', 'data table': 'table',
}
_REQUIRED = {'lecture', 'lo', 'type', 'ready', 'prompt', 'answer', 'rubric'}
_NAMES = {'lo': 'Objective', 'type': 'Question type', 'ready': 'Ready to import'}


class UploadError(ValueError):
    """An actionable format error safe to show to the instructor."""


def decode_upload(data):
    """Decode the JSON upload envelope without accepting oversized allocations."""
    if not isinstance(data, dict):
        raise UploadError('Choose a Word question-bank file using the downloadable template.')
    filename = data.get('filename')
    _filename(filename)
    value = data.get('content_base64')
    if not isinstance(value, str) or not value:
        raise UploadError('The Word file is empty. Choose a completed .docx template.')
    if len(value) > 4 * ((MAX_UPLOAD_BYTES + 2) // 3):
        raise UploadError('The Word file must be no larger than 5 MB.')
    try:
        content = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError):
        raise UploadError('The uploaded file could not be read. Choose the .docx file again.') from None
    if not content or len(content) > MAX_UPLOAD_BYTES:
        raise UploadError('The Word file must contain data and be no larger than 5 MB.')
    return filename, content


def _filename(filename):
    if (not isinstance(filename, str) or not filename.strip() or len(filename) > 200
            or '/' in filename or '\\' in filename
            or any(ord(char) < 32 for char in filename)
            or not filename.casefold().endswith('.docx')):
        raise UploadError('Choose a .docx Word file. PDF, .doc and macro-enabled files are not supported.')
    return filename.strip()


def _xml(content, label):
    if len(content) > MAX_XML_BYTES:
        raise UploadError('The Word document contains too much text. Split it into smaller question banks.')
    try:
        text = content.decode('utf-8-sig')
    except UnicodeError:
        raise UploadError('Save the Word document using the downloadable .docx template.') from None
    lowered = text.casefold()
    if '\x00' in text or '<!doctype' in lowered or '<!entity' in lowered:
        raise UploadError('The Word file contains unsupported XML declarations. Save a fresh copy of the template.')
    try:
        root = ET.fromstring(text)
    except (ET.ParseError, ValueError):
        raise UploadError('The Word file has invalid ' + label + '. Save a fresh .docx copy and try again.') from None
    pending, nodes = [(root, 1)], 0
    while pending:
        node, depth = pending.pop()
        nodes += 1
        if nodes > 100000 or depth > 60:
            raise UploadError('The Word document structure is too complex. Use a fresh copy of the template.')
        pending.extend((child, depth + 1) for child in node)
    return root


def _document(content):
    if not isinstance(content, bytes) or not content or len(content) > MAX_UPLOAD_BYTES:
        raise UploadError('The Word file must contain data and be no larger than 5 MB.')
    try:
        with ZipFile(BytesIO(content)) as archive:
            infos = archive.infolist()
            if len(infos) > 500 or sum(info.file_size for info in infos) > MAX_PACKAGE_BYTES:
                raise UploadError('The Word package is too large. Split it into smaller question banks.')
            names = set()
            for info in infos:
                name = info.filename
                normalized = name.casefold()
                if (name.startswith(('/', '\\')) or '\\' in name or ':' in name
                        or '..' in name.split('/') or normalized in names):
                    raise UploadError('The Word file has an invalid package structure. Save a fresh .docx copy.')
                names.add(normalized)
                if info.flag_bits & 1:
                    raise UploadError('Password-protected Word files are not supported. Upload an unprotected .docx file.')
                if info.file_size > MAX_PACKAGE_BYTES or (info.file_size > 1024 * 1024
                        and info.file_size > max(info.compress_size, 1) * 200):
                    raise UploadError('The Word package is too large. Split it into smaller question banks.')
                if ('vbaproject' in normalized or normalized.startswith(('word/embeddings/', 'word/activex/'))):
                    raise UploadError('Embedded programs and attachments are not supported. Use the question-bank template.')
            if 'word/document.xml' not in names or '[content_types].xml' not in names:
                raise UploadError('This is not a supported Word document. Upload a completed .docx template.')
            types = _xml(archive.read('[Content_Types].xml'), 'content types')
            if any('macroenabled' in value.casefold() for node in types for value in node.attrib.values()):
                raise UploadError('Macro-enabled documents are not supported. Save as a regular .docx file.')
            if not any(node.get('PartName') == '/word/document.xml' and node.get('ContentType') == _WORD_DOCUMENT
                       for node in types):
                raise UploadError('This is not a regular .docx Word document. Use the question-bank template.')
            for info in infos:
                if info.filename.casefold().endswith('.rels'):
                    rels = _xml(archive.read(info), 'relationships')
                    if any(node.get('TargetMode', '').casefold() == 'external' for node in rels):
                        raise UploadError('Linked external content is not supported. Remove external links or use a fresh template.')
            return _xml(archive.read('word/document.xml'), 'document text')
    except UploadError:
        raise
    except (BadZipFile, KeyError, RuntimeError, OSError, NotImplementedError):
        raise UploadError('The Word file could not be opened. Save it as a regular .docx file and try again.') from None


def _cell_text(cell):
    return '\n'.join(node_text(paragraph) for paragraph in cell.findall('w:p', NS)).strip()


def _rows(table):
    return [[_cell_text(cell) for cell in row.findall('w:tc', NS)] for row in table.findall('w:tr', NS)]


def _question(table, number):
    prefix = f'Question {number}: '
    rows = table.findall('w:tr', NS)
    if not rows or [_cell_text(cell).casefold() for cell in rows[0].findall('w:tc', NS)] != ['field', 'value']:
        raise UploadError(prefix + 'use a two-column Field and Value table from the downloadable template.')
    fields = {}
    for row in rows[1:]:
        cells = row.findall('w:tc', NS)
        if len(cells) != 2 or any(cell.find('w:tcPr/w:gridSpan', NS) is not None
                                  or cell.find('w:tcPr/w:vMerge', NS) is not None for cell in cells):
            raise UploadError(prefix + 'keep the question table in two columns without merged cells.')
        label = re.sub(r'\s+', ' ', _cell_text(cells[0])).strip().casefold()
        if label not in _FIELDS:
            raise UploadError(prefix + 'unknown field ' + repr(label[:80]) + '. Keep the field names from the template.')
        field = _FIELDS[label]
        if field in fields:
            raise UploadError(prefix + 'the ' + label + ' field appears more than once.')
        nested = cells[1].findall('w:tbl', NS)
        text = _cell_text(cells[1])
        if nested:
            if field != 'table' or len(nested) != 1 or text:
                raise UploadError(prefix + 'put a single data table only in the Data table value cell.')
            fields[field] = _rows(nested[0])
        else:
            fields[field] = text
    missing = sorted(_REQUIRED - fields.keys())
    if missing:
        raise UploadError(prefix + 'missing fields: ' + ', '.join(_NAMES.get(f, f.capitalize()) for f in missing) + '.')
    if fields['ready'].strip().casefold() != 'yes':
        raise UploadError(prefix + 'set Ready to import to Yes after replacing and reviewing the example fields.')
    if any(isinstance(value, str) and ('[[' in value or ']]' in value) for value in fields.values()):
        raise UploadError(prefix + 'replace all [[placeholder]] text before importing.')
    try:
        lecture, objective = int(fields['lecture']), int(fields['lo'])
    except ValueError:
        raise UploadError(prefix + 'Lecture and Objective must be whole numbers.') from None
    if lecture not in OBJECTIVE_LIMITS:
        raise UploadError(prefix + 'Lecture must be 1, 2, or 3, where project question banks are available.')
    if not 1 <= objective <= OBJECTIVE_LIMITS[lecture]:
        raise UploadError(prefix + f'Objective must be between 1 and {OBJECTIVE_LIMITS[lecture]} for Lecture {lecture}.')
    kind = fields['type'].strip().casefold()
    if kind not in ('multiple choice', 'short answer'):
        raise UploadError(prefix + 'Question type must be Multiple choice or Short answer.')
    options = [fields.get(letter, '').strip() for letter in 'ABCD']
    if kind == 'multiple choice':
        if not all(options):
            raise UploadError(prefix + 'fill Option A, B, C and D for a multiple-choice question.')
        options = [letter + '. ' + re.sub(r'^' + letter + r'\.\s*', '', value).strip()
                   for letter, value in zip('ABCD', options)]
    elif any(options):
        raise UploadError(prefix + 'leave Option A through D empty for a short-answer question.')
    else:
        options = []
    data = fields.get('table', '')
    if isinstance(data, str):
        data = [[cell.strip() for cell in line.split('|')] for line in data.splitlines() if line.strip()]
    if data and (not all(isinstance(row, list) and row for row in data)
                 or len({len(row) for row in data}) != 1):
        raise UploadError(prefix + 'each data-table row must contain the same number of cells.')
    raw = dict(lecture=lecture, lo=objective, prompt=fields['prompt'], options=options,
               correct_option=fields.get('correct_option', '').strip().upper(),
               answer=fields['answer'], rubric=fields['rubric'], context=fields.get('context', ''),
               table=[data] if data else [])
    try:
        return validate_question(raw)
    except ValueError as error:
        raise UploadError(prefix + str(error)) from None


def parse_question_bank(content, filename='question-bank.docx'):
    """Return all validated private items plus a content hash; perform no writes."""
    filename = _filename(filename)
    document = _document(content)
    body = document.find('w:body', NS)
    if body is None:
        raise UploadError('The Word document has no body. Use a fresh copy of the template.')
    paragraphs = [node_text(node) for node in body.findall('w:p', NS)]
    if MARKER not in paragraphs:
        raise UploadError('Use the downloadable question-bank template and keep its SYSC4005 question bank v1 format line.')
    tables = body.findall('w:tbl', NS)
    if not tables:
        raise UploadError('Add at least one completed Field and Value question table from the template.')
    if len(tables) > MAX_QUESTIONS:
        raise UploadError(f'Import at most {MAX_QUESTIONS} questions at a time. Split this bank into smaller files.')
    questions = [_question(table, number) for number, table in enumerate(tables, 1)]
    identities = set()
    for number, question in enumerate(questions, 1):
        identity = (question['lecture'], question['lo'], re.sub(r'\s+', ' ', question['prompt']).casefold())
        if identity in identities:
            raise UploadError(f'Question {number}: this lecture, objective and question text is duplicated in the Word file.')
        identities.add(identity)
    return dict(format=FORMAT, filename=filename, sha256=hashlib.sha256(content).hexdigest(),
                question_count=len(questions),
                counts={str(n): sum(q['lecture'] == n for q in questions) for n in OBJECTIVE_LIMITS},
                questions=questions)
