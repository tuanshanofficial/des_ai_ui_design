"""Provider-specific settings; credentials never fall back across providers."""

from dataclasses import dataclass, field
import os
from pathlib import Path
from urllib.parse import urlsplit


PROVIDERS = ("carleton", "openai")
OPENAI_API_URL = "https://api.openai.com/v1"
OPENAI_MODEL = "gpt-6-luna"
ENV_FILE_KEYS = frozenset({
    "DES_LLM_PROVIDER", "DES_PROJECT_CONTEXT", "DES_CONTEXT_WINDOW_TOKENS",
    "CARLETON_RCS_API_KEY", "CARLETON_RCS_URL", "CARLETON_MODEL",
    "OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL",
})


def load_provider_env(path):
    """Load explicit application settings without replacing the shell's values.

    Reading is opt-in. Interpolation and shell evaluation are disabled; unrelated
    variables such as PATH and PYTHONPATH are ignored. Errors never include file
    contents or credential values.
    """
    if path is None:
        return
    try:
        env_path = Path(path)
        if not env_path.is_file():
            raise ValueError("--env-file must name a readable UTF-8 file.")
    except (OSError, TypeError):
        raise ValueError("--env-file must name a readable UTF-8 file.") from None
    try:
        from dotenv import dotenv_values
    except ImportError:
        raise RuntimeError("Install python-dotenv to use --env-file: pip install -r requirements.txt") from None
    try:
        with env_path.open(encoding="utf-8") as stream:
            values = dotenv_values(stream=stream, interpolate=False)
    except (OSError, UnicodeError, ValueError):
        raise ValueError("--env-file must name a readable UTF-8 file.") from None
    for key, value in values.items():
        if key in ENV_FILE_KEYS and value is not None:
            os.environ.setdefault(key, value)


@dataclass(frozen=True)
class ProviderConfig:
    provider: str
    model: str
    api_url: str
    api_key: str = field(repr=False)

    def new_client(self):
        """Construct the SDK client only after settings have been validated."""
        from openai import OpenAI
        return OpenAI(base_url=self.api_url, api_key=self.api_key, timeout=90.0, max_retries=1)


def resolve_provider(provider="carleton", model=None, api_url=None, *, environ=None):
    """Resolve an explicit provider without exposing or mixing its credentials.

    The OpenAI option calls the official API only. An instructor who needs an
    OpenAI-compatible institutional endpoint should select ``carleton`` and its
    own credential instead of forwarding an OpenAI project key to that endpoint.
    """
    if provider not in PROVIDERS:
        raise ValueError("--provider must be carleton or openai.")
    env = os.environ if environ is None else environ
    if provider == "openai":
        key_name, url_name, model_name = "OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL"
        default_url, default_model = OPENAI_API_URL, OPENAI_MODEL
    else:
        key_name, url_name, model_name = "CARLETON_RCS_API_KEY", "CARLETON_RCS_URL", "CARLETON_MODEL"
        default_url, default_model = "https://rcsllm.carleton.ca/rcsapi/v1", "gpt-oss:120b"
    key = env.get(key_name, "").strip()
    if not key:
        raise ValueError(f"Set {key_name} in your environment before starting the tutor.")
    selected_model = (model if model is not None else env.get(model_name) or default_model).strip()
    selected_url = (api_url if api_url is not None else env.get(url_name) or default_url).strip().rstrip("/")
    if not selected_model:
        raise ValueError("The selected model must be nonempty.")
    try:
        parsed = urlsplit(selected_url)
        valid = (parsed.scheme in ("http", "https") and bool(parsed.hostname)
                 and not parsed.username and not parsed.password
                 and not parsed.query and not parsed.fragment)
        port = parsed.port
    except ValueError:
        valid, port = False, None
    if not valid:
        raise ValueError("The selected API URL must be an HTTP(S) base URL without credentials, query, or fragment.")
    if provider == "openai":
        if (parsed.scheme != "https" or parsed.hostname != "api.openai.com"
                or port not in (None, 443) or parsed.path != "/v1"):
            raise ValueError("The openai provider requires the official https://api.openai.com/v1 endpoint.")
    elif parsed.hostname == "openai.com" or parsed.hostname.endswith(".openai.com"):
        raise ValueError("Use --provider openai and OPENAI_API_KEY for the OpenAI API endpoint.")
    return ProviderConfig(provider, selected_model, selected_url, key)
