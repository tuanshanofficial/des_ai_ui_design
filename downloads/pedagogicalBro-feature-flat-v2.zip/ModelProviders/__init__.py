"""Model provider transports and validated task contracts."""
