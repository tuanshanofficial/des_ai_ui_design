"""Private local diagnostics, including attempts that never commit progress."""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from urllib.parse import unquote, urlsplit, urlunsplit
import uuid


_REDACTED = '[REDACTED]'
_PRIVATE_KEYS = {
    'authorization', 'proxyauthorization', 'authentication', 'auth', 'credential',
    'credentials', 'cookie', 'setcookie',
    'password', 'passwd', 'secret', 'clientsecret', 'token', 'accesstoken',
    'refreshtoken', 'idtoken', 'instructorkey', 'instructoraccesscode', 'accesscode',
    'environment', 'environ', 'env', 'envfile', 'sessionid', 'sessiontoken', 'sid',
}
_QUERY_KEYS = _PRIVATE_KEYS | {'key', 'sig', 'signature', 'auth', 'credential', 'credentials'}
_CONTEXT_KEYS = {'attempt_id', 'request_id', 'route', 'session_alias', 'operation',
                 'operation_id', 'parent_operation_id'}
_RESERVED = _CONTEXT_KEYS | {'event', 'timestamp', 'thread_id'}
_METADATA_FIELDS = {
    'status', 'duration_ms', 'model_call_id', 'provider', 'model', 'provider_response_id',
    'status_code', 'provider_request_id', 'finish_reason', 'incomplete_reason',
    'parse_attempt', 'revision', 'accepted', 'rejected_drafts', 'lookup_request_id',
    'response_request_id', 'source',
}
_ASSESSMENT_FLAGS = {'sufficient', 'guidance_correct', 'guidance_attempted', 'help_requested'}


def _key(value):
    return re.sub(r'[^a-z0-9]', '', value.casefold())


def _private_key(value):
    normalized = _key(value)
    return (normalized in _PRIVATE_KEYS or 'apikey' in normalized
            or normalized.startswith('environment')
            or normalized.endswith(('token', 'password', 'passwd', 'privatekey', 'secretkey', 'secretaccesskey')))


def _url(match):
    original = match.group(0)
    try:
        parts = urlsplit(original)
        host = parts.netloc.rsplit('@', 1)[-1]
        netloc = _REDACTED + '@' + host if '@' in parts.netloc else parts.netloc
        query = []
        for item in parts.query.split('&'):
            name, equal, value = item.partition('=')
            normalized = _key(unquote(name))
            if equal and (normalized in _QUERY_KEYS or 'apikey' in normalized or
                          normalized.endswith(('token', 'signature', 'credential', 'secret', 'password'))):
                value = _REDACTED
            query.append(name + equal + value)
        fragment = parts.fragment
        if re.search(r'(?:token|secret|password|api[_-]?key)\s*=', unquote(fragment), re.I):
            fragment = _REDACTED
        return urlunsplit((parts.scheme, netloc, parts.path, '&'.join(query), fragment))
    except ValueError:
        return '[REDACTED URL]'


def _text(value):
    value = re.sub(r'https?://[^\s<>"\']+', _url, value)
    value = re.sub(r'(?i)\b(?:Bearer|Basic)\s+[^\s,;"\'<>]+',
                   lambda match: match.group(0).split()[0] + ' ' + _REDACTED, value)
    value = re.sub(r'(?im)(\b(?:cookie|set-cookie)\s*[:=]\s*)[^\r\n]+',
                   lambda match: match.group(1) + _REDACTED, value)
    # Handle credentials embedded in error strings rather than structured fields.
    names = (r'(?:api[_-]?key|authorization|proxy-authorization|'
             r'access[_-]?token|refresh[_-]?token|id[_-]?token|client[_-]?secret|'
             r'instructor[_-]?(?:key|access[_-]?code)|session[_-]?(?:id|token)|'
             r'access[_-]?code|token|password|passwd|secret)')
    value = re.sub(
        r'(?i)(["\']?' + names + r'["\']?\s*[:=]\s*)'
        r'(?:"[^"\n]*"|\'[^\'\n]*\'|[^\s,;&]+)',
        lambda match: match.group(1) + _REDACTED, value)
    return re.sub(r'\bsk-[a-zA-Z0-9_-]{8,}', _REDACTED, value)


def _safe(value, seen=None):
    if isinstance(value, str):
        # Provider payloads often arrive as JSON strings inside another request.
        # Preserve their exact text unless credentials actually need removal.
        if value.lstrip().startswith(('{', '[')):
            try:
                parsed = json.loads(value)
            except (ValueError, TypeError):
                pass
            else:
                cleaned = _safe(parsed, seen)
                if cleaned != parsed:
                    return _text(json.dumps(cleaned, ensure_ascii=False, allow_nan=False))
        return _text(value)
    if value is None or type(value) in (bool, int):
        return value
    if isinstance(value, float):
        return value if value == value and abs(value) != float('inf') else str(value)
    if isinstance(value, BaseException):
        return {'type': type(value).__name__, 'message': _safe(str(value), seen)}
    if isinstance(value, Path):
        return _text(str(value))
    if isinstance(value, (dict, list, tuple)):
        seen = set() if seen is None else seen
        identity = id(value)
        if identity in seen:
            return '[CIRCULAR]'
        seen.add(identity)
        try:
            if isinstance(value, dict):
                return {_text(str(key)): _safe(item, seen) for key, item in value.items()
                        if not _private_key(str(key))}
            return [_safe(item, seen) for item in value]
        finally:
            seen.remove(identity)
    # Object reprs can include clients, credentials or environment settings.
    return '<' + type(value).__name__ + '>'


class AuditTrail:
    """Append JSONL at ``path``; each request context is a separate attempt.

    ``scope`` is the private session identifier, retained only as a SHA256 alias.
    ``operation`` records completion metadata; callers can add detailed results
    with ``record('grade_result', diagnosis=result)`` inside the context.
    ``model_call`` accepts a zero-argument callable and returns it unchanged.
    Metadata-only traces omit teaching text, including text nested in exceptions,
    model payloads and earlier conversations. Existing traces are not rewritten.
    """
    _lock_guard = threading.Lock()
    _path_locks = {}

    def __init__(self, path, *, metadata_only=False):
        self.path = Path(path)
        self.metadata_only = metadata_only
        self._local = threading.local()
        with self._lock_guard:
            self._lock = self._path_locks.setdefault(str(self.path.absolute()), threading.RLock())
        try:
            with self._lock:
                self._prepare()
        except Exception as error:
            self._warn(error)

    @staticmethod
    def _warn(error):
        try:
            print('Course audit logging failed (' + type(error).__name__ +
                  '); the teaching operation continues.', file=sys.stderr, flush=True)
        except Exception:
            pass

    def _prepare(self):
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path.parent.chmod(0o700)
        descriptor = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.fchmod(descriptor, 0o600)
        finally:
            os.close(descriptor)

    def record(self, event, **fields):
        """Write one complete line immediately; return False on logging failure."""
        try:
            entry = {'timestamp': datetime.now(timezone.utc).isoformat(),
                     'event': str(event), 'thread_id': threading.get_ident()}
            entry.update(getattr(self._local, 'context', {}))
            if self.metadata_only:
                entry.update({key: value for key, value in fields.items()
                              if key in _METADATA_FIELDS and type(value) in (str, int, float, bool)})
                error = fields.get('error')
                if isinstance(error, BaseException):
                    entry['error'] = {'type': type(error).__name__}
                result = fields.get('result')
                if type(result) is bool:
                    entry['result'] = result
                elif isinstance(result, dict):
                    flags = {key: result[key] for key in _ASSESSMENT_FLAGS if type(result.get(key)) is bool}
                    if flags:
                        entry['result'] = flags
            else:
                entry.update({key: value for key, value in fields.items() if key not in _RESERVED})
            line = json.dumps(_safe(entry), ensure_ascii=True, allow_nan=False) + '\n'
            with self._lock:
                self._prepare()
                descriptor = os.open(self.path, os.O_WRONLY | os.O_APPEND)
                with os.fdopen(descriptor, 'a', encoding='utf-8') as stream:
                    stream.write(line)
                    stream.flush()
            return True
        except Exception as error:
            self._warn(error)
            return False

    @contextmanager
    def request(self, scope, rid, route, data):
        previous = getattr(self._local, 'context', {})
        attempt_id = uuid.uuid4().hex
        self._local.context = dict(attempt_id=attempt_id, request_id=rid, route=route,
            session_alias='session-' + hashlib.sha256(str(scope).encode('utf-8')).hexdigest()[:24])
        started, status = time.monotonic(), 'completed'
        self.record('request_start', data=data)
        try:
            yield attempt_id
        except BaseException as error:
            status = 'error'
            self.record('request_error', error=error)
            raise
        finally:
            self.record('request_end', status=status, duration_ms=round((time.monotonic() - started) * 1000, 3))
            self._local.context = previous

    @contextmanager
    def operation(self, name):
        previous = getattr(self._local, 'context', {})
        operation_id = uuid.uuid4().hex
        self._local.context = dict(previous, operation=name, operation_id=operation_id)
        if previous.get('operation_id'):
            self._local.context['parent_operation_id'] = previous['operation_id']
        started = time.monotonic()
        self.record('operation_start')
        try:
            yield operation_id
        except BaseException as error:
            self.record('operation_error', error=error,
                        duration_ms=round((time.monotonic() - started) * 1000, 3))
            raise
        else:
            self.record('operation_result', status='completed',
                        duration_ms=round((time.monotonic() - started) * 1000, 3))
        finally:
            self._local.context = previous

    def model_call(self, instruction, payload, call):
        model_call_id = uuid.uuid4().hex
        started = time.monotonic()
        self.record('model_start', model_call_id=model_call_id, instruction=instruction, payload=payload)
        try:
            result = call()
        except BaseException as error:
            self.record('model_error', model_call_id=model_call_id, error=error,
                        duration_ms=round((time.monotonic() - started) * 1000, 3))
            raise
        self.record('model_result', model_call_id=model_call_id, raw_text=result,
                    duration_ms=round((time.monotonic() - started) * 1000, 3))
        return result
