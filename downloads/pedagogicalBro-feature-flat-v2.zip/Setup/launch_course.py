"""Launch the desktop course with its own small, reusable Python environment."""
import argparse
import json
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from urllib.error import URLError
from urllib.request import ProxyHandler, build_opener
import venv
import webbrowser

ROOT = Path(__file__).resolve().parents[2]
ENVIRONMENT = ROOT / '.course-venv'
REQUIREMENTS = ROOT / 'webui' / 'requirements-course.txt'


class LaunchError(RuntimeError):
    pass


def course_ready(url):
    try:
        opener = build_opener(ProxyHandler({}))
        with opener.open(url + '/api/info', timeout=1) as response:
            info = json.loads(response.read(65536))
        return isinstance(info, dict) and info.get('app') == 'sysc4005-course'
    except (OSError, URLError, ValueError):
        return False


def prepare_python():
    python = ENVIRONMENT / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    if not ENVIRONMENT.exists():
        print('Preparing the course environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(ENVIRONMENT)
    if not python.is_file():
        raise LaunchError('The course environment is incomplete. Repair .course-venv and try again.')
    try:
        checked = subprocess.run([str(python), '-c', 'import openai, dotenv'],
                                 capture_output=True, timeout=30)
    except subprocess.TimeoutExpired:
        raise LaunchError('The course dependencies could not be read. Repair .course-venv and try again.') from None
    if checked.returncode:
        print('Installing the course runtime...', flush=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                        '-r', str(REQUIREMENTS)], cwd=ROOT, check=True)
    return python


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error('Choose a port from 1 to 65535.')
    url = f'http://127.0.0.1:{args.port}'
    child = None
    try:
        with socket.socket() as probe:
            occupied = probe.connect_ex(('127.0.0.1', args.port)) == 0
        if occupied:
            if not course_ready(url):
                raise LaunchError(f'Port {args.port} is already used by another service. Choose --port with a free port.')
            if not args.no_browser:
                webbrowser.open(url)
            print(f'SYSC4005 is ready at {url}', flush=True)
            code_file = ROOT / '.local' / 'course' / 'instructor-access-code.txt'
            if code_file.is_file():
                print(f'Instructor access code: {code_file.read_text(encoding="utf-8").strip()}', flush=True)
            return 0
        python = prepare_python()
        command = [str(python), '-m', 'AI_TA_PYTHON_CODE.pedagogical_ai.tutor_web',
                   '--port', str(args.port), '--no-browser']
        if (ROOT / '.env').is_file():
            command.extend(['--env-file', str(ROOT / '.env')])
        child = subprocess.Popen(command, cwd=ROOT, start_new_session=True)
        deadline = time.monotonic() + 30
        while not course_ready(url):
            if child.poll() is not None:
                raise LaunchError('The course could not start. Check the configuration message above.')
            if time.monotonic() >= deadline:
                raise LaunchError('The course did not become ready. Check the message above.')
            time.sleep(.2)
        if not args.no_browser:
            webbrowser.open(url)
        return child.wait()
    except KeyboardInterrupt:
        return 0
    except (LaunchError, OSError, subprocess.CalledProcessError) as exc:
        print(f'Course launch failed: {exc}', file=sys.stderr)
        return 1
    finally:
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGINT)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.terminate()
                child.wait(timeout=5)


if __name__ == '__main__':
    raise SystemExit(main())
