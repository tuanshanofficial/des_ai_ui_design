#!/bin/bash
# Double-click in Finder to start the SYSC4005 desktop course.
set -u

tutor_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)" || exit 1
tutor_python=""
tutor_system_python="$(command -v python3 || true)"

for tutor_candidate in "$tutor_root/.course-venv/bin/python" /opt/homebrew/bin/python3 /usr/local/bin/python3 "$tutor_system_python"; do
  if [[ -x "$tutor_candidate" ]] && "$tutor_candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
    tutor_python="$tutor_candidate"
    break
  fi
done

if [[ -z "$tutor_python" ]]; then
  printf 'Python 3.10 or later is required. Install Python, then open this file again.\n'
  read -r -p 'Press Return to close this window. ' tutor_response
  exit 1
fi

printf 'SYSC4005 - Carleton University\n\n'
"$tutor_python" "$tutor_root/webui/launch_course.py" "$@"
tutor_status=$?

if [[ $tutor_status -ne 0 ]]; then
  printf '\nThe tutor did not start. Review the message above.\n'
  read -r -p 'Press Return to close this window. ' tutor_response
fi
exit "$tutor_status"
