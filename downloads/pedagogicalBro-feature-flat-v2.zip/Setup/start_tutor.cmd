@echo off
setlocal
cd /d "%~dp0"
if exist "%USERPROFILE%\anaconda3\python.exe" (
    "%USERPROFILE%\anaconda3\python.exe" -B tutor_web.py %*
) else (
    python -B tutor_web.py %*
)
if errorlevel 1 pause
