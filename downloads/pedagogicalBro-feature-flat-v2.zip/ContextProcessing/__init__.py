"""Input validation, fixed project context and model context budgets."""
