"""Instructor-supplied project scope, separate from the tutoring phase."""

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class ProjectContext:
    name: str
    description: str
    stage: str
    stage_description: str
    allowed_concepts: tuple[str, ...] = ()

    def __post_init__(self):
        for field in ("name", "description", "stage", "stage_description"):
            value = getattr(self, field)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"Project context requires a nonempty {field}.")
            object.__setattr__(self, field, value.strip())
        if not isinstance(self.allowed_concepts, (tuple, list)) or any(
            not isinstance(value, str) or not value.strip() for value in self.allowed_concepts
        ):
            raise ValueError("Project allowed_concepts must be a list of nonempty strings.")
        object.__setattr__(self, "allowed_concepts", tuple(value.strip() for value in self.allowed_concepts))

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "stage": self.stage,
            "stage_description": self.stage_description,
            "allowed_concepts": list(self.allowed_concepts),
        }

    @classmethod
    def from_dict(cls, value):
        fields = {"name", "description", "stage", "stage_description", "allowed_concepts"}
        required = fields - {"allowed_concepts"}
        if not isinstance(value, dict) or not required.issubset(value) or set(value) - fields:
            raise ValueError("Project context needs name, description, stage and stage_description; "
                             "allowed_concepts is optional.")
        return cls(**value)


def load_project_context(path):
    """Read a teacher-selected JSON file; never infer an assigned project."""
    if path is None:
        raise ValueError("Set --project-context to a JSON file describing the assigned DES project "
                         "and its current stage.")
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise ValueError("Could not read the project-context JSON file.") from None
    return ProjectContext.from_dict(data)
