"""Safe application errors shared by model transport and context preparation."""


class ModelError(RuntimeError):
    """The model request or its response could not be used safely."""
