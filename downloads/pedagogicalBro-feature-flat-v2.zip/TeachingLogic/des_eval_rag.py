"""Independent Carleton DES answers with hybrid textbook RAG and model grading.

Install: pip install openai python-dotenv sentence-transformers faiss-cpu numpy rank-bm25
Run: python des_eval_rag.py --help
Keep des_eval_no_rag.py and the existing retrieval files alongside this file.
"""
from des_eval_no_rag import run


def build_retriever():
    import des_rag_policy_v3 as rag
    import faiss
    from rank_bm25 import BM25Okapi
    from sentence_transformers import SentenceTransformer
    passages = rag.load_jsonl(rag.PASSAGES_PATH)
    parents = {chunk['chunk_id']: chunk for chunk in rag.load_jsonl(rag.CHUNKS_PATH)}
    if not passages or not parents:
        raise ValueError('Retrieval passages and parent chunks must not be empty.')
    index = faiss.read_index(str(rag.FAISS_PATH))
    if index.ntotal != len(passages):
        raise ValueError('FAISS index and passage metadata are not aligned.')
    bm25 = BM25Okapi([rag.tokenize(p.get('text', '')) for p in passages])
    embedder = SentenceTransformer(rag.EMBED_MODEL)

    def get_context(question):
        # Query only the question, never the reference answer or prior results.
        selected = rag.retrieve(question, embedder, index, bm25, passages, parents, method='dual')
        if not selected:
            raise ValueError('No textbook context retrieved; refusing a silent non-RAG answer.')
        return rag.make_context(selected, parents)

    return get_context


if __name__ == '__main__':
    run(build_retriever)
