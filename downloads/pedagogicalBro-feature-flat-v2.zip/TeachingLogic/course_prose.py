"""Validate public teaching prose without choosing among model alternatives."""
import json
import re

from AI_TA_PYTHON_CODE.pedagogical_ai.course_judgment import parse_judgment


MAX_PROSE_BYTES = 64 * 1024
_PUBLIC_FIELDS = {'explanation', 'answer', 'response', 'text'}
_OBJECT = re.compile(r'\{(?:\s|\\[nrt])*"(?:[^"\\]|\\.)*"\s*:')
_JSON_FENCE = re.compile(r'```[ \t]*json\b', re.I)
_FULL_FENCE = re.compile(r'```(?:json)?[ \t]*\r?\n([\s\S]*?)\r?\n```', re.I)
_FORMAT_TAIL = re.compile(r'(?:[.!?。！？][ \t]+|\n[ \t]*)JSON[ \t]*\Z')
_LATEX = re.compile(r'\\(?:[()[\]]|(?:frac|text|begin|end|times|cdot|boxed)\b)')
_JOINED_SENTENCES = re.compile(r'[a-z][?!][A-Z][a-z]{2}')


class PublicProseError(ValueError):
    """The draft contains an ambiguous wrapper or output-format residue."""


def public_prose(raw, *, allow_wrapper=True, plain_math=False):
    """Preserve ordinary prose, or unwrap one strictly valid public string.

    No malformed JSON is repaired, no competing objects are selected, and no
    suffix is silently removed. Object-shaped JSON anywhere else requires a
    new draft. Mathematical braces, Markdown links and normal mentions of the
    JSON format are left intact. ``allow_wrapper=False`` requires prose even
    when the entire draft is an otherwise valid public output wrapper.
    """
    if not isinstance(raw, str) or not raw.strip():
        raise PublicProseError('The teaching reply must contain nonempty text.')
    try:
        size = len(raw.encode('utf-8'))
    except UnicodeError:
        raise PublicProseError('The teaching reply contains invalid text encoding.') from None
    if size > MAX_PROSE_BYTES:
        raise PublicProseError('The teaching reply exceeds the supported size.')
    text = raw.strip()
    candidate = text
    fence = _FULL_FENCE.fullmatch(text)
    if fence:
        candidate = fence[1].strip()
    wrapped = _OBJECT.match(candidate) or _JSON_FENCE.match(text)
    if wrapped and allow_wrapper:
        # The shared parser rejects duplicate fields and multiple alternatives;
        # loads also requires this entire candidate to be a single JSON value.
        try:
            body = parse_judgment(candidate)
            json.loads(candidate)
        except (ValueError, TypeError, RecursionError, OverflowError):
            raise PublicProseError('The teaching reply contains malformed or ambiguous JSON.') from None
        if (len(body) != 1 or next(iter(body)) not in _PUBLIC_FIELDS
                or not isinstance(next(iter(body.values())), str)):
            raise PublicProseError('The teaching reply contains unexpected or private fields.')
        text = next(iter(body.values())).strip()
        if not text:
            raise PublicProseError('The public reply wrapper contains no explanation.')
    if _OBJECT.search(text) or _JSON_FENCE.search(text):
        raise PublicProseError('The teaching reply contains a JSON object or format fence.')
    if text == 'JSON' or _FORMAT_TAIL.search(text):
        raise PublicProseError('The teaching reply contains a trailing format marker.')
    if _JOINED_SENTENCES.search(text):
        raise PublicProseError('The teaching reply joins separate drafts without spacing.')
    if plain_math and _LATEX.search(text):
        raise PublicProseError('This teaching page requires plain-text formulas.')
    return text
