"""Read one unambiguous JSON judgment without choosing among model alternatives.

A model may surround its JSON with a fence or ordinary explanatory prose.
That does not make multiple, malformed or non-object judgments safe to accept.
Schema and teaching-contract validation remain the caller's responsibility.
"""
import json
import math
import re


MAX_JUDGMENT_BYTES = 64 * 1024


class JudgmentParseError(ValueError):
    """The model did not return exactly one strict JSON judgment object."""


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise JudgmentParseError('The judgment contains duplicate object fields.')
        result[key] = value
    return result


def _constant(_):
    raise JudgmentParseError('The judgment contains a non-finite numeric value.')


def _float(value):
    number = float(value)
    if not math.isfinite(number):
        raise JudgmentParseError('The judgment contains a non-finite numeric value.')
    return number


_DECODER = json.JSONDecoder(object_pairs_hook=_object, parse_constant=_constant,
                            parse_float=_float)


def _bounded(value):
    pending = [(value, 1)]
    visited = 0
    while pending:
        item, depth = pending.pop()
        visited += 1
        if depth > 64 or visited > 10000:
            raise JudgmentParseError('The judgment structure exceeds the supported size.')
        if isinstance(item, dict):
            pending.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            pending.extend((child, depth + 1) for child in item)


def _envelope(text):
    """Do not mistake extra standalone JSON values for explanatory wrapping."""
    text = re.sub(r'```(?:[A-Za-z0-9_-]+)?', '', text).strip()
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if (line.casefold() in {'true', 'false', 'null', 'none', 'nan', 'infinity', '-infinity'}
                or re.fullmatch(r'-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?', line)):
            raise JudgmentParseError('The response contains more than one judgment value.')
        try:
            _DECODER.decode(line)
        except (ValueError, RecursionError, OverflowError):
            continue
        raise JudgmentParseError('The response contains more than one judgment value.')


def parse_judgment(raw):
    """Return the sole JSON object, allowing only non-JSON prose around it.

    ``raw_decode`` consumes nested arrays/objects and braces inside JSON strings
    as one value. Every structural opening outside that value is inspected;
    malformed alternatives are rejected rather than skipped. Consequently a
    second object is rejected even when its fields agree with the first one.
    No attempt is made to repair JSON or combine competing reviewer outputs.
    """
    if not isinstance(raw, str) or not raw.strip():
        raise JudgmentParseError('The model returned no judgment text.')
    try:
        size = len(raw.encode('utf-8'))
    except UnicodeError:
        raise JudgmentParseError('The judgment contains invalid text encoding.') from None
    if size > MAX_JUDGMENT_BYTES:
        raise JudgmentParseError('The judgment text exceeds the supported size.')
    text = raw.strip().removeprefix('\ufeff').strip()
    values = []
    cursor = 0
    while cursor < len(text):
        char = text[cursor]
        if char in '{[':
            try:
                value, end = _DECODER.raw_decode(text, cursor)
            except (ValueError, RecursionError, OverflowError):
                raise JudgmentParseError('The response contains malformed or ambiguous JSON.') from None
            values.append((value, cursor, end))
            if len(values) > 1:
                raise JudgmentParseError('The response contains multiple judgment values.')
            cursor = end
        elif char in '}]':
            raise JudgmentParseError('The response contains unmatched JSON delimiters.')
        else:
            cursor += 1
    if not values:
        raise JudgmentParseError('The response contains no JSON judgment object.')
    value, start, end = values[0]
    if not isinstance(value, dict):
        raise JudgmentParseError('The judgment must be a JSON object.')
    _bounded(value)
    _envelope(text[:start])
    _envelope(text[end:])
    return value
