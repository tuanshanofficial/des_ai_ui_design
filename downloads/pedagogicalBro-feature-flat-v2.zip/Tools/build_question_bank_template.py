"""Build the instructor Word upload template using bundled python-docx.

This is a developer authoring helper. The course server reads the finished
asset and needs no Word authoring dependency at runtime.
"""
from pathlib import Path
import sys

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from AI_TA_PYTHON_CODE.pedagogical_ai.course_upload import MARKER, TEMPLATE_PATH


def fill(cell, color):
    shade = OxmlElement('w:shd')
    shade.set(qn('w:fill'), color)
    cell._tc.get_or_add_tcPr().append(shade)


def question_table(document, kind):
    values = [
        ('Lecture', '1'), ('Objective', '1'), ('Question type', kind),
        ('Ready to import', 'No'),
        ('Prompt', '[[Replace with the complete question students must answer]]'),
        ('Option A', '[[Replace with the first option]]' if kind == 'Multiple choice' else ''),
        ('Option B', '[[Replace with the second option]]' if kind == 'Multiple choice' else ''),
        ('Option C', '[[Replace with the third option]]' if kind == 'Multiple choice' else ''),
        ('Option D', '[[Replace with the fourth option]]' if kind == 'Multiple choice' else ''),
        ('Correct option', '[[A B C or D]]' if kind == 'Multiple choice' else ''),
        ('Answer', '[[Replace with the instructor reference answer]]'),
        ('Rubric', '[[Replace with the essential marking criteria]]'),
        ('Context', ''), ('Data table', ''),
    ]
    table = document.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(1.57)
    table.columns[1].width = Inches(5.73)
    for cell, text in zip(table.rows[0].cells, ('Field', 'Value')):
        cell.text = text
        fill(cell, '333333')
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.color.rgb = RGBColor.from_string('FFFFFF')
    repeat = OxmlElement('w:tblHeader')
    table.rows[0]._tr.get_or_add_trPr().append(repeat)
    for index, (name, value) in enumerate(values):
        row = table.add_row()
        row.cells[0].text, row.cells[1].text = name, value
        row.cells[0].paragraphs[0].runs[0].bold = True
        if index % 2 == 0:
            for cell in row.cells:
                fill(cell, 'F5F5F5')
    for row in table.rows:
        cant_split = OxmlElement('w:cantSplit')
        row._tr.get_or_add_trPr().append(cant_split)
        for col, cell in enumerate(row.cells):
            cell.width = Inches(1.57 if col == 0 else 5.73)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            props = cell._tc.get_or_add_tcPr()
            margins = OxmlElement('w:tcMar')
            for edge in ('top', 'left', 'bottom', 'right'):
                node = OxmlElement('w:' + edge)
                node.set(qn('w:w'), '90' if edge in ('top', 'bottom') else '115')
                node.set(qn('w:type'), 'dxa')
                margins.append(node)
            props.append(margins)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.08
                for run in paragraph.runs:
                    run.font.size = Pt(10.5)
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement('w:' + edge)
        for key, value in {'val': 'single', 'sz': '5', 'color': 'D9D9D9'}.items():
            border.set(qn('w:' + key), value)
        borders.append(border)
    table._tbl.tblPr.append(borders)


def main():
    document = Document()
    section = document.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(0.6)
    section.left_margin = section.right_margin = Inches(0.6)
    normal = document.styles['Normal']
    normal.font.name, normal.font.size = 'Arial', Pt(10.5)
    normal.font.color.rgb = RGBColor.from_string('000000')
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.12
    for name in ('Title', 'Subtitle', 'Heading 1', 'Heading 2', 'Heading 3'):
        style = document.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor.from_string('000000')
        style.font.underline = False
        for color in style.element.xpath('.//w:color'):
            for attribute in ('themeColor', 'themeTint', 'themeShade'):
                color.attrib.pop(qn('w:' + attribute), None)
    for border in document.styles.element.xpath('.//w:pBdr'):
        border.getparent().remove(border)
    document.styles['Title'].font.size = Pt(22)
    document.styles['Title'].paragraph_format.space_after = Pt(10)
    document.styles['Heading 2'].font.size = Pt(14)
    document.styles['Heading 2'].paragraph_format.space_before = Pt(10)
    document.styles['Heading 2'].paragraph_format.space_after = Pt(8)
    document.add_paragraph('SYSC4005 question bank template', 'Title')
    document.add_paragraph('Complete this Word file to add instructor questions to the course. '
                           'Upload it in the Instructor Portal, review the preview, and confirm the import.')
    document.add_paragraph('Keep the Field and Value labels and the format line below. '
                           'Replace every [[placeholder]], then set Ready to import to Yes. '
                           'Copy a question table for each additional item and delete unused examples.')
    document.add_paragraph('Use Lecture 1 or 2 with Objective 1 to 7, or Lecture 3 with Objective 1 to 9. '
                           'For short answers, leave all options and Correct option empty. '
                           'Context and Data table are optional.')
    document.add_paragraph(MARKER)
    document.add_paragraph('Multiple choice question', 'Heading 2')
    question_table(document, 'Multiple choice')
    document.add_page_break()
    document.add_paragraph('Short answer question', 'Heading 2')
    document.add_paragraph('Copy this table for another short answer. '
                           'An optional data table can be inserted inside the Data table value cell. '
                           'Alternatively, enter one row per line and separate cells with |.')
    question_table(document, 'Short answer')
    document.add_paragraph('Before uploading', 'Heading 2')
    document.add_paragraph('Check the lecture, objective, student question, reference answer and marking criteria. '
                           'The entire file must pass validation before any questions are added. '
                           'Importing a bank affects new assignments; saved student work is preserved.')
    properties = document.core_properties
    properties.title = 'SYSC4005 question bank template'
    properties.subject = 'Instructor question-bank upload format'
    properties.author = ''
    properties.last_modified_by = ''
    TEMPLATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    document.save(TEMPLATE_PATH)
    print(TEMPLATE_PATH)


if __name__ == '__main__':
    main()
