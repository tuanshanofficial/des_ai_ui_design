"""Reject local-language prose in tracked or staged repository text files.

The default checks tracked working files; --staged checks actual index bytes.
Local review archives and ignored reports are deliberately outside this check.
Unicode escape sequences in multilingual input tests remain ordinary code.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
LOCAL_PROSE = re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff]')


def check(staged=False):
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    failures = []
    checked = 0
    for name in filter(None, paths):
        try:
            if staged:
                data = subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT, stderr=subprocess.DEVNULL)
            else:
                data = (ROOT / name).read_bytes()
            if b'\x00' in data:
                continue
            text = data.decode('utf-8')
        except (OSError, UnicodeError, subprocess.CalledProcessError):
            continue
        checked += 1
        match = LOCAL_PROSE.search(text)
        if match:
            line = text.count('\n', 0, match.start()) + 1
            failures.append(f'{name}:{line}')
    return checked, failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--staged', action='store_true')
    args = parser.parse_args()
    checked, failures = check(args.staged)
    if failures:
        print('Local-language prose must stay in ignored local artifacts:', file=sys.stderr)
        print('\n'.join(failures), file=sys.stderr)
        return 1
    print(f'English repository check passed: {checked} tracked text files.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
