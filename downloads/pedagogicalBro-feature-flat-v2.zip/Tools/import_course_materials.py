#!/usr/bin/env python3
"""Import original instructor documents and render supplied slide PDFs.

Usage: python scripts/import_course_materials.py --source-dir '/path/to/course package'
Requires PyMuPDF for this one-time conversion. The running course server needs
only the imported files and Python's standard library. Originals are copied
byte-for-byte and are never edited. Existing different originals are refused.
"""
import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from AI_TA_PYTHON_CODE.pedagogical_ai.course_bank import block_text, load_banks, read_docx_blocks
from AI_TA_PYTHON_CODE.pedagogical_ai.course_materials import DEFAULT_ROOT, LESSONS_PATH, file_sha256


TITLES = {1: 'Introduction to Simulation', 2: 'Simulation Examples',
          3: 'General Principles and Simulation Software', 4: 'Statistical Models',
          5: 'Random Number Generation', 6: 'Random Variate Generation'}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def page_title(text, fallback):
    for line in text.splitlines():
        line = line.strip()
        if (len(line) > 2 and not line.isdecimal()
                and not line.startswith(('SYSC ', 'Prof.', 'Department of ', '©'))):
            return line
    return fallback


def discover_slide_pdfs(source_dir):
    """Discover supplied numbered course decks without a five-lecture ceiling."""
    pdfs = {}
    for path in sorted(Path(source_dir).iterdir()):
        if not path.is_file():
            continue
        match = re.fullmatch(r'(\d+)\s*[-_]\s*SYSC4005[ _-]+(.+)\.pdf', path.name, re.I)
        if not match:
            continue
        lecture = int(match[1])
        if lecture < 1:
            raise ValueError('Slide lecture numbers must be positive.')
        if lecture in pdfs:
            raise ValueError(f'Expected exactly one supplied slide PDF for lecture {lecture}.')
        pdfs[lecture] = path
    for lecture in (1, 2, 3):
        if lecture not in pdfs:
            raise ValueError(f'Expected a supplied slide PDF starting with {lecture:02d} - SYSC4005.')
    return dict(sorted(pdfs.items()))


def lecture_title(lecture, path):
    """Use established titles or preserve the title from the supplied filename."""
    if lecture in TITLES:
        return TITLES[lecture]
    title = re.sub(r'^\d+\s*[-_]\s*SYSC4005[ _-]+', '', Path(path).stem, flags=re.I)
    return re.sub(r'[_\s]+', ' ', title).strip()


def import_materials(source_dir, output_dir=DEFAULT_ROOT, image_width=1280):
    try:
        import pymupdf
    except ImportError:
        raise SystemExit('Install the conversion dependency first: python -m pip install pymupdf') from None
    source_dir, output_dir = Path(source_dir).resolve(), Path(output_dir).resolve()
    if image_width < 640 or image_width > 2400:
        raise ValueError('Slide-image width must be between 640 and 2400 pixels.')
    banks = load_banks(source_dir)
    pdfs = discover_slide_pdfs(source_dir)
    teaching_lectures = {int(lesson['lecture']) for lesson in
                         json.loads(LESSONS_PATH.read_text(encoding='utf-8'))}
    source_files = [source_dir / f'Lecture_{n}.docx' for n in (1, 2, 3)]
    source_files += [source_dir / 'Project Proposal.docx'] + list(pdfs.values())
    for source in source_files:
        if not source.is_file():
            raise FileNotFoundError(f'Missing source document: {source.name}')
        target = output_dir / 'source' / source.name
        if target.exists() and file_sha256(target) != file_sha256(source):
            raise FileExistsError(f'Refusing to replace a different imported original: {target.name}')
    original_hashes = {path.name: file_sha256(path) for path in source_files}
    (output_dir / 'source').mkdir(parents=True, exist_ok=True)
    documents = []
    for source in source_files:
        target = output_dir / 'source' / source.name
        if not target.exists():
            shutil.copyfile(source, target)
        if file_sha256(target) != original_hashes[source.name]:
            raise ValueError(f'Imported original differs from supplied document: {source.name}')
    for lecture, bank in banks.items():
        name = f'Lecture_{lecture}.docx'
        documents.append(dict(kind='question_bank', lecture=lecture, filename=name,
                              path=f'source/{name}', sha256=original_hashes[name],
                              size_bytes=(source_dir / name).stat().st_size,
                              question_count=len(bank), objective_count=len({q['lo'] for q in bank}),
                              prompt_table_count=sum(len(q['table']) for q in bank)))
    project_source = source_dir / 'Project Proposal.docx'
    project_blocks = read_docx_blocks(project_source)
    project = dict(title=project_blocks[0]['text'], filename=project_source.name,
                   sha256=original_hashes[project_source.name], blocks=project_blocks,
                   text='\n\n'.join(block_text(block) for block in project_blocks))
    write_json(output_dir / 'project.json', project)
    documents.append(dict(kind='project', filename=project_source.name, title=project['title'],
                          path=f'source/{project_source.name}', text_path='project.json',
                          sha256=project['sha256'], size_bytes=project_source.stat().st_size))
    for lecture, pdf in pdfs.items():
        title = lecture_title(lecture, pdf)
        pages = []
        folder = output_dir / 'slides' / f'lecture-{lecture}'
        folder.mkdir(parents=True, exist_ok=True)
        with pymupdf.open(pdf) as document:
            for index, page in enumerate(document, 1):
                text = page.get_text('text', sort=True)
                relative_image = f'slides/lecture-{lecture}/page-{index:03d}.png'
                scale = image_width / page.rect.width
                image = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
                image.save(output_dir / relative_image)
                pages.append(dict(page=index, title=page_title(text, f'{title} - slide {index}'),
                                  text=text, image_path=relative_image,
                                  width=image.width, height=image.height))
        pages_path = f'slides/lecture-{lecture}/pages.json'
        write_json(output_dir / pages_path, pages)
        documents.append(dict(kind='slides', lecture=lecture, title=title,
                              filename=pdf.name, path=f'source/{pdf.name}',
                              sha256=original_hashes[pdf.name], size_bytes=pdf.stat().st_size,
                              page_count=len(pages), pages_path=pages_path,
                              teaching_lecture=lecture if lecture in teaching_lectures else None))
    for source in source_files:
        if file_sha256(source) != original_hashes[source.name]:
            raise ValueError(f'An original changed during import: {source.name}')
    manifest = dict(schema_version=1, imported_at=datetime.now(timezone.utc).isoformat(),
                    provenance='Original course package supplied by the instructor; no questions or answers generated.',
                    extraction=dict(pdf=f'PyMuPDF {importlib.metadata.version("pymupdf")}',
                                    docx='WordprocessingML paragraphs and tables; original files retained',
                                    slide_image_width=image_width), documents=documents)
    write_json(output_dir / 'manifest.json', manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', required=True, type=Path)
    parser.add_argument('--output-dir', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--image-width', type=int, default=1280)
    args = parser.parse_args()
    manifest = import_materials(args.source_dir, args.output_dir, args.image_width)
    print(json.dumps(dict(output_dir=str(args.output_dir.resolve()),
                          source_documents=len(manifest['documents']),
                          questions=sum(doc.get('question_count', 0) for doc in manifest['documents']),
                          slide_pages=sum(doc.get('page_count', 0) for doc in manifest['documents'])), indent=2))


if __name__ == '__main__':
    main()
