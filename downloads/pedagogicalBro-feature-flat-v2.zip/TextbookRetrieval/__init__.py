"""Dense embeddings, BM25, rank fusion and bounded source construction."""
