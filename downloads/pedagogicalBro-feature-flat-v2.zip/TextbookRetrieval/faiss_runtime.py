"""Keep FAISS's native OpenMP runtime outside the Torch/transformers process.

macOS wheels of Torch and FAISS bundle different libomp libraries. Loading both
in the tutoring process caused native crashes that Python cannot catch. A spawned
worker owns FAISS indexes; the parent exchanges only paths, numbers and NumPy
arrays. No index files or ranking operations are changed.
"""

import atexit
import math
import multiprocessing
import os
import threading
import weakref


_RUNTIMES = weakref.WeakSet()


def _serve(connection):
    """Worker entry point; imports must stay independent of Torch."""
    import sys
    try:
        if "torch" in sys.modules:
            raise RuntimeError("Unsafe main-module bootstrap imported Torch into the FAISS worker.")
        import faiss
        import numpy as np
        connection.send(("ready", {"metric_inner_product": int(faiss.METRIC_INNER_PRODUCT)}))
    except Exception as exc:
        connection.send(("startup_error", type(exc).__name__))
        connection.close()
        return

    indexes = {}
    next_identifier = 0
    try:
        while True:
            try:
                operation, arguments = connection.recv()
            except EOFError:
                break
            if operation == "close":
                connection.send(("ok", None))
                break
            try:
                if operation in ("read_index", "create_flat"):
                    index = (faiss.read_index(arguments[0]) if operation == "read_index"
                             else faiss.IndexFlatIP(arguments[0]))
                    identifier = next_identifier
                    next_identifier += 1
                    indexes[identifier] = index
                    result = {"identifier": identifier, "ntotal": int(index.ntotal),
                              "d": int(index.d), "metric_type": int(index.metric_type)}
                elif operation == "search":
                    identifier, vectors, count = arguments
                    result = indexes[identifier].search(np.ascontiguousarray(vectors, dtype="float32"), count)
                elif operation == "add":
                    identifier, vectors = arguments
                    indexes[identifier].add(np.ascontiguousarray(vectors, dtype="float32"))
                    result = int(indexes[identifier].ntotal)
                elif operation == "reconstruct_n":
                    identifier, start, count = arguments
                    result = indexes[identifier].reconstruct_n(start, count)
                elif operation == "info":
                    result = {"pid": os.getpid(), "torch_loaded": "torch" in sys.modules,
                              "faiss_loaded": "faiss" in sys.modules,
                              "numpy_loaded": "numpy" in sys.modules,
                              "indexes": len(indexes)}
                else:
                    raise ValueError("Unknown FAISS worker operation.")
                connection.send(("ok", result))
            except Exception as exc:
                # Paths/vectors and exception bodies never enter browser errors.
                connection.send(("error", type(exc).__name__))
    except (EOFError, OSError, BrokenPipeError):
        pass
    finally:
        connection.close()


def _shutdown(process, connection):
    """Bounded cleanup also handles a worker stuck inside native code."""
    try:
        connection.close()
    except OSError:
        pass
    try:
        process.join(timeout=0.5)
        if process.is_alive():
            process.terminate()
            process.join(timeout=1.0)
    except (OSError, ValueError, AssertionError):
        pass


class RemoteIndex:
    """The small FAISS interface consumed by the existing retriever."""

    def __init__(self, runtime, metadata):
        self._runtime = runtime
        self._identifier = metadata["identifier"]
        self.ntotal = metadata["ntotal"]
        self.d = metadata["d"]
        self.metric_type = metadata["metric_type"]

    def search(self, vectors, count):
        return self._runtime._call("search", self._identifier, vectors, count)

    def add(self, vectors):
        self.ntotal = self._runtime._call("add", self._identifier, vectors)

    def reconstruct_n(self, start, count):
        return self._runtime._call("reconstruct_n", self._identifier, start, count)

    def close(self):
        """Close the native worker shared by indexes from this factory."""
        self._runtime.close()


class FaissRuntime:
    """One serialized pipe and one spawned native worker per retrieval factory."""

    def __init__(self, *, timeout=30.0):
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or not math.isfinite(timeout) or timeout <= 0):
            raise ValueError("FAISS worker timeout must be positive.")
        self.timeout = float(timeout)
        self._lock = threading.Lock()
        self._closed = False
        context = multiprocessing.get_context("spawn")
        self._connection, child_connection = context.Pipe()
        self._process = context.Process(target=_serve, args=(child_connection,),
                                        name="des-faiss-native", daemon=True)
        try:
            self._process.start()
        except Exception:
            self._connection.close()
            child_connection.close()
            raise RuntimeError("Could not start the isolated FAISS worker.") from None
        child_connection.close()
        self._finalizer = weakref.finalize(self, _shutdown, self._process, self._connection)
        _RUNTIMES.add(self)
        try:
            status, metadata = self._receive("startup")
            if status != "ready":
                raise RuntimeError("FAISS worker initialization failed; keep Torch/model startup inside the main guard.")
            self.METRIC_INNER_PRODUCT = metadata["metric_inner_product"]
        except Exception:
            self.close()
            raise

    def _receive(self, operation):
        try:
            if not self._connection.poll(self.timeout):
                raise RuntimeError(f"FAISS worker timed out during {operation}.")
            return self._connection.recv()
        except (EOFError, OSError, BrokenPipeError):
            raise RuntimeError(f"FAISS worker exited during {operation}.") from None

    def _call(self, operation, *arguments):
        with self._lock:
            if self._closed:
                raise RuntimeError("The FAISS worker is closed.")
            try:
                self._connection.send((operation, arguments))
                status, result = self._receive(operation)
            except (RuntimeError, EOFError, OSError, BrokenPipeError):
                self._closed = True
                self._finalizer()
                raise RuntimeError(f"FAISS worker failed or timed out during {operation}.") from None
            if status != "ok":
                raise RuntimeError(f"FAISS {operation} failed ({result}).")
            return result

    def read_index(self, path):
        return RemoteIndex(self, self._call("read_index", str(path)))

    def IndexFlatIP(self, dimension):
        return RemoteIndex(self, self._call("create_flat", dimension))

    def info(self):
        return self._call("info")

    def close(self):
        # Closing the parent pipe lets an idle worker exit on EOF. Termination
        # bounds cleanup if the worker has stopped responding in native code.
        self._closed = True
        if hasattr(self, "_finalizer"):
            self._finalizer()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def get_faiss_api(*, timeout=30.0):
    return FaissRuntime(timeout=timeout)


def _close_all():
    for runtime in list(_RUNTIMES):
        runtime.close()


atexit.register(_close_all)
