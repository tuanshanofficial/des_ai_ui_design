"""Hybrid textbook retrieval with optional dependencies loaded by the factory.

The existing corpus and vector index remain read-only. Structural checks cannot
prove which embedding model produced an index or establish its row ordering.
"""

from dataclasses import dataclass
import hashlib
import json
import math
import operator
from pathlib import Path
import re
from typing import Any

from .faiss_runtime import get_faiss_api


@dataclass(frozen=True)
class Source:
    number: int
    chunk_id: str
    chapter_title: str
    page_start: int | None
    page_end: int | None
    text: str


def _source_header(source: Source) -> str:
    start = source.page_start if source.page_start is not None else "unknown"
    end = source.page_end if source.page_end is not None else "unknown"
    return (
        f"[Source {source.number}] Chapter: {source.chapter_title}; "
        f"PDF pages: {start}-{end}; chunk ID: {source.chunk_id}\n"
    )


@dataclass(frozen=True)
class RetrievalResult:
    query: str
    sources: tuple[Source, ...]

    @property
    def context(self) -> str:
        return "\n\n".join(_source_header(source) + source.text for source in self.sources)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    """Load JSON objects and report malformed records with their line numbers."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Missing required data file: {path}")
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in {path.name}, line {line_number}: {exc.msg}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"Expected a JSON object in {path.name}, line {line_number}")
            rows.append(row)
    return rows


def tokenize(text: str) -> list[str]:
    """Keep the prototype's ASCII-English BM25 tokenizer; other scripts need one."""
    return re.findall(r"[a-z0-9]+", text.lower())


def _validate_records(rows: list[dict[str, Any]], id_field: str, filename: str) -> None:
    if not rows:
        raise ValueError(f"No records found in {filename}")
    seen = set()
    for row_number, row in enumerate(rows, 1):
        identifier = row.get(id_field)
        if not isinstance(identifier, str) or not identifier.strip():
            raise ValueError(f"{filename} record {row_number} needs a nonempty {id_field}")
        if identifier in seen:
            raise ValueError(f"Duplicate {id_field} {identifier!r} in {filename}")
        seen.add(identifier)
        text = row.get("text")
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{filename} record {identifier!r} needs nonempty text")
        for field in ("page_start", "page_end"):
            value = row.get(field)
            if value is not None and (isinstance(value, bool) or not isinstance(value, int)):
                raise ValueError(f"Invalid {field} for {identifier!r} in {filename}")
        start, end = row.get("page_start"), row.get("page_end")
        if start is not None and end is not None and start > end:
            raise ValueError(f"Reversed page span for {identifier!r} in {filename}")
        title = row.get("chapter_title")
        if title is not None and (not isinstance(title, str) or not title.strip()):
            raise ValueError(f"Invalid chapter_title for {identifier!r} in {filename}")


class HybridRetriever:
    """Fuse dense retrieval and positive BM25 matches using reciprocal ranks."""

    def __init__(
        self,
        embedder,
        index,
        bm25,
        passages,
        parents,
        candidates=20,
        top_parents=3,
        max_context_chars=18000,
        method="dual",
    ):
        for name, value in (
            ("candidates", candidates),
            ("top_parents", top_parents),
            ("max_context_chars", max_context_chars),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        self.embedder = embedder
        self.index = index
        self.bm25 = bm25
        self.passages = passages
        self.parents = parents
        self.candidates = candidates
        self.top_parents = top_parents
        self.max_context_chars = max_context_chars
        if method not in ("dual", "bm25", "semantic"):
            raise ValueError("method must be dual, bm25, or semantic")
        self.method = method

    def close(self):
        """Release the isolated native worker owned by a factory-built index."""
        close = getattr(self.index, "close", None)
        if callable(close):
            close()

    def retrieve(self, query: str) -> RetrievalResult:
        if not isinstance(query, str):
            raise TypeError("query must be a string")
        if not query.strip() or not self.passages:
            return RetrievalResult(query=query, sources=())

        count = min(self.candidates, len(self.passages))
        dense = []
        if self.method in ("dual", "semantic"):
            vector = self.embedder.encode(
                [query], normalize_embeddings=True, convert_to_numpy=True
            ).astype("float32")
            _, ids = self.index.search(vector, count)
            seen_ids = set()
            for value in ids[0]:
                try:
                    identifier = operator.index(value)
                except TypeError:
                    continue
                if isinstance(value, bool) or not 0 <= identifier < len(self.passages):
                    continue
                if identifier not in seen_ids:
                    dense.append(identifier)
                    seen_ids.add(identifier)

        sparse_scores = []
        scores = self.bm25.get_scores(tokenize(query)) if self.method in ("dual", "bm25") else ()
        for identifier, value in enumerate(scores):
            if identifier >= len(self.passages):
                break
            score = float(value)
            if math.isfinite(score) and score > 0:
                sparse_scores.append((identifier, score))
        sparse = [
            identifier
            for identifier, _ in sorted(sparse_scores, key=lambda pair: (-pair[1], pair[0]))[:count]
        ]

        fused = {}
        for ranking in (dense, sparse):
            for rank, identifier in enumerate(ranking, 1):
                fused[identifier] = fused.get(identifier, 0.0) + 1.0 / (60 + rank)

        sources = []
        seen_parents = set()
        used_chars = 0
        for identifier in sorted(fused, key=lambda identifier: (-fused[identifier], identifier)):
            passage = self.passages[identifier]
            parent_id = passage.get("parent_chunk_id")
            if parent_id in seen_parents or parent_id not in self.parents:
                continue
            parent = self.parents[parent_id]
            source = Source(
                number=len(sources) + 1,
                chunk_id=parent_id,
                chapter_title=parent.get("chapter_title", passage.get("chapter_title", "Unknown")),
                page_start=parent.get("page_start", passage.get("page_start")),
                page_end=parent.get("page_end", passage.get("page_end")),
                text="",
            )
            separator_chars = 2 if sources else 0
            available = self.max_context_chars - used_chars - separator_chars - len(_source_header(source))
            text = parent["text"]
            if len(text) > available:
                text = passage["text"]
                note = "\n[Selected passage excerpt; full parent chunk omitted.]"
                if len(text) + len(note) > available:
                    note = "\n[Passage excerpt truncated to fit context limit.]"
                    if available <= len(note):
                        continue
                    text = text[: available - len(note)] + note
                else:
                    text += note
            source = Source(
                number=source.number,
                chunk_id=source.chunk_id,
                chapter_title=source.chapter_title,
                page_start=source.page_start,
                page_end=source.page_end,
                text=text,
            )
            sources.append(source)
            seen_parents.add(parent_id)
            used_chars += separator_chars + len(_source_header(source)) + len(source.text)
            if len(sources) >= self.top_parents:
                break
        return RetrievalResult(query=query, sources=tuple(sources))

    @classmethod
    def from_directory(
        cls,
        base: Path,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        *,
        method: str = "dual",
        _embedder=None,
        _faiss_api=None,
    ) -> "HybridRetriever":
        """Load local artifacts, checking structure before constructing the model.

        Count and dimension checks do not verify vector order or model identity.
        Model construction uses sentence-transformers' normal cache behavior.
        """
        base = Path(base)
        paths = {name: base / name for name in ("chunks.jsonl", "des_passages.jsonl", "des_passages.faiss")}
        for path in paths.values():
            if not path.is_file():
                raise FileNotFoundError(f"Missing required data file: {path}")
        chunks = load_jsonl(paths["chunks.jsonl"])
        passages = load_jsonl(paths["des_passages.jsonl"])
        _validate_records(chunks, "chunk_id", "chunks.jsonl")
        _validate_records(passages, "passage_id", "des_passages.jsonl")
        parents = {chunk["chunk_id"]: chunk for chunk in chunks}
        for passage in passages:
            parent_id = passage.get("parent_chunk_id")
            if not isinstance(parent_id, str) or parent_id not in parents:
                raise ValueError(f"Unknown parent_chunk_id for passage {passage['passage_id']!r}")
            if "parent_index" in passage:
                position = passage["parent_index"]
                if (
                    isinstance(position, bool)
                    or not isinstance(position, int)
                    or not 0 <= position < len(chunks)
                    or chunks[position]["chunk_id"] != parent_id
                ):
                    raise ValueError(f"Invalid parent_index for passage {passage['passage_id']!r}")
            for field in ("chapter_title", "page_start", "page_end"):
                parent = parents[parent_id]
                if field not in passage or field not in parent:
                    continue
                child_value, parent_value = passage[field], parent[field]
                # Child passages may cover only part of their parent page range.
                # Book 1 copies parent spans; the newer books use narrower spans.
                mismatch = (child_value != parent_value if field == "chapter_title" else
                            child_value is not None and parent_value is not None and
                            (child_value < parent_value if field == "page_start" else
                             child_value > parent_value))
                if mismatch:
                    raise ValueError(f"Parent {field} mismatch for passage {passage['passage_id']!r}")

        faiss = _faiss_api if _faiss_api is not None else get_faiss_api()
        try:
            index = faiss.read_index(str(paths["des_passages.faiss"]))
        except Exception as exc:
            raise ValueError(f"Could not read FAISS index: {paths['des_passages.faiss']}") from exc
        if index.ntotal != len(passages):
            raise ValueError(f"FAISS count {index.ntotal} does not match passage count {len(passages)}")
        if index.d <= 0:
            raise ValueError("FAISS index has an invalid embedding dimension")
        try:
            from rank_bm25 import BM25Okapi
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "Hybrid retrieval requires the optional dependencies rank-bm25 and sentence-transformers"
            ) from exc
        bm25 = BM25Okapi([tokenize(passage["text"]) for passage in passages])
        # Avoid automatic MPS selection: concurrent retrieval and semantic scoring
        # caused a native Metal command-buffer abort in the local macOS server.
        embedder = _embedder if _embedder is not None else SentenceTransformer(embedding_model, device="cpu")
        dimension = embedder.get_sentence_embedding_dimension()
        if dimension != index.d:
            raise ValueError(f"Embedding model dimension {dimension} does not match FAISS dimension {index.d}")
        return cls(embedder, index, bm25, passages, parents, method=method)

    @classmethod
    def from_textbooks(cls, data_root: Path, *, book_count=3, method="dual",
                       embedding_model="sentence-transformers/all-MiniLM-L6-v2"):
        """Load 1–3 checked book corpora into a single global ranking.

        Accept the repository root, AI_TA_PYTHON_CODE, or its textbook directory.
        Book identifiers namespace passage and parent IDs before concatenation.
        Every dense index uses one shared embedder and is copied only in memory.
        """
        if type(book_count) is not int or book_count not in (1, 2, 3):
            raise ValueError("book_count must be 1, 2, or 3")
        if method not in ("dual", "bm25", "semantic"):
            raise ValueError("method must be dual, bm25, or semantic")
        root = Path(data_root)
        candidates = (root / "AI_TA_PYTHON_CODE" / "textbook", root / "textbook", root)
        directory = next((path for path in candidates if (path / "textbook1").is_dir()), None)
        if directory is None:
            raise FileNotFoundError("Cannot locate AI_TA_PYTHON_CODE/textbook under the data directory.")
        faiss = get_faiss_api()
        from rank_bm25 import BM25Okapi
        from sentence_transformers import SentenceTransformer

        embedder = SentenceTransformer(embedding_model, device="cpu")
        titles = ("Discrete-Event System Simulation", "Simulation Modeling and Analysis",
                  "Discrete-Event Simulation: A First Course")
        combined_index, passages, parents = None, [], {}
        verified_books = []
        for position in range(book_count):
            book_id = f"textbook{position + 1}"
            base = directory / book_id
            corpus = cls.from_directory(base, embedding_model, method=method,
                                        _embedder=embedder, _faiss_api=faiss)
            if corpus.index.metric_type != faiss.METRIC_INNER_PRODUCT:
                raise ValueError(f"{book_id}: expected normalized inner-product index")
            manifest_path = base / "index_manifest.json"
            if manifest_path.is_file():
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                if (manifest.get("model") != embedding_model
                        or manifest.get("normalized") is not True
                        or manifest.get("dimension") != corpus.index.d
                        or manifest.get("passage_order") != [p["passage_id"] for p in corpus.passages]):
                    raise ValueError(f"{book_id}: incompatible index manifest or passage order")
                for filename, field in (("chunks.jsonl", "chunks_sha256"),
                                        ("des_passages.jsonl", "passages_sha256")):
                    if hashlib.sha256((base / filename).read_bytes()).hexdigest() != manifest.get(field):
                        raise ValueError(f"{book_id}: {filename} differs from index manifest")
                verified_books.append(book_id)
            if combined_index is None:
                combined_index = faiss.IndexFlatIP(corpus.index.d)
            if corpus.index.d != combined_index.d:
                raise ValueError(f"{book_id}: embedding dimension mismatch")
            combined_index.add(corpus.index.reconstruct_n(0, corpus.index.ntotal))
            for parent_id, parent in corpus.parents.items():
                key = f"{book_id}:{parent_id}"
                parents[key] = dict(parent, chunk_id=key,
                    chapter_title=f"{titles[position]}; {parent.get('chapter_title', 'Unknown')}")
            for passage in corpus.passages:
                passages.append(dict(passage,
                    passage_id=f"{book_id}:{passage['passage_id']}",
                    parent_chunk_id=f"{book_id}:{passage['parent_chunk_id']}"))
        bm25 = BM25Okapi([tokenize(passage["text"]) for passage in passages])
        retriever = cls(embedder, combined_index, bm25, passages, parents, method=method)
        retriever.book_count = book_count
        retriever.manifest_verified_books = tuple(verified_books)
        return retriever
