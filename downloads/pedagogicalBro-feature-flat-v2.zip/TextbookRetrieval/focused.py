"""Question-only focused retrieval, leaving the legacy retriever unchanged."""

from collections import defaultdict
import hashlib
import json
import math
import operator
import re
import unicodedata

from .hybrid import RetrievalResult, Source, _source_header, tokenize


FOCUSED_VERSION = "focused-passages-v1"
_STOP_WORDS = frozenset((
    "a an the what which who how why when where is are was were be been being "
    "do does did can could would should of in on at to for from by with and or "
    "as that this these those it its into about please explain define describe"
).split())
_NOISE_CHAPTERS = ("about the author", "bibliography", "contents", "copyright",
                   "index", "preface", "references", "table of contents", "title")
_DEFINITION_CUES = frozenset(("is", "are", "mean", "refer", "represent", "denote",
                              "define", "consist", "describe", "occur"))
_NOTE = "[Focused textbook excerpt.]\n"

FOCUSED_CONFIG = {
    "version": FOCUSED_VERSION,
    "candidate_count_per_channel": 60,
    "rrf_k": 60,
    "max_sources": 3,
    "max_source_chars": 1600,
    "max_excerpt_chars": 4800,
    "max_context_chars": 5400,
    "max_adjacent_passages": 1,
    "near_duplicate_shingle_jaccard": 0.8,
    "rank_order": ["focus_coverage", "focus_phrase", "definition_cue", "rrf",
                   "query_coverage", "dense_similarity", "original_index_order"],
    "query_stop_words": sorted(_STOP_WORDS),
    "excluded_chapter_names": list(_NOISE_CHAPTERS),
    "definition_cues": sorted(_DEFINITION_CUES),
    "query_normalization": "nfkc_lower_ascii_words_conservative_plural",
    "focus_rule": "remove_question_scaffold_and_in_qualifier_keep_parenthetical_acronyms_as_alternatives",
    "dense_query": "original_question",
    "window_rule": "anchor_passage_then_first_fitting_next_or_previous_sibling_complete_sentence_prefix_if_needed",
    "definition_cue_lookahead_tokens": 5,
    "math_boundary_guard": "balanced_latex_inline_and_display_delimiters_for_introduced_sentence_cuts",
    "scoring_model_used_for_retrieval": False,
    "reference_answers_used": False,
}
FOCUSED_CONFIG_SHA256 = hashlib.sha256(json.dumps(
    FOCUSED_CONFIG, sort_keys=True, separators=(",", ":"), ensure_ascii=False
).encode("utf-8")).hexdigest()


def _canonical(word):
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 4 and word.endswith("s") and not word.endswith(("ss", "us", "is")):
        return word[:-1]
    return word


def _words(text):
    return [_canonical(word) for word in tokenize(unicodedata.normalize("NFKC", text))]


def _content(text):
    return [word for word in _words(text) if word not in _STOP_WORDS]


def _focus(question):
    text = unicodedata.normalize("NFKC", question).strip().rstrip("?.!")
    acronyms = [_words(value) for value in re.findall(r"\(([A-Z][A-Z0-9-]{1,10})\)", text)]
    text = re.sub(r"\([A-Z][A-Z0-9-]{1,10}\)", " ", text)
    text = re.sub(r"^(?:what\s+(?:is|are|does|do)|define|describe|explain)\s+", "", text, flags=re.I)
    text = re.split(r"\s+in\s+", text, maxsplit=1, flags=re.I)[0]
    if re.match(r"^what\s+(?:does|do)\b", question, re.I):
        text = re.sub(r"\s+(?:assess|measure|test|mean|represent|do|model)\s*$", "", text, flags=re.I)
    words = _content(text) or _content(question)
    return words, [value for value in acronyms if value]


def _find_sequence(words, sequence):
    if not sequence:
        return -1
    for start in range(len(words) - len(sequence) + 1):
        if words[start:start + len(sequence)] == sequence:
            return start
    return -1


def _definition_cue(text, focus, acronyms):
    words = _words(text)
    meaningful = [(index, word) for index, word in enumerate(words) if word not in _STOP_WORDS]
    content = [word for _, word in meaningful]
    for target in [focus, *acronyms]:
        start = _find_sequence(content, target)
        if start < 0:
            continue
        end = meaningful[start + len(target) - 1][0] + 1
        after = words[end:end + 5]
        if any(word in _DEFINITION_CUES for word in after) or (after and after[0] in ("a", "an")):
            return 1
    return 0


def _shingles(text):
    words = _words(text)
    order = min(3, len(words))
    return {tuple(words[index:index + order]) for index in range(len(words) - order + 1)} if order else set()


def _near_duplicate(left, right):
    first, second = _shingles(left), _shingles(right)
    return bool(first and second and len(first & second) / len(first | second) >= 0.8)


def _balanced_math(text):
    return all(text.count(opening) == text.count(closing)
               for opening, closing in ((r"\(", r"\)"), (r"\[", r"\]")))


class FocusedRetriever:
    """Reuse a loaded corpus/embedder/native index with a fixed focused policy."""

    def __init__(self, inner):
        self.inner = inner
        self._siblings = defaultdict(list)
        for identifier, passage in enumerate(inner.passages):
            self._siblings[passage.get("parent_chunk_id")].append(identifier)
        self._positions = {identifier: position for siblings in self._siblings.values()
                           for position, identifier in enumerate(siblings)}

    def _candidates(self, question):
        inner = self.inner
        count = min(60, len(inner.passages))
        dense, similarities = [], {}
        vector = inner.embedder.encode([question], normalize_embeddings=True, convert_to_numpy=True).astype("float32")
        distances, identifiers = inner.index.search(vector, count)
        for value, score in zip(identifiers[0], distances[0]):
            try:
                identifier = operator.index(value)
            except TypeError:
                continue
            if isinstance(value, bool) or not 0 <= identifier < len(inner.passages) or identifier in similarities:
                continue
            dense.append(identifier)
            similarities[identifier] = float(score) if math.isfinite(float(score)) else -1.0
        query_tokens = [word for word in tokenize(question) if word not in _STOP_WORDS]
        scored = [(identifier, float(score)) for identifier, score in enumerate(inner.bm25.get_scores(query_tokens))
                  if identifier < len(inner.passages) and math.isfinite(float(score)) and float(score) > 0]
        sparse = [identifier for identifier, _ in sorted(scored, key=lambda pair: (-pair[1], pair[0]))[:count]]
        fused = {}
        for ranking in (dense, sparse):
            for rank, identifier in enumerate(ranking, 1):
                fused[identifier] = fused.get(identifier, 0.0) + 1.0 / (60 + rank)
        focus, acronyms = _focus(question)
        required = set(focus)
        query_words = set(_content(question))
        def ranking(identifier):
            passage = inner.passages[identifier]
            words = _content(passage["text"])
            present = set(words)
            coverage = len(required & present) / len(required) if required else 0.0
            phrase = int(len(focus) > 1 and _find_sequence(words, focus) >= 0)
            full_coverage = len(query_words & present) / len(query_words) if query_words else 0.0
            return (coverage, phrase, _definition_cue(passage["text"], focus, acronyms),
                    fused[identifier], full_coverage, similarities.get(identifier, -1.0), -identifier)
        return sorted(fused, key=ranking, reverse=True)

    def _span(self, passage, parent):
        start, end = passage.get("parent_char_start"), passage.get("parent_char_end")
        if isinstance(start, int) and isinstance(end, int) and parent["text"][start:end] == passage["text"]:
            return start, end
        start = parent["text"].find(passage["text"])
        return (start, start + len(passage["text"])) if start >= 0 else None

    def _excerpt(self, identifier, available):
        passage = self.inner.passages[identifier]
        parent = self.inner.parents[passage["parent_chunk_id"]]
        text = passage["text"].strip()
        selected = [passage]
        span = self._span(passage, parent)
        siblings = self._siblings[passage["parent_chunk_id"]]
        position = self._positions[identifier]
        for adjacent_position in (position + 1, position - 1):
            if span is None or not 0 <= adjacent_position < len(siblings):
                continue
            neighbor = self.inner.passages[siblings[adjacent_position]]
            neighbor_span = self._span(neighbor, parent)
            if neighbor_span is None:
                continue
            start, end = min(span[0], neighbor_span[0]), max(span[1], neighbor_span[1])
            expanded = parent["text"][start:end].strip()
            if len(expanded) <= available:
                text = expanded
                selected.append(neighbor)
                break
        # Whole passages/sentences only: never cut an equation to satisfy a cap.
        if len(text) > available:
            units = re.split(r"\n\s*\n|(?<=[.!?])\s+(?=[A-Z])", text)
            kept = []
            for unit in units:
                if len("\n\n".join([*kept, unit])) > available:
                    break
                kept.append(unit)
            while kept and not _balanced_math("\n\n".join(kept)):
                kept.pop()
            text = "\n\n".join(kept).strip()
        starts = [row.get("page_start") for row in selected if row.get("page_start") is not None]
        ends = [row.get("page_end") for row in selected if row.get("page_end") is not None]
        return text, min(starts) if starts else parent.get("page_start"), max(ends) if ends else parent.get("page_end")

    def retrieve(self, question):
        if not isinstance(question, str):
            raise TypeError("query must be a string")
        if not question.strip() or not self.inner.passages:
            return RetrievalResult(question, ())
        sources, seen_parents, text_used, context_used = [], set(), 0, 0
        for identifier in self._candidates(question):
            passage = self.inner.passages[identifier]
            parent_id = passage.get("parent_chunk_id")
            if parent_id in seen_parents or parent_id not in self.inner.parents:
                continue
            parent = self.inner.parents[parent_id]
            chapter = parent.get("chapter_title", passage.get("chapter_title", "Unknown"))
            if chapter.split(";")[-1].strip().casefold() in _NOISE_CHAPTERS:
                continue
            source = Source(len(sources) + 1, parent_id, chapter, parent.get("page_start"), parent.get("page_end"), "")
            separator = 2 if sources else 0
            available = min(1600, 4800 - text_used, 5400 - context_used - separator - len(_source_header(source)))
            excerpt, page_start, page_end = self._excerpt(identifier, available - len(_NOTE))
            if not excerpt or any(_near_duplicate(excerpt, prior.text.removeprefix(_NOTE)) for prior in sources):
                continue
            source = Source(source.number, parent_id, chapter, page_start, page_end, _NOTE + excerpt)
            # A changed page header can be longer than its conservative parent header.
            size = separator + len(_source_header(source)) + len(source.text)
            if context_used + size > 5400:
                continue
            sources.append(source)
            seen_parents.add(parent_id)
            text_used += len(source.text)
            context_used += size
            if len(sources) == 3:
                break
        return RetrievalResult(question, tuple(sources))
